Patch V6 follow-up fixes

1. Fixed SFTP multi-scope uniqueness bug by changing the registry uniqueness to tenant + scope_type + scope_key + server_code.
2. Added migration backend/sql/005_sftp_server_scope_fix.sql for existing databases.
3. Hardened SFTP export path resolution against path traversal / unsafe relative keys.
4. Added resolved available SFTP server metadata into serving payloads.
5. Added optional server_code selection to GET /v1/jobs/{job_id}/serving.
6. Added admin resolve endpoint for context-aware SFTP server resolution.
