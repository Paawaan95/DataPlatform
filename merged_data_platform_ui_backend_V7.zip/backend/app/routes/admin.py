from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app.config import settings
from app.sql_repo import (
    call_bootstrap,
    delete_sftp_server_config,
    get_sftp_server_config,
    get_tenant,
    list_sftp_server_configs,
    list_tenants,
    list_tool_instances,
    upsert_sftp_server_config,
)

router = APIRouter()


class BootstrapRequest(BaseModel):
    tenant_id: str
    tenant_name: str = Field(default_factory=lambda: settings.DEFAULT_TENANT_NAME)
    airflow_base_url: str = Field(default_factory=lambda: settings.AIRFLOW_BASE_URL)
    airbyte_base_url: str | None = Field(default_factory=lambda: settings.AIRBYTE_BASE_URL)

    airflow_ui_base_url: str | None = Field(default_factory=lambda: settings.AIRFLOW_UI_BASE_URL)
    airflow_auth_mode: str | None = Field(default_factory=lambda: settings.AIRFLOW_AUTH_MODE)
    airflow_username: str | None = None
    airflow_password: str | None = None
    airflow_bearer_token: str | None = None
    airflow_username_env: str | None = None
    airflow_password_env: str | None = None
    airflow_bearer_token_env: str | None = None
    airflow_discovery_dag_ids: list[str] | None = None
    airflow_job_type_map: dict[str, str] | None = None
    airflow_default_visibility: str | None = Field(default=None, description='Private | Team | Global')
    airflow_discovery_run_type_filter: str | None = Field(default=None, description='all | manual_only | scheduled_only')
    airbyte_ui_base_url: str | None = Field(default_factory=lambda: settings.AIRBYTE_UI_BASE_URL)
    airbyte_auth_mode: str | None = Field(default_factory=lambda: settings.AIRBYTE_AUTH_MODE)
    airbyte_username: str | None = None
    airbyte_password: str | None = None
    airbyte_bearer_token: str | None = None
    airbyte_api_key: str | None = None
    airbyte_api_key_header: str | None = Field(default_factory=lambda: settings.AIRBYTE_API_KEY_HEADER)
    airbyte_api_key_prefix: str | None = Field(default_factory=lambda: settings.AIRBYTE_API_KEY_PREFIX)
    airbyte_workspace_id: str | None = Field(default_factory=lambda: settings.AIRBYTE_WORKSPACE_ID)
    airbyte_job_type_map: dict[str, str] | None = None
    airbyte_default_visibility: str | None = Field(default=None, description='Private | Team | Global')


class ActivateTenantRequest(BaseModel):
    is_active: bool = True


def _compact_dict(raw: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in raw.items() if value not in (None, '', [], {})}


@router.post('/bootstrap')
def bootstrap(req: BootstrapRequest):
    airflow_auth_ref = _compact_dict(
        {
            'ui_base_url': req.airflow_ui_base_url,
            'auth_mode': req.airflow_auth_mode,
            'username': req.airflow_username,
            'password': req.airflow_password,
            'bearer_token': req.airflow_bearer_token,
            'username_env': req.airflow_username_env,
            'password_env': req.airflow_password_env,
            'bearer_token_env': req.airflow_bearer_token_env,
            'discovery_dag_ids': req.airflow_discovery_dag_ids,
            'job_type_map': req.airflow_job_type_map,
            'default_visibility': req.airflow_default_visibility,
            'discovery_run_type_filter': req.airflow_discovery_run_type_filter,
        }
    )

    airbyte_auth_ref = _compact_dict(
        {
            'ui_base_url': req.airbyte_ui_base_url,
            'auth_mode': req.airbyte_auth_mode,
            'username': req.airbyte_username,
            'password': req.airbyte_password,
            'bearer_token': req.airbyte_bearer_token,
            'api_key': req.airbyte_api_key,
            'api_key_header': req.airbyte_api_key_header,
            'api_key_prefix': req.airbyte_api_key_prefix,
            'workspace_id': req.airbyte_workspace_id,
            'job_type_map': req.airbyte_job_type_map,
            'default_visibility': req.airbyte_default_visibility,
        }
    )

    call_bootstrap(
        tenant_id=req.tenant_id,
        tenant_name=req.tenant_name,
        airflow_base_url=req.airflow_base_url,
        airbyte_base_url=req.airbyte_base_url,
        airflow_auth_ref=airflow_auth_ref or None,
        airbyte_auth_ref=airbyte_auth_ref or None,
    )
    return {
        'ok': True,
        'tenant_id': req.tenant_id,
        'airflow_base_url': req.airflow_base_url,
        'airbyte_base_url': req.airbyte_base_url,
    }


@router.get('/tenants')
def tenants(active_only: bool = True):
    return list_tenants(active_only=active_only)


@router.get('/tenants/{tenant_id}')
def tenant_detail(tenant_id: str):
    row = get_tenant(tenant_id)
    if not row:
        raise HTTPException(status_code=404, detail=f'Tenant {tenant_id} not found')
    return row


@router.get('/tool-instances')
def tool_instances(tenant_id: str | None = Query(default=None), active_only: bool = True):
    return list_tool_instances(tenant_id=tenant_id, active_only=active_only)


class SftpServerConfigRequest(BaseModel):
    tenant_id: str
    server_code: str
    display_name: str
    scope_type: str = Field(default='tenant', description='tenant | team | user')
    scope_key: str | None = None
    host: str
    port: int = 22
    public_base_url: str | None = ''
    root_path: str = '/exports'
    export_root: str = '/srv/sftpgo/data/exports'
    read_only: bool = True
    auth_mode: str = 'password'
    enabled: bool = True
    sftpgo_enabled: bool = True
    username_template: str | None = '{tenant_id}'
    home_subdir_template: str | None = '{tenant_id}'
    password_secret: str | None = None
    metadata_json: dict[str, Any] | None = None


@router.get('/sftp-servers')
def sftp_servers(tenant_id: str | None = Query(default=None), enabled_only: bool = False):
    return list_sftp_server_configs(tenant_id=tenant_id, enabled_only=enabled_only)


@router.get('/sftp-servers/{server_id}')
def sftp_server_detail(server_id: int):
    row = get_sftp_server_config(server_id)
    if not row:
        raise HTTPException(status_code=404, detail=f'SFTP server config {server_id} not found')
    return row


@router.post('/sftp-servers')
def upsert_sftp_server(req: SftpServerConfigRequest):
    scope_type = (req.scope_type or 'tenant').strip().lower()
    if scope_type not in {'tenant', 'team', 'user'}:
        raise HTTPException(status_code=400, detail='scope_type must be one of tenant, team, user')
    cleaned_server_code = (req.server_code or '').strip()
    if not cleaned_server_code:
        raise HTTPException(status_code=400, detail='server_code is required')
    cleaned_server_code = cleaned_server_code.replace(' ', '_').replace('/', '_')
    scope_key = (req.scope_key or '').strip()
    if not scope_key:
        scope_key = req.tenant_id if scope_type == 'tenant' else ''
    if scope_type in {'team', 'user'} and not scope_key:
        raise HTTPException(status_code=400, detail='scope_key is required for team or user scoped SFTP servers')
    return upsert_sftp_server_config(
        tenant_id=req.tenant_id,
        server_code=cleaned_server_code,
        display_name=req.display_name,
        scope_type=scope_type,
        scope_key=scope_key,
        host=req.host,
        port=req.port,
        public_base_url=req.public_base_url,
        root_path=req.root_path,
        export_root=req.export_root,
        read_only=req.read_only,
        auth_mode=req.auth_mode,
        enabled=req.enabled,
        sftpgo_enabled=req.sftpgo_enabled,
        username_template=req.username_template,
        home_subdir_template=req.home_subdir_template,
        password_secret=req.password_secret,
        metadata_json=req.metadata_json,
    )


@router.delete('/sftp-servers/{server_id}')
def remove_sftp_server(server_id: int):
    deleted = delete_sftp_server_config(server_id)
    if not deleted:
        raise HTTPException(status_code=404, detail=f'SFTP server config {server_id} not found')
    return {'ok': True, 'server_id': server_id}


@router.get('/sftp-servers/resolve/{tenant_id}')
def resolve_sftp_server_for_context(tenant_id: str, team: str | None = Query(default=None), user_id: str | None = Query(default=None), requested_server_code: str | None = Query(default=None)):
    from app.services.sftp_registry import resolve_sftp_server_config
    return resolve_sftp_server_config(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code)
