from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from app.config import settings
from app.services.sftp_registry import render_template, resolve_export_roots, resolve_sftp_server_config


class SFTPGoError(RuntimeError):
    pass


def _server_base_url(server: dict[str, Any]) -> str:
    metadata = server.get('metadata_json') if isinstance(server.get('metadata_json'), dict) else {}
    return str(metadata.get('sftpgo_base_url') or settings.SFTPGO_BASE_URL).rstrip('/')


def _enabled(server: dict[str, Any]) -> bool:
    return bool(settings.SFTP_ENABLED and server.get('enabled') and server.get('sftpgo_enabled') and _server_base_url(server))


def _home_dir_for_context(server: dict[str, Any], tenant_id: str, *, team: str | None = None, user_id: str | None = None, job_id: str | None = None) -> str:
    roots = resolve_export_roots(server, tenant_id=tenant_id, team=team, user_id=user_id, job_id=job_id)
    return roots['filesystem_root']


def _username_for_context(server: dict[str, Any], tenant_id: str, *, team: str | None = None, user_id: str | None = None, job_id: str | None = None) -> str:
    template = str(server.get('username_template') or '{tenant_id}').strip()
    username = render_template(template, tenant_id=tenant_id, team=team, user_id=user_id, job_id=job_id) or tenant_id
    return username.replace('/', '_').replace(' ', '_')


def _password_for_context(server: dict[str, Any], tenant_id: str, *, team: str | None = None, user_id: str | None = None) -> str:
    base = str(server.get('password_secret') or settings.SFTP_PASSWORD or 'change-me').strip()
    if user_id:
        return f'{base}_{user_id}'.replace(' ', '_').replace('/', '_')
    if team:
        return f'{base}_{team}'.replace(' ', '_').replace('/', '_')
    if tenant_id == settings.DEFAULT_TENANT_ID:
        return base
    return f'{base}_{tenant_id}'.replace(' ', '_').replace('/', '_')


def _admin_token(server: dict[str, Any]) -> str:
    if not _enabled(server):
        raise SFTPGoError('SFTPGo is not enabled')
    with httpx.Client(base_url=_server_base_url(server), timeout=10.0) as client:
        response = client.get('/api/v2/token', auth=(settings.SFTPGO_ADMIN_USERNAME, settings.SFTPGO_ADMIN_PASSWORD))
        response.raise_for_status()
        payload = response.json()
    token = str(payload.get('access_token') or '').strip()
    if not token:
        raise SFTPGoError('SFTPGo admin token response did not include access_token')
    return token


def _user_payload(server: dict[str, Any], tenant_id: str, *, team: str | None = None, user_id: str | None = None, job_id: str | None = None) -> dict[str, Any]:
    home_dir = _home_dir_for_context(server, tenant_id, team=team, user_id=user_id, job_id=job_id)
    Path(home_dir).mkdir(parents=True, exist_ok=True)
    read_only = bool(server.get('read_only', settings.SFTP_READ_ONLY))
    return {
        'status': 1,
        'username': _username_for_context(server, tenant_id, team=team, user_id=user_id, job_id=job_id),
        'password': _password_for_context(server, tenant_id, team=team, user_id=user_id),
        'home_dir': home_dir,
        'permissions': {'/': ['list', 'download'] if read_only else ['*']},
    }


def ensure_sftpgo_user(
    tenant_id: str,
    *,
    team: str | None = None,
    user_id: str | None = None,
    requested_server_code: str | None = None,
    job_id: str | None = None,
) -> dict[str, Any]:
    server = resolve_sftp_server_config(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code)
    username = _username_for_context(server, tenant_id, team=team, user_id=user_id, job_id=job_id)
    home_dir = _home_dir_for_context(server, tenant_id, team=team, user_id=user_id, job_id=job_id)
    password = _password_for_context(server, tenant_id, team=team, user_id=user_id)

    if not _enabled(server):
        return {
            'enabled': False,
            'server_code': server.get('server_code'),
            'username': username,
            'password': password if settings.SFTPGO_EXPOSE_CREDENTIALS_IN_METADATA else '',
            'home_dir': home_dir,
            'host': server.get('host'),
            'port': server.get('port'),
            'public_base_url': server.get('public_base_url') or settings.SFTPGO_PUBLIC_BASE_URL,
            'read_only': server.get('read_only', settings.SFTP_READ_ONLY),
        }

    token = _admin_token(server)
    headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}
    payload = _user_payload(server, tenant_id, team=team, user_id=user_id, job_id=job_id)

    with httpx.Client(base_url=_server_base_url(server), timeout=10.0, headers=headers) as client:
        get_response = client.get(f'/api/v2/users/{username}')
        if get_response.status_code == 404:
            create_response = client.post('/api/v2/users', json=payload)
            create_response.raise_for_status()
        elif get_response.is_success:
            update_response = client.put(f'/api/v2/users/{username}', json=payload)
            update_response.raise_for_status()
        else:
            get_response.raise_for_status()

    return {
        'enabled': True,
        'server_code': server.get('server_code'),
        'username': username,
        'password': password if settings.SFTPGO_EXPOSE_CREDENTIALS_IN_METADATA else '',
        'home_dir': home_dir,
        'host': server.get('host'),
        'port': server.get('port'),
        'public_base_url': server.get('public_base_url') or settings.SFTPGO_PUBLIC_BASE_URL,
        'read_only': server.get('read_only', settings.SFTP_READ_ONLY),
    }
