from __future__ import annotations

from pathlib import Path
from typing import Any

from app.config import settings
from app.sql_repo import find_best_sftp_server_config, list_matching_sftp_server_configs


def _env_fallback_server(tenant_id: str, team: str | None = None, user_id: str | None = None) -> dict[str, Any]:
    return {
        'server_code': settings.SFTP_DEFAULT_SERVER_CODE or 'default',
        'tenant_id': tenant_id,
        'scope_type': 'tenant',
        'scope_key': tenant_id,
        'display_name': 'Default SFTP server',
        'host': settings.SFTP_HOST,
        'port': settings.SFTP_PORT_EXTERNAL,
        'public_base_url': settings.SFTPGO_PUBLIC_BASE_URL if settings.SFTPGO_ENABLED else '',
        'root_path': settings.RESULTS_SFTP_ROOT,
        'export_root': Path(settings.RESULTS_SFTP_EXPORT_ROOT).resolve().as_posix(),
        'read_only': settings.SFTP_READ_ONLY,
        'auth_mode': 'password',
        'enabled': settings.SFTP_ENABLED,
        'sftpgo_enabled': settings.SFTPGO_ENABLED,
        'username_template': '{tenant_id}',
        'home_subdir_template': '{tenant_id}',
        'password_secret': settings.SFTP_PASSWORD,
        'metadata_json': {},
        'team': team or '',
        'user_id': user_id or '',
    }


def resolve_sftp_server_config(
    tenant_id: str,
    *,
    team: str | None = None,
    user_id: str | None = None,
    requested_server_code: str | None = None,
) -> dict[str, Any]:
    row = find_best_sftp_server_config(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code)
    return row or _env_fallback_server(tenant_id, team=team, user_id=user_id)


def _safe_token(value: str | None) -> str:
    token = (value or '').strip().replace(' ', '_').replace('\\', '_').replace('/', '_')
    return token.replace('..', '_')


def render_template(
    template: str | None,
    *,
    tenant_id: str,
    team: str | None = None,
    user_id: str | None = None,
    job_id: str | None = None,
) -> str:
    raw = (template or '').strip()
    if not raw:
        return ''
    safe_team = _safe_token(team)
    safe_user = _safe_token(user_id)
    safe_job = _safe_token(job_id)
    safe_tenant = _safe_token(tenant_id)
    return raw.format(tenant_id=safe_tenant, team=safe_team, user_id=safe_user, job_id=safe_job)


def resolve_export_roots(
    server: dict[str, Any],
    *,
    tenant_id: str,
    team: str | None = None,
    user_id: str | None = None,
    job_id: str | None = None,
) -> dict[str, str]:
    root_path = str(server.get('root_path') or settings.RESULTS_SFTP_ROOT).rstrip('/')
    export_root = str(server.get('export_root') or settings.RESULTS_SFTP_EXPORT_ROOT).rstrip('/')
    subdir_template = str(server.get('home_subdir_template') or '{tenant_id}').strip()
    relative_root = render_template(subdir_template, tenant_id=tenant_id, team=team, user_id=user_id, job_id=job_id).strip('/')
    public_root = f'{root_path}/{relative_root}' if relative_root else root_path
    filesystem_root = f'{export_root}/{relative_root}' if relative_root else export_root
    return {'public_root': public_root.rstrip('/'), 'filesystem_root': filesystem_root.rstrip('/')}


def list_resolved_sftp_servers(tenant_id: str, *, team: str | None = None, user_id: str | None = None) -> list[dict[str, Any]]:
    rows = list_matching_sftp_server_configs(tenant_id, team=team, user_id=user_id)
    if rows:
        return rows
    return [_env_fallback_server(tenant_id, team=team, user_id=user_id)]
