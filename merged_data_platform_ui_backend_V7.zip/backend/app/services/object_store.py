from __future__ import annotations

import base64
import csv
import io
import json
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import PurePosixPath
from typing import Any
from urllib.parse import urlparse

import pyarrow.parquet as pq
from minio import Minio
from minio.error import S3Error

from app.config import settings


SUPPORTED_PREVIEW_EXTENSIONS = tuple(
    ext.strip().lower() for ext in settings.MINIO_SUPPORTED_PREVIEW_EXTENSIONS.split(',') if ext.strip()
)


@dataclass
class StoragePath:
    bucket: str
    key: str = ''
    is_prefix: bool = True
    raw: str = ''

    @property
    def normalized_key(self) -> str:
        return self.key.lstrip('/')


def _encode_cursor(payload: dict[str, Any]) -> str:
    raw = json.dumps(payload, separators=(',', ':'), sort_keys=True).encode('utf-8')
    return base64.urlsafe_b64encode(raw).decode('utf-8')


def _decode_cursor(cursor: str | None) -> dict[str, Any]:
    if not cursor:
        return {}
    try:
        raw = base64.urlsafe_b64decode(cursor.encode('utf-8'))
        value = json.loads(raw.decode('utf-8'))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _build_minio_client(endpoint: str, secure: bool) -> Minio | None:
    endpoint = (endpoint or '').strip()
    if not settings.MINIO_ENABLED:
        return None
    if not endpoint or not settings.MINIO_ACCESS_KEY or not settings.MINIO_SECRET_KEY:
        return None
    return Minio(
        endpoint,
        access_key=settings.MINIO_ACCESS_KEY,
        secret_key=settings.MINIO_SECRET_KEY,
        secure=secure,
        region=settings.MINIO_REGION or None,
    )


def minio_client() -> Minio | None:
    return _build_minio_client(settings.minio_internal_endpoint(), settings.minio_internal_secure())


def minio_public_client() -> Minio | None:
    return _build_minio_client(settings.minio_public_endpoint(), settings.minio_public_secure())


def parse_result_location(result_location: str | None) -> StoragePath | None:
    raw = (result_location or '').strip()
    if not raw:
        return None

    parsed = urlparse(raw)
    if parsed.scheme in {'s3', 'minio'}:
        bucket = parsed.netloc or settings.MINIO_DEFAULT_BUCKET
        key = parsed.path.lstrip('/')
    else:
        bucket = settings.MINIO_DEFAULT_BUCKET
        key = raw.lstrip('/')

    suffix = PurePosixPath(key).suffix.lower()
    is_prefix = raw.endswith('/') or (not suffix)
    return StoragePath(bucket=bucket, key=key, is_prefix=is_prefix, raw=raw)


def _candidate_preview_extensions() -> tuple[str, ...]:
    return SUPPORTED_PREVIEW_EXTENSIONS or ('.csv', '.json', '.jsonl', '.ndjson', '.parquet')


def _object_format_from_key(object_key: str) -> str:
    lower_key = object_key.lower()
    if lower_key.endswith('.parquet'):
        return 'parquet'
    if lower_key.endswith('.csv'):
        return 'csv'
    if lower_key.endswith('.jsonl') or lower_key.endswith('.ndjson'):
        return 'jsonl'
    if lower_key.endswith('.json'):
        return 'json'
    return 'unknown'


def _read_object_bytes(client: Minio, bucket: str, object_key: str, *, byte_limit: int | None = None) -> bytes:
    if byte_limit is None:
        response = client.get_object(bucket, object_key)
    else:
        response = client.get_object(bucket, object_key, length=byte_limit)
    try:
        return response.read()
    finally:
        response.close()
        response.release_conn()


def _stat_object(client: Minio, bucket: str, object_key: str):
    return client.stat_object(bucket, object_key)


def _relative_key(location: StoragePath, object_key: str) -> str:
    object_key = object_key.lstrip('/')
    if location.is_prefix and location.normalized_key:
        prefix = location.normalized_key.rstrip('/') + '/'
        if object_key.startswith(prefix):
            relative = object_key[len(prefix):].lstrip('/')
            if relative:
                return relative
    return PurePosixPath(object_key).name or object_key


def _normalize_requested_object_key(value: str | None) -> str:
    return str(value or '').strip().lstrip('/')


def is_object_key_allowed(location: StoragePath | None, object_key: str | None) -> bool:
    if location is None:
        return False
    normalized = _normalize_requested_object_key(object_key)
    if not normalized:
        return False
    allowed_key = location.normalized_key
    if not allowed_key:
        return True
    if location.is_prefix:
        prefix = allowed_key.rstrip('/')
        return normalized == prefix or normalized.startswith(prefix + '/')
    return normalized == allowed_key


def validate_preferred_object_key(result_location: str | None, preferred_object_key: str | None) -> tuple[StoragePath | None, str | None]:
    location = parse_result_location(result_location)
    normalized = _normalize_requested_object_key(preferred_object_key)
    if not normalized:
        return location, None
    if not is_object_key_allowed(location, normalized):
        return location, 'Requested object_key is outside the job result scope'
    return location, None


def _list_prefix_objects(client: Minio, location: StoragePath, start_after: str = '', limit: int = 50) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    iterator = client.list_objects(
        location.bucket,
        prefix=location.normalized_key,
        recursive=True,
        start_after=start_after or None,
    )
    for obj in iterator:
        rows.append(
            {
                'object_key': obj.object_name,
                'relative_key': _relative_key(location, obj.object_name),
                'display_name': PurePosixPath(obj.object_name).name or obj.object_name,
                'size_bytes': getattr(obj, 'size', None),
                'etag': getattr(obj, 'etag', None),
                'last_modified': getattr(obj, 'last_modified', None),
                'content_type': getattr(obj, 'content_type', None),
                'format': _object_format_from_key(obj.object_name),
                'storage_location': f's3://{location.bucket}/{obj.object_name}',
            }
        )
        if len(rows) >= limit:
            break
    return rows


def list_job_objects(result_location: str | None, *, limit: int = 50, cursor: str | None = None) -> dict[str, Any]:
    location = parse_result_location(result_location)
    if location is None:
        return {'items': [], 'next_cursor': None, 'message': 'Result location is empty', 'count': 0}

    client = minio_client()
    if client is None:
        return {'items': [], 'next_cursor': None, 'message': 'MinIO is not configured', 'count': 0}

    limit = max(1, min(limit, settings.MINIO_LIST_MAX_LIMIT))
    cursor_payload = _decode_cursor(cursor)
    start_after = str(cursor_payload.get('last_key') or '')

    try:
        if not location.is_prefix and location.normalized_key:
            stat = _stat_object(client, location.bucket, location.normalized_key)
            item = {
                'object_key': location.normalized_key,
                'relative_key': PurePosixPath(location.normalized_key).name or location.normalized_key,
                'display_name': PurePosixPath(location.normalized_key).name or location.normalized_key,
                'size_bytes': getattr(stat, 'size', None),
                'etag': getattr(stat, 'etag', None),
                'last_modified': getattr(stat, 'last_modified', None),
                'format': _object_format_from_key(location.normalized_key),
                'storage_location': f's3://{location.bucket}/{location.normalized_key}',
                'is_primary': True,
            }
            return {'items': [item], 'next_cursor': None, 'message': '1 object resolved', 'count': 1}

        rows = _list_prefix_objects(client, location, start_after=start_after, limit=limit + 1)
        items = rows[:limit]
        next_cursor = _encode_cursor({'last_key': items[-1]['object_key']}) if len(rows) > limit and items else None

        preferred_ext = _candidate_preview_extensions()
        primary_assigned = False
        for item in items:
            item['is_primary'] = item['format'] in {ext.lstrip('.') for ext in preferred_ext} and not primary_assigned
            primary_assigned = primary_assigned or item['is_primary']
        if items and not primary_assigned:
            items[0]['is_primary'] = True

        return {'items': items, 'next_cursor': next_cursor, 'message': f'{len(items)} object(s) resolved', 'count': len(items)}
    except S3Error as exc:
        return {'items': [], 'next_cursor': None, 'message': f'MinIO object listing failed: {exc}', 'count': 0}


def resolve_primary_object(result_location: str | None, preferred_object_key: str | None = None) -> tuple[StoragePath | None, str | None, str | None]:
    location, validation_error = validate_preferred_object_key(result_location, preferred_object_key)
    if location is None:
        return None, None, 'Result location is empty'
    if validation_error:
        return location, None, validation_error

    client = minio_client()
    if client is None:
        return location, None, 'MinIO is not configured'

    normalized_preferred = _normalize_requested_object_key(preferred_object_key)
    if normalized_preferred:
        return location, normalized_preferred, None

    if not location.is_prefix and location.normalized_key:
        return location, location.normalized_key, None

    objects = list_job_objects(result_location, limit=settings.MINIO_SERVING_OBJECT_SUMMARY_LIMIT)
    items = objects.get('items') or []
    if not items:
        return location, None, 'No objects found under result prefix'

    for item in items:
        if item.get('is_primary'):
            return location, str(item['object_key']), None
    return location, str(items[0]['object_key']), None


def create_presigned_download(result_location: str | None, *, preferred_object_key: str | None = None, expires_in_seconds: int | None = None) -> dict[str, Any]:
    location, object_key, message = resolve_primary_object(result_location, preferred_object_key)
    if not location or not object_key:
        return {
            'download_url': None,
            'storage_location': result_location or '',
            'message': message or 'Download not available yet',
            'method': settings.RESULTS_DOWNLOAD_METHOD_LABEL,
            'expires_at': None,
            'expires_in_seconds': None,
            'object_key': _normalize_requested_object_key(preferred_object_key) or preferred_object_key,
            'public_endpoint': settings.minio_public_endpoint(),
            'public_secure': settings.minio_public_secure(),
        }

    client = minio_public_client()
    if client is None:
        return {
            'download_url': None,
            'storage_location': f's3://{location.bucket}/{object_key}',
            'message': 'MinIO public endpoint is not configured',
            'method': settings.RESULTS_DOWNLOAD_METHOD_LABEL,
            'expires_at': None,
            'expires_in_seconds': None,
            'object_key': object_key,
            'public_endpoint': settings.minio_public_endpoint(),
            'public_secure': settings.minio_public_secure(),
        }

    ttl_seconds = expires_in_seconds or settings.MINIO_PRESIGN_TTL_SECONDS
    ttl_seconds = max(60, min(ttl_seconds, 3600))
    url = client.presigned_get_object(location.bucket, object_key, expires=timedelta(seconds=ttl_seconds))
    expires_at = datetime.now(timezone.utc) + timedelta(seconds=ttl_seconds)
    return {
        'download_url': url,
        'expires_at': expires_at.isoformat(),
        'expires_in_seconds': ttl_seconds,
        'storage_location': f's3://{location.bucket}/{object_key}',
        'object_key': object_key,
        'method': settings.RESULTS_DOWNLOAD_METHOD_LABEL,
        'message': 'Ready',
        'public_endpoint': settings.minio_public_endpoint(),
        'public_secure': settings.minio_public_secure(),
    }


def _preview_csv(data: bytes, *, limit: int, row_offset: int) -> tuple[list[dict[str, Any]], str | None]:
    text = data.decode('utf-8-sig', errors='replace')
    reader = csv.DictReader(io.StringIO(text))
    rows: list[dict[str, Any]] = []
    current_index = 0
    next_cursor = None
    for row in reader:
        if current_index < row_offset:
            current_index += 1
            continue
        if len(rows) >= limit:
            next_cursor = _encode_cursor({'row_offset': current_index})
            break
        rows.append({key: value for key, value in row.items()})
        current_index += 1
    return rows, next_cursor


def _preview_json_lines(data: bytes, *, limit: int, row_offset: int) -> tuple[list[dict[str, Any]], str | None]:
    rows: list[dict[str, Any]] = []
    current_index = 0
    next_cursor = None
    for line in data.decode('utf-8', errors='replace').splitlines():
        if not line.strip():
            continue
        if current_index < row_offset:
            current_index += 1
            continue
        if len(rows) >= limit:
            next_cursor = _encode_cursor({'row_offset': current_index})
            break
        try:
            value = json.loads(line)
        except json.JSONDecodeError:
            value = {'raw': line}
        rows.append(value if isinstance(value, dict) else {'value': value})
        current_index += 1
    return rows, next_cursor


def _preview_json_document(data: bytes, *, limit: int, row_offset: int) -> tuple[list[dict[str, Any]], str | None]:
    try:
        value = json.loads(data.decode('utf-8', errors='replace'))
    except json.JSONDecodeError:
        return [], None

    if isinstance(value, list):
        slice_rows = value[row_offset: row_offset + limit]
        rows = [row if isinstance(row, dict) else {'value': row} for row in slice_rows]
        next_cursor = _encode_cursor({'row_offset': row_offset + limit}) if row_offset + limit < len(value) else None
        return rows, next_cursor
    if isinstance(value, dict):
        return [value], None
    return [{'value': value}], None


def _preview_parquet_inline(data: bytes, *, limit: int, row_offset: int) -> tuple[list[dict[str, Any]], str | None]:
    table = pq.read_table(io.BytesIO(data))
    total_rows = table.num_rows
    if row_offset >= total_rows:
        return [], None
    slice_length = min(limit, total_rows - row_offset)
    df = table.slice(row_offset, slice_length).to_pandas()
    rows = df.to_dict(orient='records')
    next_cursor = _encode_cursor({'row_offset': row_offset + slice_length}) if row_offset + slice_length < total_rows else None
    return rows, next_cursor


def _preview_parquet_duckdb(location: StoragePath, object_key: str, *, limit: int, row_offset: int) -> tuple[list[dict[str, Any]], str | None]:
    try:
        import duckdb  # type: ignore
    except Exception as exc:  # pragma: no cover - dependency optional until env is rebuilt
        raise RuntimeError(f'DuckDB parquet engine is unavailable: {exc}') from exc

    con = duckdb.connect(database=':memory:')
    try:
        for statement in ('INSTALL httpfs', 'LOAD httpfs'):
            try:
                con.execute(statement)
            except Exception:
                pass
        con.execute("SET s3_endpoint = ?", [settings.minio_internal_endpoint()])
        con.execute("SET s3_access_key_id = ?", [settings.MINIO_ACCESS_KEY])
        con.execute("SET s3_secret_access_key = ?", [settings.MINIO_SECRET_KEY])
        con.execute("SET s3_use_ssl = ?", ['true' if settings.minio_internal_secure() else 'false'])
        con.execute("SET s3_url_style = 'path'")
        region = settings.MINIO_REGION or 'us-east-1'
        con.execute("SET s3_region = ?", [region])
        rows = con.execute(
            'select * from read_parquet(?) limit ? offset ?',
            [f's3://{location.bucket}/{object_key}', limit + 1, row_offset],
        ).fetchdf()
        has_more = len(rows.index) > limit
        if has_more:
            rows = rows.head(limit)
        records = rows.to_dict(orient='records')
        next_cursor = _encode_cursor({'row_offset': row_offset + len(records)}) if has_more else None
        return records, next_cursor
    finally:
        con.close()


def _preview_parquet(location: StoragePath, object_key: str, *, client: Minio, limit: int, row_offset: int) -> tuple[list[dict[str, Any]], str | None]:
    engine = (settings.PARQUET_QUERY_ENGINE or 'duckdb_then_inline').strip().lower()
    if engine in {'duckdb', 'duckdb_then_inline'}:
        try:
            return _preview_parquet_duckdb(location, object_key, limit=limit, row_offset=row_offset)
        except Exception:
            if engine == 'duckdb':
                raise
    data = _read_object_bytes(client, location.bucket, object_key, byte_limit=settings.MINIO_PARQUET_INLINE_PREVIEW_MAX_BYTES)
    return _preview_parquet_inline(data, limit=limit, row_offset=row_offset)


def preview_result_object(result_location: str | None, *, limit: int = 20, cursor: str | None = None, preferred_object_key: str | None = None) -> dict[str, Any]:
    limit = max(1, min(limit, settings.MINIO_PREVIEW_MAX_LIMIT))
    cursor_payload = _decode_cursor(cursor)
    row_offset = int(cursor_payload.get('row_offset') or 0)

    location, object_key, message = resolve_primary_object(result_location, preferred_object_key)
    normalized_preferred = _normalize_requested_object_key(preferred_object_key) or preferred_object_key
    if not location or not object_key:
        return {
            'rows': [],
            'columns': [],
            'next_cursor': None,
            'message': message or 'Preview not available yet',
            'format': '',
            'storage_location': result_location or '',
            'object_key': normalized_preferred,
            'limit': limit,
            'preview_engine': '',
        }

    if cursor_payload.get('object_key') and cursor_payload.get('object_key') != object_key:
        return {
            'rows': [],
            'columns': [],
            'next_cursor': None,
            'message': 'Preview cursor does not match the selected object',
            'format': _object_format_from_key(object_key),
            'storage_location': f's3://{location.bucket}/{object_key}',
            'object_key': object_key,
            'limit': limit,
            'preview_engine': '',
        }

    client = minio_client()
    if client is None:
        return {
            'rows': [],
            'columns': [],
            'next_cursor': None,
            'message': 'MinIO is not configured',
            'format': '',
            'storage_location': f's3://{location.bucket}/{object_key}',
            'object_key': object_key,
            'limit': limit,
            'preview_engine': '',
        }

    fmt = _object_format_from_key(object_key)
    preview_engine = 'inline'
    try:
        if fmt == 'csv':
            data = _read_object_bytes(client, location.bucket, object_key, byte_limit=settings.MINIO_PREVIEW_MAX_BYTES)
            rows, next_cursor = _preview_csv(data, limit=limit, row_offset=row_offset)
        elif fmt == 'jsonl':
            data = _read_object_bytes(client, location.bucket, object_key, byte_limit=settings.MINIO_PREVIEW_MAX_BYTES)
            rows, next_cursor = _preview_json_lines(data, limit=limit, row_offset=row_offset)
        elif fmt == 'json':
            data = _read_object_bytes(client, location.bucket, object_key, byte_limit=settings.MINIO_PREVIEW_MAX_BYTES)
            rows, next_cursor = _preview_json_document(data, limit=limit, row_offset=row_offset)
        elif fmt == 'parquet':
            rows, next_cursor = _preview_parquet(location, object_key, client=client, limit=limit, row_offset=row_offset)
            preview_engine = (settings.PARQUET_QUERY_ENGINE or 'duckdb_then_inline').strip().lower()
        else:
            return {
                'rows': [],
                'columns': [],
                'next_cursor': None,
                'message': f'Preview is not supported for {object_key}',
                'format': fmt,
                'storage_location': f's3://{location.bucket}/{object_key}',
                'object_key': object_key,
                'limit': limit,
                'preview_engine': preview_engine,
            }

        if next_cursor:
            next_payload = _decode_cursor(next_cursor)
            next_payload['object_key'] = object_key
            next_cursor = _encode_cursor(next_payload)

        columns = list(rows[0].keys()) if rows else []
        return {
            'rows': rows,
            'columns': columns,
            'next_cursor': next_cursor,
            'message': 'Ready' if rows else 'Not available yet',
            'format': fmt,
            'storage_location': f's3://{location.bucket}/{object_key}',
            'object_key': object_key,
            'limit': limit,
            'preview_engine': preview_engine,
        }
    except S3Error as exc:
        return {
            'rows': [],
            'columns': [],
            'next_cursor': None,
            'message': f'MinIO preview failed: {exc}',
            'format': fmt,
            'storage_location': f's3://{location.bucket}/{object_key}',
            'object_key': object_key,
            'limit': limit,
            'preview_engine': preview_engine,
        }
    except Exception as exc:
        return {
            'rows': [],
            'columns': [],
            'next_cursor': None,
            'message': f'Preview parsing failed: {exc}',
            'format': fmt,
            'storage_location': f's3://{location.bucket}/{object_key}',
            'object_key': object_key,
            'limit': limit,
            'preview_engine': preview_engine,
        }


def build_serving_descriptor(
    *,
    job_id: str,
    tenant_id: str,
    result_location: str | None,
    objects_summary: dict[str, Any] | None = None,
    sftp_publication: dict[str, Any] | None = None,
) -> dict[str, Any]:
    location = parse_result_location(result_location)
    has_result = bool(location)
    objects_items = (objects_summary or {}).get('items') or []
    primary_object = next((item for item in objects_items if item.get('is_primary')), objects_items[0] if objects_items else None)
    object_count = int((objects_summary or {}).get('count') or len(objects_items) or 0)

    sftp_path = f"{settings.RESULTS_SFTP_ROOT.rstrip('/')}/{tenant_id}/{job_id}"
    if location and location.normalized_key and not location.is_prefix:
        sftp_path = f"{sftp_path}/{PurePosixPath(location.normalized_key).name}"

    sftp_payload = {
        'available': has_result and settings.SFTP_ENABLED,
        'path': sftp_path,
        'backed_by': result_location or '',
        'host': settings.SFTP_HOST,
        'port': settings.SFTP_PORT_EXTERNAL,
        'username': settings.SFTP_USERNAME,
        'auth_mode': 'password',
        'read_only': settings.SFTP_READ_ONLY,
        'published': False,
        'published_file_count': 0,
        'message': 'Not available yet' if not has_result else 'Ready for explicit publish',
        'publish_route': f'/v1/jobs/{job_id}/sftp-publish',
        'server_type': 'sftpgo' if settings.SFTPGO_ENABLED else 'filesystem-export',
    }
    if isinstance(sftp_publication, dict):
        sftp_payload.update(sftp_publication)

    return {
        'job_id': job_id,
        'tenant_id': tenant_id,
        'storage_backend': 'minio',
        'result_location': result_location or '',
        'has_result': has_result,
        'objects_summary': {
            'count': object_count,
            'multi_file': object_count > 1,
            'items': objects_items,
            'primary_object_key': primary_object.get('object_key') if primary_object else None,
        },
        'api': {
            'available': has_result,
            'route': f'/v1/jobs/{job_id}/preview',
            'method': 'GET',
            'backed_by': result_location or '',
            'pagination': 'cursor',
            'objects_route': f'/v1/jobs/{job_id}/objects',
            'preview_route': f'/v1/jobs/{job_id}/preview',
            'download_route': f'/v1/jobs/{job_id}/download-url',
            'serving_route': f'/v1/jobs/{job_id}/serving',
            'serving_route_supports_server_code': True,
            'auth_mode': 'bearer-or-api-key' if settings.API_AUTH_REQUIRED else 'demo-none',
        },
        'sftp': sftp_payload,
        'download': {'available': has_result, 'route': f'/v1/jobs/{job_id}/download-url', 'method': 'POST', 'backed_by': result_location or ''},
        'preview': {
            'available': has_result,
            'route': f'/v1/jobs/{job_id}/preview',
            'supported_formats': [ext.lstrip('.') for ext in _candidate_preview_extensions()],
            'primary_object_key': primary_object.get('object_key') if primary_object else None,
            'parquet_engine': settings.PARQUET_QUERY_ENGINE,
        },
    }
