from __future__ import annotations

import json
import shutil
from pathlib import Path, PurePosixPath
from typing import Any

from minio.error import S3Error

from app.config import settings
from app.services.object_store import list_job_objects, minio_client, parse_result_location
from app.services.sftp_registry import list_resolved_sftp_servers, resolve_export_roots, resolve_sftp_server_config
from app.services.sftpgo import ensure_sftpgo_user


def _job_export_dir(server: dict[str, Any], tenant_id: str, job_id: str, *, team: str | None = None, user_id: str | None = None) -> Path:
    roots = resolve_export_roots(server, tenant_id=tenant_id, team=team, user_id=user_id, job_id=job_id)
    return Path(roots['filesystem_root']).resolve() / job_id


def _manifest_path(server: dict[str, Any], tenant_id: str, job_id: str, *, team: str | None = None, user_id: str | None = None) -> Path:
    return _job_export_dir(server, tenant_id, job_id, team=team, user_id=user_id) / '.manifest.json'


def _relative_export_key(result_location: str | None, object_key: str) -> str:
    location = parse_result_location(result_location)
    object_key = object_key.lstrip('/')
    if location and location.is_prefix and location.normalized_key:
        prefix = location.normalized_key.rstrip('/') + '/'
        if object_key.startswith(prefix):
            relative = object_key[len(prefix):].lstrip('/')
            if relative:
                cleaned = PurePosixPath(relative).as_posix().lstrip('/')
                if cleaned and '..' not in PurePosixPath(cleaned).parts:
                    return cleaned
    fallback = PurePosixPath(object_key).name or object_key
    return fallback.replace('..', '_')


def _safe_target_path(export_dir: Path, relative_key: str) -> Path:
    candidate = (export_dir / relative_key).resolve()
    export_root = export_dir.resolve()
    if candidate != export_root and export_root not in candidate.parents:
        raise RuntimeError('Refusing to publish object outside export root')
    return candidate


def _copy_object(bucket: str, object_key: str, target_path: Path) -> None:
    client = minio_client()
    if client is None:
        raise RuntimeError('MinIO is not configured')
    target_path.parent.mkdir(parents=True, exist_ok=True)
    response = client.get_object(bucket, object_key)
    try:
        with target_path.open('wb') as fh:
            shutil.copyfileobj(response, fh)
    finally:
        response.close()
        response.release_conn()


def _base_payload(
    tenant_id: str,
    job_id: str,
    result_location: str | None,
    *,
    team: str | None = None,
    user_id: str | None = None,
    requested_server_code: str | None = None,
) -> dict[str, Any]:
    server = resolve_sftp_server_config(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code)
    roots = resolve_export_roots(server, tenant_id=tenant_id, team=team, user_id=user_id, job_id=job_id)
    credential_info = ensure_sftpgo_user(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code, job_id=job_id) if settings.SFTPGO_FORCE_PROVISION_ON_STATUS else {
        'enabled': settings.SFTP_ENABLED,
        'server_code': server.get('server_code'),
        'username': '',
        'password': '',
        'home_dir': roots['filesystem_root'],
        'host': server.get('host'),
        'port': server.get('port'),
        'public_base_url': server.get('public_base_url'),
        'read_only': server.get('read_only', settings.SFTP_READ_ONLY),
    }
    base_path = f"{roots['public_root'].rstrip('/')}/{job_id}"
    available_servers = list_resolved_sftp_servers(tenant_id, team=team, user_id=user_id)
    payload = {
        'available': bool(result_location) and settings.SFTP_ENABLED and bool(server.get('enabled', True)),
        'server_code': server.get('server_code'),
        'display_name': server.get('display_name') or server.get('server_code'),
        'scope_type': server.get('scope_type', 'tenant'),
        'scope_key': server.get('scope_key', tenant_id),
        'path': base_path,
        'backed_by': result_location or '',
        'host': credential_info.get('host') or server.get('host'),
        'port': credential_info.get('port') or server.get('port'),
        'username': credential_info.get('username') or '',
        'password': credential_info.get('password') or '',
        'auth_mode': server.get('auth_mode') or 'password',
        'read_only': bool(server.get('read_only', settings.SFTP_READ_ONLY)),
        'server_type': 'sftpgo' if server.get('sftpgo_enabled', settings.SFTPGO_ENABLED) else 'filesystem-export',
        'published': False,
        'published_file_count': 0,
        'published_files': [],
        'message': 'Not available yet' if not result_location else 'Ready for explicit publish',
        'admin_base_url': credential_info.get('public_base_url') or server.get('public_base_url') or settings.SFTPGO_PUBLIC_BASE_URL,
        'available_servers': [
            {
                'server_id': row.get('server_id'),
                'server_code': row.get('server_code'),
                'display_name': row.get('display_name') or row.get('server_code'),
                'scope_type': row.get('scope_type', 'tenant'),
                'scope_key': row.get('scope_key', tenant_id),
                'host': row.get('host'),
                'port': row.get('port'),
                'read_only': bool(row.get('read_only', settings.SFTP_READ_ONLY)),
            }
            for row in available_servers
        ],
    }
    if not settings.SFTP_ENABLED or not bool(server.get('enabled', True)):
        payload['message'] = 'SFTP is disabled'
    return payload


def get_sftp_publication_status(
    tenant_id: str,
    job_id: str,
    result_location: str | None,
    *,
    team: str | None = None,
    user_id: str | None = None,
    requested_server_code: str | None = None,
) -> dict[str, Any]:
    base_payload = _base_payload(tenant_id, job_id, result_location, team=team, user_id=user_id, requested_server_code=requested_server_code)
    if not settings.SFTP_ENABLED or not result_location or not base_payload.get('available'):
        return base_payload

    server = resolve_sftp_server_config(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code)
    export_dir = _job_export_dir(server, tenant_id, job_id, team=team, user_id=user_id)
    manifest_path = _manifest_path(server, tenant_id, job_id, team=team, user_id=user_id)
    published_files: list[str] = []
    if manifest_path.exists():
        try:
            manifest = json.loads(manifest_path.read_text(encoding='utf-8'))
        except Exception:
            manifest = {}
        raw_files = manifest.get('published_files') or []
        published_files = [str(item) for item in raw_files if str(item).strip()]
    elif export_dir.exists():
        for path in sorted(export_dir.rglob('*')):
            if not path.is_file() or path.name == '.manifest.json':
                continue
            relative = path.relative_to(export_dir).as_posix()
            published_files.append(str(PurePosixPath(base_payload['path']) / relative))

    if published_files:
        base_payload.update({'published': True, 'published_file_count': len(published_files), 'published_files': published_files, 'message': 'Published to SFTP export root'})
        if len(published_files) == 1:
            base_payload['path'] = published_files[0]
    return base_payload


def publish_result_to_sftp(
    tenant_id: str,
    job_id: str,
    result_location: str | None,
    *,
    preferred_object_key: str | None = None,
    explicit: bool = False,
    team: str | None = None,
    user_id: str | None = None,
    requested_server_code: str | None = None,
) -> dict[str, Any]:
    base_payload = get_sftp_publication_status(tenant_id, job_id, result_location, team=team, user_id=user_id, requested_server_code=requested_server_code)

    if not settings.SFTP_ENABLED or not base_payload.get('available'):
        return base_payload
    if not result_location:
        return base_payload
    if not explicit and not settings.SFTP_AUTO_PUBLISH:
        base_payload['message'] = 'SFTP auto publish is disabled'
        return base_payload

    location = parse_result_location(result_location)
    if location is None:
        base_payload['message'] = 'Invalid result location'
        return base_payload

    objects_payload = list_job_objects(result_location, limit=settings.SFTP_EXPORT_MAX_FILES)
    items = objects_payload.get('items') or []
    if preferred_object_key:
        items = [item for item in items if item.get('object_key') == preferred_object_key]
    if not items:
        base_payload['message'] = objects_payload.get('message') or 'No objects available for SFTP publish'
        return base_payload

    server = resolve_sftp_server_config(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code)
    export_dir = _job_export_dir(server, tenant_id, job_id, team=team, user_id=user_id)
    export_dir.mkdir(parents=True, exist_ok=True)
    ensure_sftpgo_user(tenant_id, team=team, user_id=user_id, requested_server_code=requested_server_code, job_id=job_id)

    published_files: list[str] = []
    try:
        for item in items:
            object_key = str(item.get('object_key') or '').strip()
            if not object_key:
                continue
            relative_key = _relative_export_key(result_location, object_key)
            target_path = _safe_target_path(export_dir, relative_key)
            if target_path.exists() and not settings.SFTP_EXPORT_OVERWRITE:
                published_files.append(str(PurePosixPath(base_payload['path']) / relative_key.replace('\\', '/')))
                continue
            _copy_object(location.bucket, object_key, target_path)
            published_files.append(str(PurePosixPath(base_payload['path']) / relative_key.replace('\\', '/')))

        manifest = {
            'tenant_id': tenant_id,
            'job_id': job_id,
            'result_location': result_location,
            'published_files': published_files,
            'server_type': base_payload.get('server_type'),
            'server_code': base_payload.get('server_code'),
        }
        _manifest_path(server, tenant_id, job_id, team=team, user_id=user_id).write_text(json.dumps(manifest, indent=2), encoding='utf-8')
    except S3Error as exc:
        base_payload['message'] = f'SFTP publish failed while reading MinIO: {exc}'
        return base_payload
    except Exception as exc:
        base_payload['message'] = f'SFTP publish failed: {exc}'
        return base_payload

    if len(published_files) == 1:
        base_payload['path'] = published_files[0]
    base_payload.update({'published': True, 'published_file_count': len(published_files), 'published_files': published_files, 'message': 'Published to SFTP export root'})
    return base_payload
