from __future__ import annotations

from pydantic import field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file='.env', extra='ignore')

    PLATFORM_ENV: str = 'development'
    PLATFORM_NAME: str = 'Data Platform Control Ledger'
    PLATFORM_VERSION: str = '1.4.0'

    DATABASE_URL: str | None = None
    POSTGRES_USER: str = 'dp'
    POSTGRES_PASSWORD: str = 'dp'
    POSTGRES_DB: str = 'dp_control'
    POSTGRES_HOST_INTERNAL: str = 'dp_control_pg'
    POSTGRES_PORT_INTERNAL: int = 5432

    DEFAULT_TENANT_ID: str = 'demo'
    DEFAULT_TENANT_NAME: str = 'Demo Tenant'
    TENANT_IDS: str = ''
    TENANT_SOURCE: str = 'db_or_env'
    ALLOW_DEFAULT_TENANT: bool = True
    ENFORCE_ACTIVE_TENANT: bool = True

    AIRFLOW_BASE_URL: str = 'http://host.docker.internal:18080'
    AIRFLOW_UI_BASE_URL: str = 'http://localhost:18080'
    AIRFLOW_AUTH_MODE: str = 'basic'
    AIRFLOW_USERNAME: str = 'admin'
    AIRFLOW_PASSWORD: str = 'ADMIN'
    AIRFLOW_BEARER_TOKEN: str = ''
    AIRFLOW_HTTP_TIMEOUT_SECONDS: int = 20

    AIRBYTE_BASE_URL: str = 'http://host.docker.internal:18000'
    AIRBYTE_UI_BASE_URL: str = 'http://localhost:18000'
    AIRBYTE_AUTH_MODE: str = 'none'
    AIRBYTE_USERNAME: str = ''
    AIRBYTE_PASSWORD: str = ''
    AIRBYTE_BEARER_TOKEN: str = ''
    AIRBYTE_API_KEY: str = ''
    AIRBYTE_API_KEY_HEADER: str = 'Authorization'
    AIRBYTE_API_KEY_PREFIX: str = 'Bearer'
    AIRBYTE_HTTP_TIMEOUT_SECONDS: int = 20
    AIRBYTE_WORKSPACE_ID: str = ''
    AIRBYTE_CONNECTION_LIMIT: int = 100
    AIRBYTE_JOB_LIST_LIMIT: int = 100
    AIRBYTE_LOOKBACK_HOURS: int = 24

    POLL_SECONDS: int = 10
    SLOW_DISCOVERY_SECONDS: int = 45

    DISCOVERY_DAG_IDS: str = 'dp_job_dispatcher'
    DISCOVERY_SCAN_ALL_DAGS: bool = False
    DISCOVERY_BOOTSTRAP_LOOKBACK_MINUTES: int = 60
    DISCOVERY_LOOKBACK_SECONDS: int = 900
    DISCOVERY_ACTIVE_POLL_WINDOW_MINUTES: int = 180
    DISCOVERY_DAG_RUN_PAGE_SIZE: int = 100
    DISCOVERY_MAX_PAGES: int = 3
    DISCOVERY_MAX_RUNS_PER_DAG_PER_LOOP: int = 100
    DISCOVERY_ORDER_BY: str = '-start_date'
    DISCOVERY_DEFAULT_VISIBILITY: str = 'Global'
    DISCOVERY_JOB_TYPE_MAP_JSON: str = '{"dp_job_dispatcher":"Ingestion"}'
    DISCOVERY_RUN_TYPE_FILTER: str = 'all'

    BOOTSTRAP_SEED_ENABLED: bool = True
    BOOTSTRAP_AIRFLOW_ENABLED: bool = True
    BOOTSTRAP_AIRBYTE_ENABLED: bool = True

    API_PORT_INTERNAL: int = 8099
    API_PORT_EXTERNAL: int = 8199
    POSTGRES_PORT_EXTERNAL: int = 5435

    API_AUTH_REQUIRED: bool = False
    DEFAULT_DEMO_SUBJECT: str = 'demo-user'
    DEFAULT_DEMO_ROLE: str = 'platform-admin'
    DEFAULT_DEMO_TEAM: str = 'Platform'
    AUTH_JWT_SECRET: str = ''
    AUTH_JWT_ALGORITHM: str = 'HS256'
    AUTH_JWT_ISSUER: str = 'data-platform-control'
    AUTH_JWT_AUDIENCE: str = 'data-platform-consumers'
    AUTH_JWKS_URL: str = ''
    AUTH_OIDC_DISCOVERY_URL: str = ''
    AUTH_SCOPE_CLAIM_NAMES: str = 'scope,scp,scopes'
    AUTH_ROLE_CLAIM_NAMES: str = 'role,roles,realm_access.roles'
    AUTH_TEAM_CLAIM_NAMES: str = 'team,team_id,groups'
    AUTH_TENANT_CLAIM_NAMES: str = 'tenant_id,tid,tenant'
    AUTH_JWT_CLOCK_SKEW_SECONDS: int = 30
    AUTH_JWT_REQUIRE_ISSUER: bool = True
    AUTH_JWT_REQUIRE_AUDIENCE: bool = True
    API_KEYS_JSON: str = ''

    MINIO_ENABLED: bool = True
    MINIO_ENDPOINT: str = 'minio:9000'
    MINIO_INTERNAL_ENDPOINT: str = 'minio:9000'
    MINIO_PUBLIC_ENDPOINT: str = '127.0.0.1:9000'
    MINIO_ACCESS_KEY: str = 'minioadmin'
    MINIO_SECRET_KEY: str = 'minioadmin'
    MINIO_SECURE: bool = False
    MINIO_INTERNAL_SECURE: bool | None = None
    MINIO_PUBLIC_SECURE: bool | None = None
    MINIO_REGION: str = ''
    MINIO_DEFAULT_BUCKET: str = 'job-results'
    MINIO_PRESIGN_TTL_SECONDS: int = 300
    MINIO_LIST_MAX_LIMIT: int = 500
    MINIO_PREVIEW_MAX_LIMIT: int = 100
    MINIO_PREVIEW_MAX_BYTES: int = 8_388_608
    MINIO_PARQUET_INLINE_PREVIEW_MAX_BYTES: int = 67_108_864
    MINIO_SUPPORTED_PREVIEW_EXTENSIONS: str = '.csv,.json,.jsonl,.ndjson,.parquet'
    MINIO_SERVING_OBJECT_SUMMARY_LIMIT: int = 50

    RESULTS_API_BASE_PATH: str = '/consumer-results'
    RESULTS_SFTP_ROOT: str = '/exports'
    RESULTS_SFTP_EXPORT_ROOT: str = '/srv/sftpgo/data/exports'
    RESULTS_DOWNLOAD_METHOD_LABEL: str = 'backend-generated presigned URL'

    SFTP_ENABLED: bool = True
    SFTP_HOST: str = '127.0.0.1'
    SFTP_PORT_EXTERNAL: int = 2222
    SFTP_USERNAME: str = 'demo_sftp'
    SFTP_PASSWORD: str = 'demo_sftp_password'
    SFTP_READ_ONLY: bool = True
    SFTP_AUTO_PUBLISH: bool = True
    SFTP_PUBLISH_ON_SERVING_READ: bool = False
    SFTP_EXPORT_MAX_FILES: int = 500
    SFTP_EXPORT_OVERWRITE: bool = False
    SFTP_MULTI_SERVER_MODE: bool = True
    SFTP_DEFAULT_SERVER_CODE: str = 'default'
    SFTP_REQUIRE_EXPLICIT_SERVER_SELECTION: bool = False

    SFTPGO_ENABLED: bool = True
    SFTPGO_BASE_URL: str = 'http://sftpgo:8080'
    SFTPGO_PUBLIC_BASE_URL: str = 'http://127.0.0.1:8080'
    SFTPGO_ADMIN_USERNAME: str = 'admin'
    SFTPGO_ADMIN_PASSWORD: str = 'admin_password_change_me'
    SFTPGO_CREATE_DEFAULT_ADMIN: bool = True
    SFTPGO_HOME_BASE_DIR: str = '/srv/sftpgo/data'
    SFTPGO_EXPOSE_CREDENTIALS_IN_METADATA: bool = False
    SFTPGO_FORCE_PROVISION_ON_STATUS: bool = True

    PARQUET_QUERY_ENGINE: str = 'duckdb_then_inline'
    PARQUET_QUERY_TEMP_DIR: str = '/tmp'

    def minio_internal_endpoint(self) -> str:
        return (self.MINIO_INTERNAL_ENDPOINT or self.MINIO_ENDPOINT or '').strip()

    def minio_public_endpoint(self) -> str:
        return (self.MINIO_PUBLIC_ENDPOINT or self.MINIO_INTERNAL_ENDPOINT or self.MINIO_ENDPOINT or '').strip()

    def minio_internal_secure(self) -> bool:
        return self.MINIO_SECURE if self.MINIO_INTERNAL_SECURE is None else bool(self.MINIO_INTERNAL_SECURE)

    def minio_public_secure(self) -> bool:
        return self.MINIO_SECURE if self.MINIO_PUBLIC_SECURE is None else bool(self.MINIO_PUBLIC_SECURE)

    def is_local_environment(self) -> bool:
        return (self.PLATFORM_ENV or '').strip().lower() in {'local', 'development', 'dev'}

    def validate_runtime_warnings(self) -> list[str]:
        warnings: list[str] = []
        public_endpoint = self.minio_public_endpoint()
        internal_endpoint = self.minio_internal_endpoint()
        if self.MINIO_ENABLED and not public_endpoint:
            warnings.append('MINIO_PUBLIC_ENDPOINT is empty; browser downloads will fail')
        if self.MINIO_ENABLED and not internal_endpoint:
            warnings.append('MINIO_INTERNAL_ENDPOINT is empty; backend MinIO reads will fail')
        if self.MINIO_ENABLED and public_endpoint and not self.is_local_environment() and public_endpoint.startswith(('127.0.0.1', 'localhost')):
            warnings.append('MINIO_PUBLIC_ENDPOINT points to localhost/127.0.0.1 outside local mode; browser downloads will usually fail for other users')
        if self.SFTP_ENABLED and self.SFTP_MULTI_SERVER_MODE and not self.SFTP_DEFAULT_SERVER_CODE:
            warnings.append('SFTP_DEFAULT_SERVER_CODE is empty while multi-server mode is enabled')
        return warnings

    def build_database_url(self) -> str:
        return (
            f'postgresql://{self.POSTGRES_USER}:{self.POSTGRES_PASSWORD}'
            f'@{self.POSTGRES_HOST_INTERNAL}:{self.POSTGRES_PORT_INTERNAL}/{self.POSTGRES_DB}'
        )

    @field_validator('MINIO_SUPPORTED_PREVIEW_EXTENSIONS')
    @classmethod
    def normalize_supported_extensions(cls, value: str) -> str:
        items = []
        for item in value.split(','):
            text = item.strip().lower()
            if not text:
                continue
            if not text.startswith('.'):
                text = f'.{text}'
            items.append(text)
        return ','.join(dict.fromkeys(items))


settings = Settings()
if not settings.DATABASE_URL:
    settings.DATABASE_URL = settings.build_database_url()
