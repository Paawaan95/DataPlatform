from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Any, Optional

import psycopg2.extras

from app.config import settings
from app.db import get_conn, put_conn


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def _parse_json_object(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    if isinstance(value, dict):
        return value
    if isinstance(value, str):
        text = value.strip()
        if not text:
            return {}
        try:
            obj = json.loads(text)
        except json.JSONDecodeError:
            return {}
        return obj if isinstance(obj, dict) else {}
    return {}


def _csv_items(value: str | None) -> list[str]:
    return [item.strip() for item in (value or '').split(',') if item and item.strip()]


def _resolve_secret_ref(auth_ref: dict[str, Any], direct_key: str, env_key_name: str, fallback: str | None = None) -> str | None:
    direct = auth_ref.get(direct_key)
    if direct not in (None, ''):
        return str(direct)

    env_name = auth_ref.get(env_key_name)
    if env_name not in (None, ''):
        env_value = os.getenv(str(env_name), '')
        if env_value:
            return env_value

    return fallback


_GLOBAL_DISCOVERY_JOB_TYPE_MAP = _parse_json_object(settings.DISCOVERY_JOB_TYPE_MAP_JSON)


def _build_tool_instance_config(row: dict[str, Any]) -> dict[str, Any]:
    auth_ref = _parse_json_object(row.get('auth_ref'))
    tool = str(row.get('tool') or '').strip().lower()
    base_url = str(row['base_url']).rstrip('/')

    if tool == 'airflow':
        discovery_dag_ids_raw = auth_ref.get('discovery_dag_ids')
        if isinstance(discovery_dag_ids_raw, str):
            discovery_dag_ids = _csv_items(discovery_dag_ids_raw)
        elif isinstance(discovery_dag_ids_raw, list):
            discovery_dag_ids = [str(item).strip() for item in discovery_dag_ids_raw if str(item).strip()]
        else:
            discovery_dag_ids = _csv_items(settings.DISCOVERY_DAG_IDS)

        job_type_map_raw = auth_ref.get('job_type_map')
        job_type_map = job_type_map_raw if isinstance(job_type_map_raw, dict) else _GLOBAL_DISCOVERY_JOB_TYPE_MAP

        return {
            'tenant_id': row['tenant_id'],
            'tool': tool,
            'base_url': base_url,
            'ui_base_url': str(auth_ref.get('ui_base_url') or settings.AIRFLOW_UI_BASE_URL or base_url).rstrip('/'),
            'auth_mode': str(auth_ref.get('auth_mode') or settings.AIRFLOW_AUTH_MODE or 'none').lower(),
            'username': _resolve_secret_ref(auth_ref, 'username', 'username_env', settings.AIRFLOW_USERNAME),
            'password': _resolve_secret_ref(auth_ref, 'password', 'password_env', settings.AIRFLOW_PASSWORD),
            'bearer_token': _resolve_secret_ref(auth_ref, 'bearer_token', 'bearer_token_env', settings.AIRFLOW_BEARER_TOKEN),
            'discovery_dag_ids': discovery_dag_ids,
            'job_type_map': job_type_map,
            'default_visibility': str(auth_ref.get('default_visibility') or settings.DISCOVERY_DEFAULT_VISIBILITY),
            'discovery_run_type_filter': str(
                auth_ref.get('discovery_run_type_filter') or settings.DISCOVERY_RUN_TYPE_FILTER or 'all'
            ).lower(),
            'auth_ref': auth_ref,
        }

    if tool == 'airbyte':
        return {
            'tenant_id': row['tenant_id'],
            'tool': tool,
            'base_url': base_url,
            'ui_base_url': str(auth_ref.get('ui_base_url') or settings.AIRBYTE_UI_BASE_URL or base_url).rstrip('/'),
            'auth_mode': str(auth_ref.get('auth_mode') or settings.AIRBYTE_AUTH_MODE or 'none').lower(),
            'username': _resolve_secret_ref(auth_ref, 'username', 'username_env', settings.AIRBYTE_USERNAME),
            'password': _resolve_secret_ref(auth_ref, 'password', 'password_env', settings.AIRBYTE_PASSWORD),
            'bearer_token': _resolve_secret_ref(auth_ref, 'bearer_token', 'bearer_token_env', settings.AIRBYTE_BEARER_TOKEN),
            'api_key': _resolve_secret_ref(auth_ref, 'api_key', 'api_key_env', settings.AIRBYTE_API_KEY),
            'api_key_header': str(auth_ref.get('api_key_header') or settings.AIRBYTE_API_KEY_HEADER or 'Authorization'),
            'api_key_prefix': str(auth_ref.get('api_key_prefix') or settings.AIRBYTE_API_KEY_PREFIX or '').strip(),
            'workspace_id': str(auth_ref.get('workspace_id') or settings.AIRBYTE_WORKSPACE_ID or '').strip(),
            'default_visibility': str(auth_ref.get('default_visibility') or settings.DISCOVERY_DEFAULT_VISIBILITY),
            'job_type_map': auth_ref.get('job_type_map') if isinstance(auth_ref.get('job_type_map'), dict) else {},
            'auth_ref': auth_ref,
        }

    return {
        'tenant_id': row['tenant_id'],
        'tool': tool,
        'base_url': base_url,
        'ui_base_url': str(auth_ref.get('ui_base_url') or base_url).rstrip('/'),
        'auth_mode': str(auth_ref.get('auth_mode') or 'none').lower(),
        'username': _resolve_secret_ref(auth_ref, 'username', 'username_env', None),
        'password': _resolve_secret_ref(auth_ref, 'password', 'password_env', None),
        'bearer_token': _resolve_secret_ref(auth_ref, 'bearer_token', 'bearer_token_env', None),
        'default_visibility': str(auth_ref.get('default_visibility') or settings.DISCOVERY_DEFAULT_VISIBILITY),
        'auth_ref': auth_ref,
    }


def log_event(
    tenant_id: str,
    tool: str,
    event_type: str,
    external_id: str | None = None,
    external_sub_id: str | None = None,
    payload: Any | None = None,
):
    conn = get_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    insert into sync_event_log(tenant_id, tool, event_type, external_id, external_sub_id, payload)
                    values (%s,%s,%s,%s,%s,%s::jsonb)
                    ''',
                    (
                        tenant_id,
                        tool,
                        event_type,
                        external_id,
                        external_sub_id,
                        json.dumps(payload) if payload is not None else None,
                    ),
                )
    finally:
        put_conn(conn)


def call_bootstrap(
    tenant_id: str,
    tenant_name: str,
    airflow_base_url: str,
    airbyte_base_url: str | None,
    airflow_auth_ref: dict[str, Any] | None = None,
    airbyte_auth_ref: dict[str, Any] | None = None,
) -> None:
    airflow_auth_ref_json = json.dumps(airflow_auth_ref) if airflow_auth_ref is not None else None
    airbyte_auth_ref_json = json.dumps(airbyte_auth_ref) if airbyte_auth_ref is not None else None

    conn = get_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    insert into tenant(tenant_id, tenant_name)
                    values (%s,%s)
                    on conflict (tenant_id) do update
                    set tenant_name=excluded.tenant_name, is_active=true, updated_at=now()
                    ''',
                    (tenant_id, tenant_name),
                )
                cur.execute(
                    '''
                    insert into tool_instance(tenant_id, tool, base_url, auth_ref, is_active)
                    values (%s,'airflow',%s,%s,true)
                    on conflict (tenant_id, tool) do update
                    set base_url=excluded.base_url,
                        auth_ref=coalesce(excluded.auth_ref, tool_instance.auth_ref),
                        is_active=true,
                        updated_at=now()
                    ''',
                    (tenant_id, airflow_base_url.rstrip('/'), airflow_auth_ref_json),
                )
                if airbyte_base_url and airbyte_base_url.strip():
                    cur.execute(
                        '''
                        insert into tool_instance(tenant_id, tool, base_url, auth_ref, is_active)
                        values (%s,'airbyte',%s,%s,true)
                        on conflict (tenant_id, tool) do update
                        set base_url=excluded.base_url,
                            auth_ref=coalesce(excluded.auth_ref, tool_instance.auth_ref),
                            is_active=true,
                            updated_at=now()
                        ''',
                        (tenant_id, airbyte_base_url.rstrip('/'), airbyte_auth_ref_json),
                    )
    finally:
        put_conn(conn)


def get_tenant(tenant_id: str) -> Optional[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                '''
                select tenant_id, tenant_name, is_active, created_at, updated_at
                from tenant
                where tenant_id=%s
                limit 1
                ''',
                (tenant_id,),
            )
            row = cur.fetchone()
            return dict(row) if row else None
    finally:
        put_conn(conn)


def tenant_is_active(tenant_id: str) -> bool:
    tenant = get_tenant(tenant_id)
    return bool(tenant and tenant.get('is_active'))


def list_tenants(active_only: bool = True) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                f'''
                select tenant_id, tenant_name, is_active, created_at, updated_at
                from tenant
                {'where is_active=true' if active_only else ''}
                order by tenant_id asc
                '''
            )
            return [dict(row) for row in cur.fetchall()]
    finally:
        put_conn(conn)


def list_tool_instances(tenant_id: str | None = None, active_only: bool = True) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        where = []
        params: list[Any] = []
        if tenant_id:
            where.append('tenant_id=%s')
            params.append(tenant_id)
        if active_only:
            where.append('is_active=true')
        where_sql = f"where {' and '.join(where)}" if where else ''
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                f'''
                select tenant_id, tool::text as tool, base_url, auth_ref, is_active, created_at, updated_at
                from tool_instance
                {where_sql}
                order by tenant_id asc, tool asc
                ''',
                tuple(params),
            )
            return [dict(row) for row in cur.fetchall()]
    finally:
        put_conn(conn)


def list_active_tenant_ids() -> list[str]:
    tenant_source = (settings.TENANT_SOURCE or 'db_or_env').strip().lower()
    explicit_tenants = _csv_items(settings.TENANT_IDS)
    db_tenants = [
        str(row['tenant_id']).strip()
        for row in list_tenants(active_only=True)
        if str(row.get('tenant_id', '')).strip()
    ]

    if tenant_source == 'env':
        if explicit_tenants:
            return explicit_tenants
        return [settings.DEFAULT_TENANT_ID.strip()] if settings.DEFAULT_TENANT_ID.strip() else []

    if tenant_source == 'db':
        return db_tenants

    if db_tenants:
        return db_tenants
    if explicit_tenants:
        return explicit_tenants
    if settings.DEFAULT_TENANT_ID:
        return [settings.DEFAULT_TENANT_ID.strip()]
    return []


def fetch_tool_instance(tenant_id: str, tool: str) -> Optional[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                '''
                select tenant_id, tool, base_url, auth_ref
                from tool_instance
                where tenant_id=%s and tool=%s and is_active=true
                limit 1
                ''',
                (tenant_id, tool),
            )
            row = cur.fetchone()
            return _build_tool_instance_config(dict(row)) if row else None
    finally:
        put_conn(conn)


def upsert_job_summary(
    tenant_id: str,
    job_id: str,
    job_type: str,
    orchestrator: str,
    status: str,
    visibility: str,
    created_at: datetime,
    airflow_dag_id: str | None = None,
    airflow_dag_run_id: str | None = None,
    airbyte_connection_id: str | None = None,
    airbyte_job_id: str | None = None,
    submitted_by_user_id: str | None = None,
    submitted_by_role: str | None = None,
    submitted_by_team: str | None = None,
    source: str | None = None,
    destination: str | None = None,
    result_location: str | None = None,
    open_job_link: str | None = None,
    seen_at: datetime | None = None,
):
    conn = get_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    select sp_upsert_job_summary_index(
                      %s,%s,%s,%s,%s,
                      %s,%s,%s,%s,
                      %s,%s,%s,%s,
                      %s,%s,%s,%s,
                      %s,%s
                    )
                    ''',
                    (
                        tenant_id,
                        job_id,
                        job_type,
                        orchestrator,
                        status,
                        submitted_by_user_id,
                        submitted_by_role,
                        submitted_by_team,
                        visibility,
                        source,
                        destination,
                        result_location,
                        open_job_link,
                        airflow_dag_id,
                        airflow_dag_run_id,
                        airbyte_connection_id,
                        airbyte_job_id,
                        created_at,
                        seen_at or utc_now(),
                    ),
                )
    finally:
        put_conn(conn)


def get_or_create_binding_id(
    tenant_id: str,
    tool: str,
    resource_type: str,
    external_id: str,
    external_sub_id: str | None = None,
    external_url: str | None = None,
    *,
    id_prefix: str = 'JOB',
) -> str:
    conn = get_conn()
    try:
        with conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    '''
                    select platform_resource_id, external_url
                    from tool_resource_binding
                    where tenant_id=%s and tool=%s and resource_type=%s
                      and external_id=%s and coalesce(external_sub_id,'')=coalesce(%s,'')
                    limit 1
                    ''',
                    (tenant_id, tool, resource_type, external_id, external_sub_id),
                )
                row = cur.fetchone()
                if row and row.get('platform_resource_id'):
                    if external_url and external_url != row.get('external_url'):
                        cur.execute(
                            '''
                            update tool_resource_binding
                            set external_url=%s, updated_at=now()
                            where tenant_id=%s and tool=%s and resource_type=%s
                              and external_id=%s and coalesce(external_sub_id,'')=coalesce(%s,'')
                            ''',
                            (external_url, tenant_id, tool, resource_type, external_id, external_sub_id),
                        )
                    return str(row['platform_resource_id'])

                platform_id = f'{id_prefix}-{uuid.uuid4().hex}'
                cur.execute(
                    '''
                    insert into tool_resource_binding(
                      tenant_id, platform_resource_id, resource_type, tool,
                      external_id, external_sub_id, external_url
                    )
                    values (%s,%s,%s,%s,%s,%s,%s)
                    on conflict do nothing
                    ''',
                    (tenant_id, platform_id, resource_type, tool, external_id, external_sub_id, external_url),
                )

                cur.execute(
                    '''
                    select platform_resource_id
                    from tool_resource_binding
                    where tenant_id=%s and tool=%s and resource_type=%s
                      and external_id=%s and coalesce(external_sub_id,'')=coalesce(%s,'')
                    limit 1
                    ''',
                    (tenant_id, tool, resource_type, external_id, external_sub_id),
                )
                row2 = cur.fetchone()
                return str(row2['platform_resource_id']) if row2 and row2.get('platform_resource_id') else platform_id
    finally:
        put_conn(conn)


def get_or_create_job_id_for_airflow_run(
    tenant_id: str,
    dag_id: str,
    dag_run_id: str,
    external_url: str | None = None,
) -> str:
    return get_or_create_binding_id(
        tenant_id,
        'airflow',
        'job_run',
        dag_id,
        dag_run_id,
        external_url,
        id_prefix='JOB',
    )


def get_or_create_job_id_for_airbyte_job(
    tenant_id: str,
    airbyte_job_id: str,
    airbyte_connection_id: str | None = None,
    external_url: str | None = None,
) -> str:
    return get_or_create_binding_id(
        tenant_id,
        'airbyte',
        'job_run',
        airbyte_job_id,
        airbyte_connection_id,
        external_url,
        id_prefix='JOB',
    )


def get_job(tenant_id: str, job_id: str) -> Optional[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                '''
                select *
                from job_summary_index
                where tenant_id=%s and job_id=%s
                limit 1
                ''',
                (tenant_id, job_id),
            )
            row = cur.fetchone()
            return dict(row) if row else None
    finally:
        put_conn(conn)


def list_jobs(tenant_id: str, limit: int = 50) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                '''
                select * from job_summary_index
                where tenant_id=%s
                order by created_at desc
                limit %s
                ''',
                (tenant_id, limit),
            )
            return [dict(row) for row in cur.fetchall()]
    finally:
        put_conn(conn)


def get_active_jobs_to_poll(tenant_id: str, max_age_minutes: int = 10080, limit: int = 200) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute('select * from sp_get_active_jobs_to_poll(%s,%s,%s)', (tenant_id, max_age_minutes, limit))
            return [dict(row) for row in cur.fetchall()]
    finally:
        put_conn(conn)


def get_sync_state(tenant_id: str, tool: str) -> dict[str, Any]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                "select coalesce(sp_get_sync_state(%s,%s), '{}'::jsonb) as cursor_json",
                (tenant_id, tool),
            )
            row = cur.fetchone()
            return dict(row['cursor_json'] or {}) if row else {}
    finally:
        put_conn(conn)


def upsert_sync_state(
    tenant_id: str,
    tool: str,
    cursor_json: dict[str, Any],
    last_error: str | None = None,
    success: bool = True,
) -> None:
    conn = get_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    'select sp_upsert_sync_state(%s,%s,%s::jsonb,%s,%s)',
                    (
                        tenant_id,
                        tool,
                        json.dumps(cursor_json),
                        last_error,
                        success,
                    ),
                )
    finally:
        put_conn(conn)


def upsert_connection_summary(
    tenant_id: str,
    connection_id: str,
    airbyte_connection_id: str,
    connection_name: str,
    *,
    source_name: str | None = None,
    destination_name: str | None = None,
    schedule_type: str | None = None,
    schedule_value: str | None = None,
    last_sync_status: str | None = None,
    last_sync_started_at: datetime | None = None,
    last_sync_ended_at: datetime | None = None,
    created_by_user_id: str | None = None,
    updated_by_user_id: str | None = None,
    created_at: datetime | None = None,
    seen_at: datetime | None = None,
) -> None:
    conn = get_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    select sp_upsert_connection_summary_index(
                      %s,%s,%s,
                      %s,%s,%s,%s,%s,
                      %s,%s,%s,
                      %s,%s,%s,%s
                    )
                    ''',
                    (
                        tenant_id,
                        connection_id,
                        airbyte_connection_id,
                        connection_name,
                        source_name,
                        destination_name,
                        schedule_type,
                        schedule_value,
                        last_sync_status,
                        last_sync_started_at,
                        last_sync_ended_at,
                        created_by_user_id,
                        updated_by_user_id,
                        created_at or utc_now(),
                        seen_at or utc_now(),
                    ),
                )
    finally:
        put_conn(conn)


def get_or_create_connection_id_for_airbyte_connection(
    tenant_id: str,
    airbyte_connection_id: str,
    external_url: str | None = None,
) -> str:
    return get_or_create_binding_id(
        tenant_id,
        'airbyte',
        'connection',
        airbyte_connection_id,
        None,
        external_url,
        id_prefix='CONN',
    )


def list_sftp_server_configs(tenant_id: str | None = None, enabled_only: bool = False) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            clauses: list[str] = []
            params: list[Any] = []
            if tenant_id:
                clauses.append('tenant_id=%s')
                params.append(tenant_id)
            if enabled_only:
                clauses.append('enabled=true')
            where = f"where {' and '.join(clauses)}" if clauses else ''
            cur.execute(
                f'''
                select server_id, tenant_id, server_code, display_name, scope_type, scope_key, host, port, public_base_url,
                       root_path, export_root, read_only, auth_mode, enabled, sftpgo_enabled, username_template,
                       home_subdir_template, metadata_json, created_at, updated_at
                from sftp_server_config
                {where}
                order by tenant_id asc,
                         case scope_type when 'user' then 1 when 'team' then 2 when 'tenant' then 3 else 4 end asc,
                         server_code asc
                ''' ,
                tuple(params),
            )
            rows = [dict(row) for row in cur.fetchall()]
            for row in rows:
                row['metadata_json'] = _parse_json_object(row.get('metadata_json'))
            return rows
    except Exception:
        return []
    finally:
        put_conn(conn)


def get_sftp_server_config(server_id: int) -> Optional[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            cur.execute(
                '''
                select server_id, tenant_id, server_code, display_name, scope_type, scope_key, host, port, public_base_url,
                       root_path, export_root, read_only, auth_mode, enabled, sftpgo_enabled, username_template,
                       home_subdir_template, password_secret, metadata_json, created_at, updated_at
                from sftp_server_config
                where server_id=%s
                limit 1
                ''',
                (server_id,),
            )
            row = cur.fetchone()
            if not row:
                return None
            item = dict(row)
            item['metadata_json'] = _parse_json_object(item.get('metadata_json'))
            return item
    except Exception:
        return None
    finally:
        put_conn(conn)


def upsert_sftp_server_config(
    tenant_id: str,
    server_code: str,
    display_name: str,
    scope_type: str,
    scope_key: str,
    host: str,
    port: int,
    public_base_url: str | None,
    root_path: str,
    export_root: str,
    read_only: bool,
    auth_mode: str,
    enabled: bool,
    sftpgo_enabled: bool,
    username_template: str | None,
    home_subdir_template: str | None,
    password_secret: str | None,
    metadata_json: dict[str, Any] | None = None,
) -> dict[str, Any]:
    conn = get_conn()
    try:
        with conn:
            with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
                cur.execute(
                    '''
                    insert into sftp_server_config(
                        tenant_id, server_code, display_name, scope_type, scope_key, host, port, public_base_url,
                        root_path, export_root, read_only, auth_mode, enabled, sftpgo_enabled,
                        username_template, home_subdir_template, password_secret, metadata_json
                    )
                    values (%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
                    on conflict (tenant_id, scope_type, scope_key, server_code) do update
                    set display_name=excluded.display_name,
                        scope_type=excluded.scope_type,
                        scope_key=excluded.scope_key,
                        host=excluded.host,
                        port=excluded.port,
                        public_base_url=excluded.public_base_url,
                        root_path=excluded.root_path,
                        export_root=excluded.export_root,
                        read_only=excluded.read_only,
                        auth_mode=excluded.auth_mode,
                        enabled=excluded.enabled,
                        sftpgo_enabled=excluded.sftpgo_enabled,
                        username_template=excluded.username_template,
                        home_subdir_template=excluded.home_subdir_template,
                        password_secret=excluded.password_secret,
                        metadata_json=excluded.metadata_json,
                        updated_at=now()
                    returning server_id, tenant_id, server_code, display_name, scope_type, scope_key, host, port, public_base_url,
                              root_path, export_root, read_only, auth_mode, enabled, sftpgo_enabled, username_template,
                              home_subdir_template, metadata_json, created_at, updated_at
                    ''',
                    (
                        tenant_id,
                        server_code,
                        display_name,
                        scope_type,
                        scope_key,
                        host,
                        port,
                        public_base_url,
                        root_path,
                        export_root,
                        read_only,
                        auth_mode,
                        enabled,
                        sftpgo_enabled,
                        username_template,
                        home_subdir_template,
                        password_secret,
                        json.dumps(metadata_json or {}),
                    ),
                )
                row = cur.fetchone()
                item = dict(row)
                item['metadata_json'] = _parse_json_object(item.get('metadata_json'))
                return item
    finally:
        put_conn(conn)


def delete_sftp_server_config(server_id: int) -> bool:
    conn = get_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute('delete from sftp_server_config where server_id=%s', (server_id,))
                return cur.rowcount > 0
    except Exception:
        return False
    finally:
        put_conn(conn)


def list_matching_sftp_server_configs(
    tenant_id: str,
    *,
    team: str | None = None,
    user_id: str | None = None,
) -> list[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            clauses = ['tenant_id=%s', 'enabled=true']
            params: list[Any] = [tenant_id]
            scope_checks: list[str] = []
            if user_id:
                scope_checks.append("(scope_type='user' and scope_key=%s)")
                params.append(user_id)
            if team:
                scope_checks.append("(scope_type='team' and scope_key=%s)")
                params.append(team)
            scope_checks.append("(scope_type='tenant' and scope_key=%s)")
            params.append(tenant_id)
            clauses.append('(' + ' or '.join(scope_checks) + ')')
            sql = (
                "select server_id, tenant_id, server_code, display_name, scope_type, scope_key, host, port, public_base_url, "
                "root_path, export_root, read_only, auth_mode, enabled, sftpgo_enabled, username_template, "
                "home_subdir_template, metadata_json, created_at, updated_at "
                "from sftp_server_config "
                f"where {' and '.join(clauses)} "
                "order by case scope_type when 'user' then 1 when 'team' then 2 when 'tenant' then 3 else 4 end asc, "
                "updated_at desc, server_code asc"
            )
            cur.execute(sql, tuple(params))
            rows = [dict(row) for row in cur.fetchall()]
            for row in rows:
                row['metadata_json'] = _parse_json_object(row.get('metadata_json'))
            return rows
    except Exception:
        return []
    finally:
        put_conn(conn)

def find_best_sftp_server_config(
    tenant_id: str,
    *,
    team: str | None = None,
    user_id: str | None = None,
    requested_server_code: str | None = None,
) -> Optional[dict[str, Any]]:
    conn = get_conn()
    try:
        with conn.cursor(cursor_factory=psycopg2.extras.RealDictCursor) as cur:
            if requested_server_code:
                cur.execute(
                    '''
                    select *
                    from sftp_server_config
                    where tenant_id=%s and server_code=%s and enabled=true
                    limit 1
                    ''',
                    (tenant_id, requested_server_code),
                )
                row = cur.fetchone()
                if row:
                    item = dict(row)
                    item['metadata_json'] = _parse_json_object(item.get('metadata_json'))
                    return item

            candidates: list[tuple[str, str]] = []
            if user_id:
                candidates.append(('user', user_id))
            if team:
                candidates.append(('team', team))
            candidates.append(('tenant', tenant_id))

            for scope_type, scope_key in candidates:
                cur.execute(
                    '''
                    select *
                    from sftp_server_config
                    where tenant_id=%s and enabled=true and scope_type=%s and scope_key=%s
                    order by case when server_code=%s then 0 else 1 end,
                             updated_at desc,
                             server_id desc
                    limit 1
                    ''',
                    (tenant_id, scope_type, scope_key, settings.SFTP_DEFAULT_SERVER_CODE or 'default'),
                )
                row = cur.fetchone()
                if row:
                    item = dict(row)
                    item['metadata_json'] = _parse_json_object(item.get('metadata_json'))
                    return item
            return None
    except Exception:
        return None
    finally:
        put_conn(conn)
