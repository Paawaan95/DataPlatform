create table if not exists sftp_server_config (
  server_id bigserial primary key,
  tenant_id text not null references tenant(tenant_id),
  server_code text not null,
  display_name text not null,
  scope_type text not null default 'tenant',
  scope_key text not null,
  host text not null,
  port integer not null default 22,
  public_base_url text,
  root_path text not null default '/exports',
  export_root text not null default '/srv/sftpgo/data/exports',
  read_only boolean not null default true,
  auth_mode text not null default 'password',
  enabled boolean not null default true,
  sftpgo_enabled boolean not null default true,
  username_template text,
  home_subdir_template text,
  password_secret text,
  metadata_json jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint chk_sftp_server_scope_type check (scope_type in ('tenant','team','user')),
  unique (tenant_id, scope_type, scope_key, server_code)
);

create index if not exists idx_sftp_server_scope on sftp_server_config(tenant_id, scope_type, scope_key, enabled);
create index if not exists idx_sftp_server_code on sftp_server_config(tenant_id, server_code, enabled);
