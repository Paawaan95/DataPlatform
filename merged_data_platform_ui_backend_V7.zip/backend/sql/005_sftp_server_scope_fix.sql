alter table if exists sftp_server_config
  drop constraint if exists sftp_server_config_tenant_id_server_code_key;

alter table if exists sftp_server_config
  drop constraint if exists chk_sftp_server_scope_type;

alter table if exists sftp_server_config
  add constraint chk_sftp_server_scope_type
  check (scope_type in ('tenant','team','user'));

create unique index if not exists uq_sftp_server_scope_code
  on sftp_server_config(tenant_id, scope_type, scope_key, server_code);

create index if not exists idx_sftp_server_code
  on sftp_server_config(tenant_id, server_code, enabled);
