# Patch V5 complete upgrade notes

This patch preserves the working Jobs Summary -> clickable Job Id -> Job Details flow and adds targeted upgrades:
- startup config warnings for broken MinIO public endpoint setups
- multi-server SFTP registry table and admin CRUD API
- SFTPGo provisioning resolved through tenant/team/user scoped server config
- Streamlit admin page for SFTP server management
- smoke test assertion for MINIO_PUBLIC_ENDPOINT in presigned URLs

Apply backend/sql/004_sftp_server_config.sql before using the new SFTP server admin APIs.
