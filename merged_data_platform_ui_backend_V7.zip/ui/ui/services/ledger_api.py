from __future__ import annotations

from typing import Any

import pandas as pd
import requests
import streamlit as st

from ui import settings
from ui.links import make_open_job_link


DEFAULT_TIMEOUT_SECONDS = 10.0
LINEAGE_COLUMNS = [
    "Edge Id",
    "From Type",
    "From Id",
    "To Type",
    "To Id",
    "Relation",
    "Created At",
]


def ledger_api_enabled() -> bool:
    return settings.env_str("LEDGER_API_ENABLED", "true").strip().lower() not in {"0", "false", "no", "off"}



def ledger_api_base_url() -> str:
    return settings.env_str("LEDGER_API_BASE_URL", "http://localhost:8199").rstrip("/")



def _timeout_seconds() -> float:
    try:
        return float(settings.env_str("LEDGER_API_TIMEOUT_SECONDS", str(DEFAULT_TIMEOUT_SECONDS)))
    except ValueError:
        return DEFAULT_TIMEOUT_SECONDS



def _fallback_tenants() -> list[str]:
    raw = settings.env_str("LEDGER_TENANTS", "")
    tenants = [item.strip() for item in raw.split(",") if item.strip()]
    return tenants or [settings.LEDGER_DEFAULT_TENANT]



def _auth_headers() -> dict[str, str]:
    headers: dict[str, str] = {}
    auth_mode = settings.env_str("LEDGER_API_AUTH_MODE", "NONE").strip().upper()
    token = settings.env_str("LEDGER_API_TOKEN", "")
    api_key = settings.env_str("LEDGER_API_KEY", "")

    if auth_mode == "BEARER" and token:
        headers["Authorization"] = f"Bearer {token}"
    elif auth_mode == "API_KEY" and api_key:
        header_name = settings.env_str("LEDGER_API_KEY_HEADER", "X-Platform-API-Key")
        prefix = settings.env_str("LEDGER_API_KEY_PREFIX", "")
        headers[header_name] = f"{prefix} {api_key}".strip() if prefix else api_key
    return headers



def _headers(tenant_id: str | None = None) -> dict[str, str]:
    headers = {"Accept": "application/json", **_auth_headers()}
    if tenant_id:
        headers["X-Tenant-ID"] = tenant_id
    return headers



def _remember_error(message: str | None):
    st.session_state.ledger_api_error = message



def _clean_text(value: Any) -> str:
    return "" if value is None else str(value).strip()



def _format_timestamp(value: Any) -> str:
    if value in (None, ""):
        return ""
    try:
        return str(pd.to_datetime(value, utc=True))
    except Exception:
        return str(value)



def _preferred_display_label(explicit_label: Any, job_type: str, job_name: str, system_name: str, system_type: str, job_id: str) -> str:
    explicit = _clean_text(explicit_label)
    if explicit:
        return explicit
    if job_name:
        return f"{job_type} - {job_name}" if job_type else job_name
    if system_name:
        return system_name
    if system_type:
        return system_type
    return job_id



def _normalize_lineage_rows(payload: Any) -> pd.DataFrame:
    if isinstance(payload, dict):
        rows = payload.get("edges") or payload.get("items") or payload.get("rows") or []
    elif isinstance(payload, list):
        rows = payload
    else:
        rows = []

    normalized: list[dict[str, str]] = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        normalized.append(
            {
                "Edge Id": _clean_text(row.get("Edge Id") or row.get("edge_id") or row.get("id")),
                "From Type": _clean_text(row.get("From Type") or row.get("from_type") or row.get("fromType")),
                "From Id": _clean_text(row.get("From Id") or row.get("from_id") or row.get("fromId")),
                "To Type": _clean_text(row.get("To Type") or row.get("to_type") or row.get("toType")),
                "To Id": _clean_text(row.get("To Id") or row.get("to_id") or row.get("toId")),
                "Relation": _clean_text(row.get("Relation") or row.get("relation")),
                "Created At": _format_timestamp(row.get("Created At") or row.get("created_at") or row.get("createdAt")),
            }
        )

    df = pd.DataFrame(normalized, columns=LINEAGE_COLUMNS)
    if not df.empty:
        sort_key = pd.to_datetime(df["Created At"], utc=True, errors="coerce")
        df = df.assign(__sort_key=sort_key).sort_values("__sort_key", ascending=False, kind="stable").drop(columns=["__sort_key"])
    return df



def _request_json(method: str, path: str, *, tenant_id: str | None = None, params: dict[str, Any] | None = None, json_body: dict[str, Any] | None = None) -> Any:
    response = requests.request(
        method,
        f"{ledger_api_base_url()}{path}",
        headers=_headers(tenant_id),
        params=params,
        json=json_body,
        timeout=_timeout_seconds(),
    )
    response.raise_for_status()
    return response.json()



def fetch_available_tenants() -> list[str]:
    if not ledger_api_enabled():
        tenants = _fallback_tenants()
        st.session_state.available_tenants = tenants
        return tenants
    try:
        rows = _request_json("GET", "/v1/admin/tenants") or []
        tenants = [str(row.get("tenant_id")).strip() for row in rows if str(row.get("tenant_id", "")).strip()]
        tenants = tenants or _fallback_tenants()
        st.session_state.available_tenants = tenants
        _remember_error(None)
        return tenants
    except Exception as exc:
        tenants = _fallback_tenants()
        st.session_state.available_tenants = tenants
        _remember_error(f"Ledger API tenant lookup failed: {exc}")
        return tenants



def jobs_dataframe_from_api(tenant_id: str, limit: int = 200) -> pd.DataFrame:
    if not ledger_api_enabled():
        return pd.DataFrame()
    try:
        rows = _request_json("GET", "/v1/jobs", tenant_id=tenant_id, params={"limit": limit}) or []
        _remember_error(None)
        return normalize_jobs(rows)
    except Exception as exc:
        _remember_error(f"Ledger API jobs lookup failed for tenant '{tenant_id}': {exc}")
        return pd.DataFrame()



def fetch_job_detail(tenant_id: str, job_id: str) -> dict[str, Any] | None:
    if not ledger_api_enabled() or not job_id:
        return None
    try:
        row = _request_json("GET", f"/v1/jobs/{job_id}", tenant_id=tenant_id)
        _remember_error(None)
        return row
    except Exception as exc:
        _remember_error(f"Ledger API job detail lookup failed for job '{job_id}': {exc}")
        return None



def fetch_job_lineage(tenant_id: str, job_id: str) -> pd.DataFrame:
    if not ledger_api_enabled() or not job_id:
        return pd.DataFrame(columns=LINEAGE_COLUMNS)
    try:
        payload = _request_json("GET", f"/v1/jobs/{job_id}/lineage", tenant_id=tenant_id) or {}
        _remember_error(None)
        return _normalize_lineage_rows(payload)
    except Exception as exc:
        _remember_error(f"Ledger API lineage lookup failed for job '{job_id}': {exc}")
        return pd.DataFrame(columns=LINEAGE_COLUMNS)



def fetch_job_serving(tenant_id: str, job_id: str) -> dict[str, Any] | None:
    if not ledger_api_enabled() or not job_id:
        return None
    try:
        payload = _request_json("GET", f"/v1/jobs/{job_id}/serving", tenant_id=tenant_id) or {}
        _remember_error(None)
        return payload
    except Exception as exc:
        _remember_error(f"Ledger API serving lookup failed for job '{job_id}': {exc}")
        return None



def fetch_job_objects(tenant_id: str, job_id: str, limit: int = 100, cursor: str | None = None) -> dict[str, Any] | None:
    if not ledger_api_enabled() or not job_id:
        return None
    try:
        params = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        payload = _request_json("GET", f"/v1/jobs/{job_id}/objects", tenant_id=tenant_id, params=params) or {}
        _remember_error(None)
        return payload
    except Exception as exc:
        _remember_error(f"Ledger API object listing failed for job '{job_id}': {exc}")
        return None



def fetch_job_sample_preview(
    tenant_id: str,
    job_id: str,
    limit: int = 20,
    *,
    cursor: str | None = None,
    object_key: str | None = None,
) -> dict[str, Any] | None:
    if not ledger_api_enabled() or not job_id:
        return None
    try:
        params: dict[str, Any] = {"limit": limit}
        if cursor:
            params["cursor"] = cursor
        if object_key:
            params["object_key"] = object_key
        payload = _request_json("GET", f"/v1/jobs/{job_id}/preview", tenant_id=tenant_id, params=params) or {}
        _remember_error(None)
        return payload
    except Exception as exc:
        _remember_error(f"Ledger API preview lookup failed for job '{job_id}': {exc}")
        return None



def fetch_job_download_url(
    tenant_id: str,
    job_id: str,
    *,
    object_key: str | None = None,
    expires_in_seconds: int | None = None,
) -> dict[str, Any] | None:
    if not ledger_api_enabled() or not job_id:
        return None
    try:
        body: dict[str, Any] = {}
        if object_key:
            body["object_key"] = object_key
        if expires_in_seconds is not None:
            body["expires_in_seconds"] = expires_in_seconds
        payload = _request_json("POST", f"/v1/jobs/{job_id}/download-url", tenant_id=tenant_id, json_body=body) or {}
        _remember_error(None)
        return payload
    except Exception as exc:
        _remember_error(f"Ledger API download-url lookup failed for job '{job_id}': {exc}")
        return None



def publish_job_sftp(tenant_id: str, job_id: str, *, object_key: str | None = None) -> dict[str, Any] | None:
    if not ledger_api_enabled() or not job_id:
        return None
    try:
        body: dict[str, Any] = {}
        if object_key:
            body["object_key"] = object_key
        payload = _request_json("POST", f"/v1/jobs/{job_id}/sftp-publish", tenant_id=tenant_id, json_body=body) or {}
        _remember_error(None)
        return payload
    except Exception as exc:
        _remember_error(f"Ledger API SFTP publish failed for job '{job_id}': {exc}")
        return None



def normalize_jobs(rows: list[dict[str, Any]]) -> pd.DataFrame:
    normalized: list[dict[str, Any]] = []
    for row in rows:
        job_id = _clean_text(row.get("job_id"))
        if not job_id:
            continue
        job_type = _clean_text(row.get("job_type")) or "Unknown"
        system_type = _clean_text(row.get("system_type"))
        system_name = _clean_text(row.get("system_name")) or _clean_text(row.get("airflow_dag_id")) or _clean_text(row.get("airbyte_connection_id"))
        job_name = _clean_text(row.get("job_name")) or system_name or _clean_text(row.get("airflow_dag_id")) or _clean_text(row.get("airbyte_job_id")) or job_type
        display_label = _preferred_display_label(row.get("display_label"), job_type, job_name, system_name, system_type, job_id)
        normalized.append(
            {
                "Tenant Id": row.get("tenant_id") or "",
                "Job Id": job_id,
                "Job Name": job_name,
                "System Type": system_type,
                "System Name": system_name,
                "Display Label": display_label,
                "Submitted By": row.get("submitted_by_user_id") or "system",
                "Role": row.get("submitted_by_role") or "System",
                "Team": row.get("submitted_by_team") or "Platform",
                "Visibility": row.get("visibility") or "Global",
                "Job Type": job_type,
                "Orchestrator": row.get("orchestrator") or (system_type.title() if system_type else "Unknown"),
                "Status": row.get("status") or "UNKNOWN",
                "Created At": _format_timestamp(row.get("created_at")),
                "Updated At": _format_timestamp(row.get("updated_at")),
                "Last Seen At": _format_timestamp(row.get("last_seen_at")),
                "Source": row.get("source") or "",
                "Destination": row.get("destination") or "",
                "Result Location": row.get("result_location") or "",
                "Open Job Link": make_open_job_link(job_id),
                "External Job Link": row.get("open_job_link") or "",
                "Airflow DAG Id": row.get("airflow_dag_id") or "",
                "Airflow DAG Run Id": row.get("airflow_dag_run_id") or "",
                "Airbyte Connection Id": row.get("airbyte_connection_id") or "",
                "Airbyte Job Id": row.get("airbyte_job_id") or "",
            }
        )

    df = pd.DataFrame(normalized)
    if not df.empty and "Created At" in df.columns:
        df = df.sort_values("Created At", ascending=False, kind="stable").reset_index(drop=True)
    return df


def list_sftp_servers(tenant_id: str) -> list[dict[str, Any]]:
    if not ledger_api_enabled():
        return []
    try:
        rows = _request_json('GET', '/v1/admin/sftp-servers', tenant_id=tenant_id, params={'tenant_id': tenant_id}) or []
        _remember_error(None)
        return rows if isinstance(rows, list) else []
    except Exception as exc:
        _remember_error(f"Ledger API SFTP server listing failed for tenant '{tenant_id}': {exc}")
        return []


def upsert_sftp_server(payload: dict[str, Any]) -> dict[str, Any] | None:
    tenant_id = str(payload.get('tenant_id') or '').strip()
    if not ledger_api_enabled() or not tenant_id:
        return None
    try:
        row = _request_json('POST', '/v1/admin/sftp-servers', tenant_id=tenant_id, json_body=payload) or {}
        _remember_error(None)
        return row if isinstance(row, dict) else None
    except Exception as exc:
        _remember_error(f"Ledger API SFTP server save failed for tenant '{tenant_id}': {exc}")
        return None


def delete_sftp_server(tenant_id: str, server_id: int) -> bool:
    if not ledger_api_enabled() or not tenant_id:
        return False
    try:
        _request_json('DELETE', f'/v1/admin/sftp-servers/{server_id}', tenant_id=tenant_id)
        _remember_error(None)
        return True
    except Exception as exc:
        _remember_error(f"Ledger API SFTP server delete failed for tenant '{tenant_id}': {exc}")
        return False
