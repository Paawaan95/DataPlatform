from __future__ import annotations

import pandas as pd
import streamlit as st

from ui.services.ledger_api import delete_sftp_server, list_sftp_servers, upsert_sftp_server


def page_sftp_servers():
    st.title('SFTP Servers')
    tenant_id = st.session_state.get('selected_tenant') or ''
    if not tenant_id:
        st.info('Select a tenant to manage SFTP servers.')
        return

    rows = list_sftp_servers(tenant_id)
    if rows:
        display_rows = []
        for row in rows:
            display_rows.append(
                {
                    'Server Id': row.get('server_id'),
                    'Code': row.get('server_code'),
                    'Name': row.get('display_name'),
                    'Scope Type': row.get('scope_type'),
                    'Scope Key': row.get('scope_key'),
                    'Host': row.get('host'),
                    'Port': row.get('port'),
                    'Root Path': row.get('root_path'),
                    'Export Root': row.get('export_root'),
                    'Read Only': row.get('read_only'),
                    'Enabled': row.get('enabled'),
                }
            )
        st.dataframe(pd.DataFrame(display_rows), use_container_width=True, hide_index=True)
    else:
        st.caption('No SFTP server config exists for this tenant yet. The backend will fall back to env defaults until you add one.')

    st.caption('Uniqueness is per tenant + scope type + scope key + server code, so you can keep the same server code pattern across different team/user scopes when needed.')
    st.subheader('Create or update SFTP server')
    with st.form('sftp_server_form'):
        left, right = st.columns(2)
        with left:
            server_code = st.text_input('Server code', value='default')
            display_name = st.text_input('Display name', value='Default SFTP server')
            scope_type = st.selectbox('Scope type', ['tenant', 'team', 'user'], index=0)
            scope_key = st.text_input('Scope key', value=tenant_id)
            host = st.text_input('Host', value='127.0.0.1')
            port = st.number_input('Port', min_value=1, max_value=65535, value=2222, step=1)
        with right:
            public_base_url = st.text_input('Public/admin base URL', value='http://127.0.0.1:8080')
            root_path = st.text_input('Public SFTP root path', value='/exports')
            export_root = st.text_input('Filesystem export root', value='/srv/sftpgo/data/exports')
            username_template = st.text_input('Username template', value='{tenant_id}')
            home_subdir_template = st.text_input('Home subdir template', value='{tenant_id}')
            password_secret = st.text_input('Password seed/secret', value='demo_sftp_password', type='password')
        read_only = st.checkbox('Read only', value=True)
        enabled = st.checkbox('Enabled', value=True)
        sftpgo_enabled = st.checkbox('Managed by SFTPGo', value=True)
        submitted = st.form_submit_button('Save SFTP server')

        if submitted:
            payload = {
                'tenant_id': tenant_id,
                'server_code': server_code.strip(),
                'display_name': display_name.strip() or server_code.strip(),
                'scope_type': scope_type,
                'scope_key': scope_key.strip() or tenant_id,
                'host': host.strip(),
                'port': int(port),
                'public_base_url': public_base_url.strip(),
                'root_path': root_path.strip(),
                'export_root': export_root.strip(),
                'read_only': read_only,
                'auth_mode': 'password',
                'enabled': enabled,
                'sftpgo_enabled': sftpgo_enabled,
                'username_template': username_template.strip(),
                'home_subdir_template': home_subdir_template.strip(),
                'password_secret': password_secret,
                'metadata_json': {},
            }
            saved = upsert_sftp_server(payload)
            if saved:
                st.success(f"Saved SFTP server '{saved.get('server_code')}'")
                st.rerun()
            else:
                st.error('Failed to save SFTP server configuration.')

    if rows:
        st.subheader('Delete SFTP server')
        delete_options = {f"{row.get('server_code')} ({row.get('scope_type')}:{row.get('scope_key')})": row.get('server_id') for row in rows}
        choice = st.selectbox('Select server to delete', options=list(delete_options.keys()))
        if st.button('Delete selected server', type='secondary'):
            ok = delete_sftp_server(tenant_id, int(delete_options[choice]))
            if ok:
                st.success('Deleted SFTP server configuration.')
                st.rerun()
            else:
                st.error('Delete failed.')
