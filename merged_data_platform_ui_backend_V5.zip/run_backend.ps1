$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
docker compose --env-file .env up -d --build
Write-Host "Backend stack started. Check: docker compose ps"
Write-Host "Default API: http://127.0.0.1:8199"
Write-Host "Default MinIO Console: http://127.0.0.1:9001"
