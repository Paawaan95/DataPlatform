# Patch V5 - serving hardening plus production-oriented integration patch

## What changed
- Replaced the local demo SFTP server integration with SFTPGo in Docker Compose and backend publication/provisioning flow.
- Added backend-to-SFTPGo admin integration to provision deterministic per-tenant read-only users.
- Added OIDC/JWKS bearer-token validation support plus stronger claim extraction and scope enforcement.
- Added support for hashed API keys in `API_KEYS_JSON`.
- Added runtime registration support for Airbyte, Trino, Kafka, SQL, and Natural Language jobs alongside Airflow.
- Added Airbyte fast/slow workers for connection discovery and job-status polling.
- Upgraded Parquet preview to use DuckDB against MinIO/S3 first, then fall back to inline PyArrow only when needed.
- Updated env templates and Docker Compose to match SFTPGo, Airbyte, auth, and Parquet-query settings.

## What is materially better now
- SFTP is no longer only a demo container with a shared static login; the backend can provision tenant-specific SFTPGo users with enforced read-only permissions.
- Auth can now validate bearer tokens through OIDC discovery or JWKS instead of only a shared secret.
- Airbyte has real runtime synchronization workers similar in shape to the existing Airflow workers.
- Parquet preview no longer depends only on reading the whole file into memory first.

## What is still intentionally not claimed as complete
- This patch does not claim real enterprise secret-management integration; it still reads credentials from env unless you connect a secret manager outside this repo.
- Trino/Kafka/SQL/NL runtime integrations are stronger and more explicit, but they still depend on your platform actually creating or registering those jobs.
- The Docker stack could not be executed inside this ChatGPT environment because Docker is unavailable here, so the code was patched and syntax-checked but not compose-executed end to end.
