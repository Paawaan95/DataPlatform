# Data Platform Control Ledger - centralized backend

## What changed in this patch
This backend now includes:
- MinIO internal vs public endpoint split for object-serving and presigned browser downloads
- explicit SFTP publish flow backed by SFTPGo provisioning
- OIDC/JWKS-capable bearer-token validation
- hashed API key support
- Airbyte fast/slow workers for runtime sync
- DuckDB-backed Parquet preview
- runtime registration for Airflow, Airbyte, Trino, Kafka, SQL, and NL jobs

## Run
```powershell
cd <repo-root>
Copy-Item .env.example .env -Force
# edit .env as needed

docker compose down
docker compose up -d --build
```

## Most important envs to review
- `API_AUTH_REQUIRED`
- `AUTH_JWKS_URL` or `AUTH_OIDC_DISCOVERY_URL`
- `AUTH_JWT_ISSUER`
- `AUTH_JWT_AUDIENCE`
- `API_KEYS_JSON`
- `AIRFLOW_*`
- `AIRBYTE_*`
- `MINIO_INTERNAL_ENDPOINT`
- `MINIO_PUBLIC_ENDPOINT`
- `MINIO_ACCESS_KEY`
- `MINIO_SECRET_KEY`
- `SFTPGO_*`
- `RESULTS_SFTP_EXPORT_ROOT`
- `PARQUET_QUERY_ENGINE`

## Useful local commands
Seed demo result objects and a demo job row:
```powershell
docker compose exec dp_control_api python /app/scripts/seed_demo_result.py
```

Run serving smoke test:
```powershell
docker compose exec dp_control_api python /app/scripts/smoke_result_serving.py
```

Inspect service logs:
```powershell
docker compose logs --tail=100 dp_control_api
docker compose logs --tail=100 dp_control_fast_worker
docker compose logs --tail=100 dp_control_slow_worker
docker compose logs --tail=100 dp_control_airbyte_fast_worker
docker compose logs --tail=100 dp_control_airbyte_slow_worker
docker compose logs --tail=100 sftpgo
```
