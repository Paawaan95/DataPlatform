import psycopg2
import psycopg2.pool
from app.config import settings

_pool: psycopg2.pool.SimpleConnectionPool | None = None

def init_pool():
    global _pool
    if _pool is None:
        _pool = psycopg2.pool.SimpleConnectionPool(1, 10, dsn=settings.DATABASE_URL)

def get_conn():
    init_pool()
    assert _pool is not None
    return _pool.getconn()

def put_conn(conn):
    assert _pool is not None
    _pool.putconn(conn)
