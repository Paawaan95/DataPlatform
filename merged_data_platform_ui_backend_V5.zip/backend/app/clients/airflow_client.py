from __future__ import annotations

import base64
from typing import Any, Dict, Optional
from urllib.parse import quote

import httpx

from app.config import settings


def _auth_headers(airflow: Dict[str, Any] | None = None) -> Dict[str, str]:
    airflow = airflow or {}
    mode = str(airflow.get('auth_mode') or settings.AIRFLOW_AUTH_MODE or 'none').lower()
    if mode == 'basic':
        username = airflow.get('username') or settings.AIRFLOW_USERNAME
        password = airflow.get('password') or settings.AIRFLOW_PASSWORD
        token = base64.b64encode(f'{username}:{password}'.encode()).decode()
        return {'Authorization': f'Basic {token}'}
    if mode == 'bearer':
        token = airflow.get('bearer_token') or settings.AIRFLOW_BEARER_TOKEN
        if token:
            return {'Authorization': f'Bearer {token}'}
    return {}


def _clean_params(params: Dict[str, Any]) -> Dict[str, Any]:
    return {key: value for key, value in params.items() if value not in (None, '', [])}


async def get_dag_run(airflow: Dict[str, Any], dag_id: str, dag_run_id: str) -> Optional[Dict[str, Any]]:
    url = f"{airflow['base_url'].rstrip('/')}/api/v1/dags/{quote(dag_id, safe='')}/dagRuns/{quote(dag_run_id, safe='')}"
    async with httpx.AsyncClient(timeout=settings.AIRFLOW_HTTP_TIMEOUT_SECONDS, follow_redirects=True) as client:
        r = await client.get(url, headers={'Accept': 'application/json', **_auth_headers(airflow)})
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.json()


async def list_dag_runs(
    airflow: Dict[str, Any],
    dag_id: str,
    limit: int = 50,
    offset: int = 0,
    order_by: str | None = None,
    extra_filters: Dict[str, Any] | None = None,
) -> Dict[str, Any]:
    url = f"{airflow['base_url'].rstrip('/')}/api/v1/dags/{quote(dag_id, safe='')}/dagRuns"
    params = {'limit': limit, 'offset': offset}
    if order_by:
        params['order_by'] = order_by
    if extra_filters:
        params.update(extra_filters)
    params = _clean_params(params)

    async with httpx.AsyncClient(timeout=settings.AIRFLOW_HTTP_TIMEOUT_SECONDS, follow_redirects=True) as client:
        headers = {'Accept': 'application/json', **_auth_headers(airflow)}
        r = await client.get(url, params=params, headers=headers)
        if r.status_code == 400 and extra_filters:
            fallback = {'limit': limit, 'offset': offset}
            if order_by:
                fallback['order_by'] = order_by
            r = await client.get(url, params=fallback, headers=headers)
        if r.status_code == 400 and order_by:
            fallback = {'limit': limit, 'offset': offset}
            r = await client.get(url, params=fallback, headers=headers)
        r.raise_for_status()
        return r.json()


async def list_dags(
    airflow: Dict[str, Any],
    limit: int = 100,
    offset: int = 0,
    only_active: bool = True,
) -> Dict[str, Any]:
    url = f"{airflow['base_url'].rstrip('/')}/api/v1/dags"
    params = {'limit': limit, 'offset': offset}
    if only_active:
        params['only_active'] = True

    async with httpx.AsyncClient(timeout=settings.AIRFLOW_HTTP_TIMEOUT_SECONDS, follow_redirects=True) as client:
        r = await client.get(
            url,
            params=params,
            headers={'Accept': 'application/json', **_auth_headers(airflow)},
        )
        r.raise_for_status()
        return r.json()


def normalize_state(af_json: Dict[str, Any]) -> str:
    state = (af_json.get('state') or '').upper()
    if state == 'SUCCESS':
        return 'SUCCEEDED'
    if state == 'FAILED':
        return 'FAILED'
    if state == 'RUNNING':
        return 'RUNNING'
    if state == 'QUEUED':
        return 'QUEUED'
    return state or 'UNKNOWN'


def airflow_ui_run_link(airflow: Dict[str, Any] | str, dag_id: str, dag_run_id: str) -> str:
    if isinstance(airflow, dict):
        base_url = str(airflow.get('ui_base_url') or airflow.get('base_url') or '').rstrip('/')
    else:
        base_url = str(airflow).rstrip('/')
    return f"{base_url}/dags/{quote(dag_id, safe='')}/grid?dag_run_id={quote(dag_run_id, safe='')}"
