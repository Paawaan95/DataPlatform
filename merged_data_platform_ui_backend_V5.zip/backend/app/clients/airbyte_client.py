from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

import httpx

from app.config import settings


def _headers(airbyte: dict[str, Any]) -> dict[str, str]:
    headers = {'Accept': 'application/json', 'Content-Type': 'application/json'}
    auth_mode = str(airbyte.get('auth_mode') or 'none').lower()
    if auth_mode == 'bearer' and airbyte.get('bearer_token'):
        headers['Authorization'] = f"Bearer {airbyte['bearer_token']}"
    elif auth_mode == 'basic' and airbyte.get('username') and airbyte.get('password'):
        # httpx handles auth separately; kept for compatibility if an upstream proxy expects it.
        pass
    elif airbyte.get('api_key'):
        header_name = str(airbyte.get('api_key_header') or 'Authorization')
        prefix = str(airbyte.get('api_key_prefix') or '').strip()
        token = str(airbyte.get('api_key') or '').strip()
        headers[header_name] = f'{prefix} {token}'.strip() if prefix else token
    return headers


def _auth(airbyte: dict[str, Any]):
    auth_mode = str(airbyte.get('auth_mode') or 'none').lower()
    if auth_mode == 'basic' and airbyte.get('username') and airbyte.get('password'):
        return (airbyte['username'], airbyte['password'])
    return None


def _client(airbyte: dict[str, Any]) -> httpx.Client:
    return httpx.Client(
        base_url=str(airbyte['base_url']).rstrip('/'),
        headers=_headers(airbyte),
        auth=_auth(airbyte),
        timeout=settings.AIRBYTE_HTTP_TIMEOUT_SECONDS,
    )


def airbyte_ui_job_link(airbyte: dict[str, Any], connection_id: str | None = None, job_id: str | None = None) -> str:
    base = str(airbyte.get('ui_base_url') or airbyte.get('base_url') or '').rstrip('/')
    if connection_id:
        return f'{base}/connections/{connection_id}'
    if job_id:
        return f'{base}/jobs/{job_id}'
    return base


def _job_from_payload(payload: dict[str, Any]) -> dict[str, Any]:
    return payload.get('job') if isinstance(payload.get('job'), dict) else payload


def _parse_ms(value: Any) -> datetime | None:
    if value in (None, ''):
        return None
    try:
        return datetime.fromtimestamp(int(value) / 1000.0, tz=timezone.utc)
    except Exception:
        return None


def normalize_airbyte_status(payload: dict[str, Any]) -> str:
    job = _job_from_payload(payload)
    status = str(job.get('status') or job.get('jobStatus') or '').upper()
    if status in {'SUCCEEDED', 'SUCCESS'}:
        return 'SUCCEEDED'
    if status in {'FAILED', 'ERROR'}:
        return 'FAILED'
    if status in {'RUNNING'}:
        return 'RUNNING'
    if status in {'PENDING', 'INCOMPLETE'}:
        return 'QUEUED'
    return status or 'UNKNOWN'


def job_timestamps(payload: dict[str, Any]) -> tuple[datetime | None, datetime | None]:
    job = _job_from_payload(payload)
    started = _parse_ms(job.get('startedAt') or job.get('startTime') or job.get('createdAt'))
    ended = _parse_ms(job.get('endedAt') or job.get('endTime'))
    return started, ended


def list_connections(airbyte: dict[str, Any]) -> list[dict[str, Any]]:
    body: dict[str, Any] = {}
    if airbyte.get('workspace_id'):
        body['workspaceId'] = airbyte['workspace_id']
    with _client(airbyte) as client:
        response = client.post('/api/v1/connections/list', json=body)
        response.raise_for_status()
        payload = response.json()
    rows = payload.get('connections') if isinstance(payload, dict) else None
    return [row for row in (rows or []) if isinstance(row, dict)]


def get_job(airbyte: dict[str, Any], job_id: str) -> dict[str, Any] | None:
    if not job_id:
        return None
    with _client(airbyte) as client:
        response = client.post('/api/v1/jobs/get', json={'id': int(job_id) if str(job_id).isdigit() else job_id})
        if response.status_code == 404:
            return None
        response.raise_for_status()
        payload = response.json()
    return payload if isinstance(payload, dict) else None


def list_jobs_for_connection(airbyte: dict[str, Any], connection_id: str) -> list[dict[str, Any]]:
    body = {'configTypes': ['sync'], 'connectionId': connection_id, 'pagination': {'pageSize': settings.AIRBYTE_JOB_LIST_LIMIT}}
    with _client(airbyte) as client:
        response = client.post('/api/v1/jobs/list', json=body)
        response.raise_for_status()
        payload = response.json()
    jobs = payload.get('jobs') if isinstance(payload, dict) else None
    return [row for row in (jobs or []) if isinstance(row, dict)]
