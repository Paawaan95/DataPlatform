from __future__ import annotations

from typing import Any

from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

from app.config import settings
from app.sql_repo import call_bootstrap, get_tenant, list_tenants, list_tool_instances

router = APIRouter()


class BootstrapRequest(BaseModel):
    tenant_id: str
    tenant_name: str = Field(default_factory=lambda: settings.DEFAULT_TENANT_NAME)
    airflow_base_url: str = Field(default_factory=lambda: settings.AIRFLOW_BASE_URL)
    airbyte_base_url: str | None = Field(default_factory=lambda: settings.AIRBYTE_BASE_URL)

    airflow_ui_base_url: str | None = Field(default_factory=lambda: settings.AIRFLOW_UI_BASE_URL)
    airflow_auth_mode: str | None = Field(default_factory=lambda: settings.AIRFLOW_AUTH_MODE)
    airflow_username: str | None = None
    airflow_password: str | None = None
    airflow_bearer_token: str | None = None
    airflow_username_env: str | None = None
    airflow_password_env: str | None = None
    airflow_bearer_token_env: str | None = None
    airflow_discovery_dag_ids: list[str] | None = None
    airflow_job_type_map: dict[str, str] | None = None
    airflow_default_visibility: str | None = Field(default=None, description='Private | Team | Global')
    airflow_discovery_run_type_filter: str | None = Field(default=None, description='all | manual_only | scheduled_only')
    airbyte_ui_base_url: str | None = Field(default_factory=lambda: settings.AIRBYTE_UI_BASE_URL)
    airbyte_auth_mode: str | None = Field(default_factory=lambda: settings.AIRBYTE_AUTH_MODE)
    airbyte_username: str | None = None
    airbyte_password: str | None = None
    airbyte_bearer_token: str | None = None
    airbyte_api_key: str | None = None
    airbyte_api_key_header: str | None = Field(default_factory=lambda: settings.AIRBYTE_API_KEY_HEADER)
    airbyte_api_key_prefix: str | None = Field(default_factory=lambda: settings.AIRBYTE_API_KEY_PREFIX)
    airbyte_workspace_id: str | None = Field(default_factory=lambda: settings.AIRBYTE_WORKSPACE_ID)
    airbyte_job_type_map: dict[str, str] | None = None
    airbyte_default_visibility: str | None = Field(default=None, description='Private | Team | Global')


class ActivateTenantRequest(BaseModel):
    is_active: bool = True


def _compact_dict(raw: dict[str, Any]) -> dict[str, Any]:
    return {key: value for key, value in raw.items() if value not in (None, '', [], {})}


@router.post('/bootstrap')
def bootstrap(req: BootstrapRequest):
    airflow_auth_ref = _compact_dict(
        {
            'ui_base_url': req.airflow_ui_base_url,
            'auth_mode': req.airflow_auth_mode,
            'username': req.airflow_username,
            'password': req.airflow_password,
            'bearer_token': req.airflow_bearer_token,
            'username_env': req.airflow_username_env,
            'password_env': req.airflow_password_env,
            'bearer_token_env': req.airflow_bearer_token_env,
            'discovery_dag_ids': req.airflow_discovery_dag_ids,
            'job_type_map': req.airflow_job_type_map,
            'default_visibility': req.airflow_default_visibility,
            'discovery_run_type_filter': req.airflow_discovery_run_type_filter,
        }
    )

    airbyte_auth_ref = _compact_dict(
        {
            'ui_base_url': req.airbyte_ui_base_url,
            'auth_mode': req.airbyte_auth_mode,
            'username': req.airbyte_username,
            'password': req.airbyte_password,
            'bearer_token': req.airbyte_bearer_token,
            'api_key': req.airbyte_api_key,
            'api_key_header': req.airbyte_api_key_header,
            'api_key_prefix': req.airbyte_api_key_prefix,
            'workspace_id': req.airbyte_workspace_id,
            'job_type_map': req.airbyte_job_type_map,
            'default_visibility': req.airbyte_default_visibility,
        }
    )

    call_bootstrap(
        tenant_id=req.tenant_id,
        tenant_name=req.tenant_name,
        airflow_base_url=req.airflow_base_url,
        airbyte_base_url=req.airbyte_base_url,
        airflow_auth_ref=airflow_auth_ref or None,
        airbyte_auth_ref=airbyte_auth_ref or None,
    )
    return {
        'ok': True,
        'tenant_id': req.tenant_id,
        'airflow_base_url': req.airflow_base_url,
        'airbyte_base_url': req.airbyte_base_url,
    }


@router.get('/tenants')
def tenants(active_only: bool = True):
    return list_tenants(active_only=active_only)


@router.get('/tenants/{tenant_id}')
def tenant_detail(tenant_id: str):
    row = get_tenant(tenant_id)
    if not row:
        raise HTTPException(status_code=404, detail=f'Tenant {tenant_id} not found')
    return row


@router.get('/tool-instances')
def tool_instances(tenant_id: str | None = Query(default=None), active_only: bool = True):
    return list_tool_instances(tenant_id=tenant_id, active_only=active_only)
