from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from app.auth import AccessContext, access_dependency, can_read_job
from app.clients.airbyte_client import airbyte_ui_job_link
from app.clients.airflow_client import airflow_ui_run_link
from app.config import settings
from app.result_repo import record_result_access_audit
from app.services.lineage import fallback_lineage_for_job
from app.services.object_store import (
    build_serving_descriptor,
    create_presigned_download,
    list_job_objects,
    preview_result_object,
)
from app.services.sftp_export import get_sftp_publication_status, publish_result_to_sftp
from app.sql_repo import (
    fetch_tool_instance,
    get_job,
    get_or_create_binding_id,
    get_or_create_job_id_for_airbyte_job,
    get_or_create_job_id_for_airflow_run,
    list_jobs,
    log_event,
    upsert_job_summary,
    utc_now,
)

router = APIRouter()


class RegisterRequest(BaseModel):
    airflow_dag_id: str
    airflow_dag_run_id: str
    job_type: str = 'Unknown'
    status: str = 'RUNNING'
    visibility: str = 'Private'
    submitted_by_user_id: str | None = None
    submitted_by_role: str | None = None
    submitted_by_team: str | None = None
    source: str | None = None
    destination: str | None = None
    result_location: str | None = None
    open_job_link: str | None = None
    created_at: datetime | None = None


class RuntimeRegisterRequest(BaseModel):
    tool: Literal['airflow', 'airbyte', 'trino', 'kafka', 'sql', 'nl']
    external_id: str = Field(description='Authoritative external identifier, such as Airbyte job id or Trino query id')
    external_sub_id: str | None = Field(default=None, description='Optional sub identifier, such as Airflow dag_run_id or Airbyte connection id')
    job_type: str = 'Unknown'
    orchestrator: str | None = None
    status: str = 'RUNNING'
    visibility: str = 'Private'
    submitted_by_user_id: str | None = None
    submitted_by_role: str | None = None
    submitted_by_team: str | None = None
    source: str | None = None
    destination: str | None = None
    result_location: str | None = None
    open_job_link: str | None = None
    created_at: datetime | None = None


class DownloadUrlRequest(BaseModel):
    object_key: str | None = Field(default=None, description='Optional explicit object to download when a job produced multiple files')
    expires_in_seconds: int | None = Field(default=None, ge=60, le=3600)


class SftpPublishRequest(BaseModel):
    object_key: str | None = Field(default=None, description='Optional explicit object to publish when a job produced multiple files')


TERMINAL_STATUSES = {'SUCCEEDED', 'FAILED', 'CANCELLED', 'SKIPPED'}


def _readable_job_or_404(tenant_id: str, job_id: str, ctx: AccessContext) -> dict[str, Any]:
    row = get_job(tenant_id, job_id)
    if not row:
        raise HTTPException(status_code=404, detail=f'Job {job_id} not found for tenant {tenant_id}')
    if not can_read_job(ctx, row):
        raise HTTPException(status_code=403, detail=f'Job {job_id} is not visible to the current principal')
    return row


def _default_orchestrator(tool: str) -> str:
    mapping = {
        'airflow': 'Airflow',
        'airbyte': 'Airbyte',
        'trino': 'Trino',
        'kafka': 'Kafka',
        'sql': 'SQL',
        'nl': 'Natural Language',
    }
    return mapping.get(tool, tool.title())


@router.post('/jobs/register')
def register(req: RegisterRequest, ctx: AccessContext = Depends(access_dependency('jobs:register'))):
    tenant_id = ctx.tenant_id
    airflow = fetch_tool_instance(tenant_id, 'airflow')
    open_job_link = req.open_job_link
    if not open_job_link and airflow:
        open_job_link = airflow_ui_run_link(airflow, req.airflow_dag_id, req.airflow_dag_run_id)

    job_id = get_or_create_job_id_for_airflow_run(
        tenant_id,
        req.airflow_dag_id,
        req.airflow_dag_run_id,
        external_url=open_job_link,
    )

    created_at = req.created_at or utc_now()
    upsert_job_summary(
        tenant_id=tenant_id,
        job_id=job_id,
        job_type=req.job_type,
        orchestrator='Airflow',
        status=req.status,
        visibility=req.visibility,
        submitted_by_user_id=req.submitted_by_user_id,
        submitted_by_role=req.submitted_by_role,
        submitted_by_team=req.submitted_by_team,
        source=req.source,
        destination=req.destination,
        result_location=req.result_location,
        open_job_link=open_job_link,
        airflow_dag_id=req.airflow_dag_id,
        airflow_dag_run_id=req.airflow_dag_run_id,
        created_at=created_at,
    )
    log_event(
        tenant_id,
        'airflow',
        'REGISTER_DAG_RUN',
        external_id=req.airflow_dag_id,
        external_sub_id=req.airflow_dag_run_id,
        payload={'job_id': job_id, 'status': req.status, 'visibility': req.visibility},
    )
    return {
        'tenant_id': tenant_id,
        'job_id': job_id,
        'airflow_dag_id': req.airflow_dag_id,
        'airflow_dag_run_id': req.airflow_dag_run_id,
        'status': req.status,
        'open_job_link': open_job_link,
    }


@router.post('/jobs/register-runtime')
def register_runtime(req: RuntimeRegisterRequest, ctx: AccessContext = Depends(access_dependency('jobs:register'))):
    tenant_id = ctx.tenant_id
    tool = req.tool.lower()
    created_at = req.created_at or utc_now()
    orchestrator = req.orchestrator or _default_orchestrator(tool)
    open_job_link = req.open_job_link

    if tool == 'airflow':
        if not req.external_sub_id:
            raise HTTPException(status_code=400, detail='external_sub_id is required for airflow runtime registration')
        airflow = fetch_tool_instance(tenant_id, 'airflow')
        if not open_job_link and airflow:
            open_job_link = airflow_ui_run_link(airflow, req.external_id, req.external_sub_id)
        job_id = get_or_create_job_id_for_airflow_run(tenant_id, req.external_id, req.external_sub_id, external_url=open_job_link)
        upsert_job_summary(
            tenant_id=tenant_id,
            job_id=job_id,
            job_type=req.job_type,
            orchestrator=orchestrator,
            status=req.status,
            visibility=req.visibility,
            submitted_by_user_id=req.submitted_by_user_id,
            submitted_by_role=req.submitted_by_role,
            submitted_by_team=req.submitted_by_team,
            source=req.source,
            destination=req.destination,
            result_location=req.result_location,
            open_job_link=open_job_link,
            airflow_dag_id=req.external_id,
            airflow_dag_run_id=req.external_sub_id,
            created_at=created_at,
        )
    elif tool == 'airbyte':
        airbyte = fetch_tool_instance(tenant_id, 'airbyte')
        if not open_job_link and airbyte:
            open_job_link = airbyte_ui_job_link(airbyte, connection_id=req.external_sub_id, job_id=req.external_id)
        job_id = get_or_create_job_id_for_airbyte_job(tenant_id, req.external_id, req.external_sub_id, external_url=open_job_link)
        upsert_job_summary(
            tenant_id=tenant_id,
            job_id=job_id,
            job_type=req.job_type,
            orchestrator=orchestrator,
            status=req.status,
            visibility=req.visibility,
            submitted_by_user_id=req.submitted_by_user_id,
            submitted_by_role=req.submitted_by_role,
            submitted_by_team=req.submitted_by_team,
            source=req.source,
            destination=req.destination,
            result_location=req.result_location,
            open_job_link=open_job_link,
            airbyte_connection_id=req.external_sub_id,
            airbyte_job_id=req.external_id,
            created_at=created_at,
        )
    else:
        job_id = get_or_create_binding_id(
            tenant_id,
            tool,
            'job_run',
            req.external_id,
            req.external_sub_id,
            open_job_link,
            id_prefix='JOB',
        )
        upsert_job_summary(
            tenant_id=tenant_id,
            job_id=job_id,
            job_type=req.job_type,
            orchestrator=orchestrator,
            status=req.status,
            visibility=req.visibility,
            submitted_by_user_id=req.submitted_by_user_id,
            submitted_by_role=req.submitted_by_role,
            submitted_by_team=req.submitted_by_team,
            source=req.source,
            destination=req.destination,
            result_location=req.result_location,
            open_job_link=open_job_link,
            created_at=created_at,
        )

    log_event(
        tenant_id,
        tool,
        'REGISTER_RUNTIME_JOB',
        external_id=req.external_id,
        external_sub_id=req.external_sub_id,
        payload={'job_id': job_id, 'status': req.status, 'visibility': req.visibility, 'orchestrator': orchestrator},
    )
    return {'tenant_id': tenant_id, 'job_id': job_id, 'tool': tool, 'status': req.status, 'open_job_link': open_job_link}


@router.get('/jobs')
def jobs(limit: int = Query(default=50, ge=1, le=500), ctx: AccessContext = Depends(access_dependency('jobs:list'))):
    rows = list_jobs(ctx.tenant_id, limit=limit)
    return [row for row in rows if can_read_job(ctx, row)]


@router.get('/jobs/{job_id}')
def job_detail(job_id: str, ctx: AccessContext = Depends(access_dependency('jobs:read'))):
    return _readable_job_or_404(ctx.tenant_id, job_id, ctx)


@router.get('/jobs/{job_id}/lineage')
def job_lineage(job_id: str, ctx: AccessContext = Depends(access_dependency('jobs:lineage:read'))):
    job = _readable_job_or_404(ctx.tenant_id, job_id, ctx)
    payload = fallback_lineage_for_job(job)
    record_result_access_audit(ctx.tenant_id, job_id, 'lineage', ctx.subject, ctx.auth_type, 'OK', detail={'edge_count': len(payload.get('edges') or [])})
    return payload


@router.get('/jobs/{job_id}/serving')
def job_serving(job_id: str, ctx: AccessContext = Depends(access_dependency('jobs:serving:read'))):
    job = _readable_job_or_404(ctx.tenant_id, job_id, ctx)
    result_location = job.get('result_location')
    objects_summary = list_job_objects(result_location, limit=50) if result_location else {'items': [], 'count': 0, 'message': 'Result location is empty'}
    sftp_publication = get_sftp_publication_status(ctx.tenant_id, job_id, result_location) if result_location else None
    payload = build_serving_descriptor(
        job_id=job_id,
        tenant_id=ctx.tenant_id,
        result_location=result_location,
        objects_summary=objects_summary,
        sftp_publication=sftp_publication,
    )
    record_result_access_audit(
        ctx.tenant_id,
        job_id,
        'serving',
        ctx.subject,
        ctx.auth_type,
        'OK',
        detail={
            'has_result': payload.get('has_result'),
            'object_count': (payload.get('objects_summary') or {}).get('count'),
            'sftp_published': ((payload.get('sftp') or {}).get('published')),
            'server_type': ((payload.get('sftp') or {}).get('server_type')),
            'publish_on_read': settings.SFTP_PUBLISH_ON_SERVING_READ,
        },
    )
    return payload


@router.post('/jobs/{job_id}/sftp-publish')
def job_sftp_publish(
    job_id: str,
    req: SftpPublishRequest,
    ctx: AccessContext = Depends(access_dependency('jobs:sftp:publish')),
):
    job = _readable_job_or_404(ctx.tenant_id, job_id, ctx)
    payload = publish_result_to_sftp(ctx.tenant_id, job_id, job.get('result_location'), preferred_object_key=req.object_key, explicit=True)
    record_result_access_audit(
        ctx.tenant_id,
        job_id,
        'sftp_publish',
        ctx.subject,
        ctx.auth_type,
        'OK' if payload.get('published') else 'EMPTY',
        object_key=req.object_key,
        detail={'published_file_count': payload.get('published_file_count'), 'server_type': payload.get('server_type')},
    )
    return payload


@router.get('/jobs/{job_id}/objects')
def job_objects(
    job_id: str,
    limit: int = Query(default=50, ge=1, le=500),
    cursor: str | None = Query(default=None),
    ctx: AccessContext = Depends(access_dependency('jobs:objects:read')),
):
    job = _readable_job_or_404(ctx.tenant_id, job_id, ctx)
    payload = list_job_objects(job.get('result_location'), limit=limit, cursor=cursor)
    record_result_access_audit(
        ctx.tenant_id,
        job_id,
        'objects',
        ctx.subject,
        ctx.auth_type,
        'OK' if payload.get('items') is not None else 'EMPTY',
        detail={'limit': limit, 'has_next_cursor': bool(payload.get('next_cursor')), 'count': payload.get('count')},
    )
    return payload


@router.get('/jobs/{job_id}/preview')
def job_preview(
    job_id: str,
    limit: int = Query(default=20, ge=1, le=100),
    cursor: str | None = Query(default=None),
    object_key: str | None = Query(default=None),
    ctx: AccessContext = Depends(access_dependency('jobs:preview:read')),
):
    job = _readable_job_or_404(ctx.tenant_id, job_id, ctx)
    payload = preview_result_object(job.get('result_location'), limit=limit, cursor=cursor, preferred_object_key=object_key)
    record_result_access_audit(
        ctx.tenant_id,
        job_id,
        'preview',
        ctx.subject,
        ctx.auth_type,
        'OK' if payload.get('rows') else 'EMPTY',
        object_key=payload.get('object_key'),
        detail={'limit': limit, 'format': payload.get('format'), 'preview_engine': payload.get('preview_engine'), 'has_next_cursor': bool(payload.get('next_cursor'))},
    )
    return payload


@router.get('/jobs/{job_id}/sample-preview')
def job_sample_preview(
    job_id: str,
    limit: int = Query(default=20, ge=1, le=100),
    cursor: str | None = Query(default=None),
    object_key: str | None = Query(default=None),
    ctx: AccessContext = Depends(access_dependency('jobs:preview:read')),
):
    return job_preview(job_id=job_id, limit=limit, cursor=cursor, object_key=object_key, ctx=ctx)


@router.post('/jobs/{job_id}/download-url')
def job_download_url(
    job_id: str,
    req: DownloadUrlRequest,
    ctx: AccessContext = Depends(access_dependency('jobs:download:create')),
):
    job = _readable_job_or_404(ctx.tenant_id, job_id, ctx)
    payload = create_presigned_download(
        job.get('result_location'),
        preferred_object_key=req.object_key,
        expires_in_seconds=req.expires_in_seconds,
    )
    record_result_access_audit(
        ctx.tenant_id,
        job_id,
        'download_url',
        ctx.subject,
        ctx.auth_type,
        'OK' if payload.get('download_url') else 'EMPTY',
        object_key=payload.get('object_key'),
        detail={'expires_in_seconds': payload.get('expires_in_seconds')},
    )
    return payload


@router.get('/jobs/{job_id}/download-url')
def job_download_url_get(
    job_id: str,
    object_key: str | None = Query(default=None),
    expires_in_seconds: int | None = Query(default=None, ge=60, le=3600),
    ctx: AccessContext = Depends(access_dependency('jobs:download:create')),
):
    return job_download_url(job_id=job_id, req=DownloadUrlRequest(object_key=object_key, expires_in_seconds=expires_in_seconds), ctx=ctx)
