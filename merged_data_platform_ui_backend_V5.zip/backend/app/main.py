from fastapi import FastAPI

from app.config import settings
from app.db import get_conn, put_conn
from app.routes.admin import router as admin_router
from app.routes.jobs import router as jobs_router

app = FastAPI(title=settings.PLATFORM_NAME, version=settings.PLATFORM_VERSION)

app.include_router(admin_router, prefix='/v1/admin', tags=['admin'])
app.include_router(jobs_router, prefix='/v1', tags=['jobs'])


@app.get('/v1/health')
def health():
    return {'status': 'ok', 'version': settings.PLATFORM_VERSION}


@app.get('/v1/health/live')
def live():
    return {'status': 'ok'}


@app.get('/v1/health/ready')
def ready():
    conn = get_conn()
    try:
        with conn.cursor() as cur:
            cur.execute('select 1')
            cur.fetchone()
        return {'status': 'ready'}
    finally:
        put_conn(conn)
