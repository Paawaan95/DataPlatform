from __future__ import annotations

from datetime import datetime, timezone
from typing import Any



def _edge(edge_id: str, from_type: str, from_id: str, to_type: str, to_id: str, relation: str) -> dict[str, Any]:
    return {
        'edge_id': edge_id,
        'from_type': from_type,
        'from_id': from_id,
        'to_type': to_type,
        'to_id': to_id,
        'relation': relation,
        'created_at': datetime.now(timezone.utc).isoformat(),
    }



def fallback_lineage_for_job(job: dict[str, Any]) -> dict[str, Any]:
    job_id = str(job.get('job_id') or '')
    source = str(job.get('source') or '').strip()
    destination = str(job.get('destination') or '').strip()
    result_location = str(job.get('result_location') or '').strip()

    edges: list[dict[str, Any]] = []
    if source:
        edges.append(_edge(f'{job_id}:source', 'dataset', source, 'job', job_id, 'feeds'))
    if destination:
        edges.append(_edge(f'{job_id}:destination', 'job', job_id, 'dataset', destination, 'produces'))
    if result_location:
        edges.append(_edge(f'{job_id}:result', 'job', job_id, 'object_storage', result_location, 'materializes_to'))

    return {
        'mode': 'fallback',
        'edges': edges,
        'message': 'Fallback lineage derived from source, destination, and result_location' if edges else 'No lineage available yet',
    }
