from __future__ import annotations

from pathlib import Path
from typing import Any

import httpx

from app.config import settings


class SFTPGoError(RuntimeError):
    pass


def _enabled() -> bool:
    return bool(settings.SFTP_ENABLED and settings.SFTPGO_ENABLED and settings.SFTPGO_BASE_URL)


def _home_dir_for_tenant(tenant_id: str) -> str:
    return str((Path(settings.SFTPGO_HOME_BASE_DIR) / 'exports' / tenant_id).resolve())


def _username_for_tenant(tenant_id: str) -> str:
    base = (settings.SFTP_USERNAME or 'tenant').strip()
    return f'{base}_{tenant_id}'.replace('/', '_').replace(' ', '_')


def _password_for_tenant(tenant_id: str) -> str:
    # For local/demo this is intentionally deterministic. Production should switch to one-time credentials or SSH keys.
    base = (settings.SFTP_PASSWORD or 'change-me').strip()
    if tenant_id == settings.DEFAULT_TENANT_ID:
        return base
    return f'{base}_{tenant_id}'


def _admin_token() -> str:
    if not _enabled():
        raise SFTPGoError('SFTPGo is not enabled')
    with httpx.Client(base_url=settings.SFTPGO_BASE_URL.rstrip('/'), timeout=10.0) as client:
        response = client.get('/api/v2/token', auth=(settings.SFTPGO_ADMIN_USERNAME, settings.SFTPGO_ADMIN_PASSWORD))
        response.raise_for_status()
        payload = response.json()
    token = str(payload.get('access_token') or '').strip()
    if not token:
        raise SFTPGoError('SFTPGo admin token response did not include access_token')
    return token


def _user_payload(tenant_id: str) -> dict[str, Any]:
    home_dir = _home_dir_for_tenant(tenant_id)
    Path(home_dir).mkdir(parents=True, exist_ok=True)
    payload: dict[str, Any] = {
        'status': 1,
        'username': _username_for_tenant(tenant_id),
        'password': _password_for_tenant(tenant_id),
        'home_dir': home_dir,
        'permissions': {'/': ['list', 'download'] if settings.SFTP_READ_ONLY else ['*']},
    }
    return payload


def ensure_sftpgo_user(tenant_id: str) -> dict[str, Any]:
    if not _enabled():
        return {
            'enabled': False,
            'username': settings.SFTP_USERNAME,
            'password': settings.SFTP_PASSWORD if settings.SFTPGO_EXPOSE_CREDENTIALS_IN_METADATA else '',
            'home_dir': _home_dir_for_tenant(tenant_id),
        }

    token = _admin_token()
    username = _username_for_tenant(tenant_id)
    headers = {'Authorization': f'Bearer {token}', 'Content-Type': 'application/json'}
    payload = _user_payload(tenant_id)

    with httpx.Client(base_url=settings.SFTPGO_BASE_URL.rstrip('/'), timeout=10.0, headers=headers) as client:
        get_response = client.get(f'/api/v2/users/{username}')
        if get_response.status_code == 404:
            create_response = client.post('/api/v2/users', json=payload)
            create_response.raise_for_status()
        elif get_response.is_success:
            update_response = client.put(f'/api/v2/users/{username}', json=payload)
            update_response.raise_for_status()
        else:
            get_response.raise_for_status()

    return {
        'enabled': True,
        'username': username,
        'password': _password_for_tenant(tenant_id) if settings.SFTPGO_EXPOSE_CREDENTIALS_IN_METADATA else '',
        'home_dir': _home_dir_for_tenant(tenant_id),
    }
