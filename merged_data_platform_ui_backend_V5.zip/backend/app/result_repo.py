from __future__ import annotations

import json
from typing import Any

from app.db import get_conn, put_conn



def record_result_access_audit(
    tenant_id: str,
    job_id: str,
    access_type: str,
    actor_id: str,
    auth_type: str,
    status: str,
    *,
    object_key: str | None = None,
    detail: dict[str, Any] | None = None,
) -> None:
    conn = get_conn()
    try:
        with conn:
            with conn.cursor() as cur:
                cur.execute(
                    '''
                    insert into result_access_audit(
                      tenant_id, job_id, access_type, actor_id, auth_type, object_key, status, detail
                    )
                    values (%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
                    ''',
                    (
                        tenant_id,
                        job_id,
                        access_type,
                        actor_id,
                        auth_type,
                        object_key,
                        status,
                        json.dumps(detail or {}),
                    ),
                )
    except Exception:
        # Keep backward compatibility with older databases that do not yet have the audit table.
        try:
            conn.rollback()
        except Exception:
            pass
    finally:
        put_conn(conn)
