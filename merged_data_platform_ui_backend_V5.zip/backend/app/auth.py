from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass, field
from functools import lru_cache
from typing import Any, Callable

import httpx
import jwt
from fastapi import Depends, Header, HTTPException

from app.config import settings
from app.sql_repo import tenant_is_active


@dataclass
class AccessContext:
    tenant_id: str
    subject: str = 'anonymous'
    role: str = 'viewer'
    team: str = ''
    scopes: set[str] = field(default_factory=set)
    auth_type: str = 'none'
    raw_claims: dict[str, Any] = field(default_factory=dict)

    def has_scope(self, scope: str) -> bool:
        return '*' in self.scopes or scope in self.scopes

    def require(self, *scopes: str) -> None:
        missing = [scope for scope in scopes if not self.has_scope(scope)]
        if missing:
            raise HTTPException(status_code=403, detail=f"Missing required scope(s): {', '.join(missing)}")


DEFAULT_SCOPES = {
    'jobs:list',
    'jobs:read',
    'jobs:lineage:read',
    'jobs:serving:read',
    'jobs:objects:read',
    'jobs:preview:read',
    'jobs:download:create',
    'jobs:sftp:publish',
    'jobs:register',
}


def _parse_csv(value: str | None) -> list[str]:
    return [item.strip() for item in (value or '').split(',') if item and item.strip()]


def _parse_scopes(value: Any) -> set[str]:
    if isinstance(value, list):
        return {str(item).strip() for item in value if str(item).strip()}
    if isinstance(value, str):
        parts = [item.strip() for item in value.replace(',', ' ').split(' ') if item.strip()]
        return set(parts)
    return set()


def _nested_get(payload: dict[str, Any], dotted_path: str) -> Any:
    current: Any = payload
    for part in dotted_path.split('.'):
        if not isinstance(current, dict) or part not in current:
            return None
        current = current.get(part)
    return current


def _claim_values(payload: dict[str, Any], dotted_names_csv: str) -> list[Any]:
    values: list[Any] = []
    for dotted_name in _parse_csv(dotted_names_csv):
        value = _nested_get(payload, dotted_name)
        if value not in (None, '', [], {}):
            values.append(value)
    return values


def _api_keys() -> dict[str, dict[str, Any]]:
    raw = (settings.API_KEYS_JSON or '').strip()
    if not raw:
        return {}
    try:
        data = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise RuntimeError(f'Invalid API_KEYS_JSON: {exc}') from exc
    return data if isinstance(data, dict) else {}


def _validate_tenant(tenant_id: str) -> str:
    if not tenant_id:
        raise HTTPException(status_code=400, detail='Missing tenant context')
    if settings.ENFORCE_ACTIVE_TENANT and not tenant_is_active(tenant_id):
        raise HTTPException(status_code=404, detail=f'Tenant {tenant_id} is not active or does not exist')
    return tenant_id


def _ctx_from_demo(tenant_id: str) -> AccessContext:
    return AccessContext(
        tenant_id=_validate_tenant(tenant_id),
        subject=settings.DEFAULT_DEMO_SUBJECT,
        role=settings.DEFAULT_DEMO_ROLE,
        team=settings.DEFAULT_DEMO_TEAM,
        scopes=set(DEFAULT_SCOPES),
        auth_type='none',
        raw_claims={'mode': 'demo'},
    )


def _resolve_api_key_claims(api_key: str) -> dict[str, Any] | None:
    keys = _api_keys()
    if not keys:
        return None
    if api_key in keys:
        claims = keys.get(api_key)
        return claims if isinstance(claims, dict) else None

    hashed = hashlib.sha256(api_key.encode('utf-8')).hexdigest()
    for _, raw_claims in keys.items():
        if not isinstance(raw_claims, dict):
            continue
        declared = str(raw_claims.get('sha256') or raw_claims.get('hash_sha256') or '').strip().lower()
        if declared and declared == hashed:
            return raw_claims
    return None


def _ctx_from_api_key(api_key: str, tenant_id: str) -> AccessContext:
    claims = _resolve_api_key_claims(api_key)
    if not claims:
        raise HTTPException(status_code=401, detail='Invalid API key')

    resolved_tenant = str(claims.get('tenant_id') or tenant_id or '').strip()
    if tenant_id and resolved_tenant and tenant_id != resolved_tenant:
        raise HTTPException(status_code=403, detail='API key tenant mismatch')

    return AccessContext(
        tenant_id=_validate_tenant(resolved_tenant),
        subject=str(claims.get('subject') or claims.get('client_id') or 'service-client'),
        role=str(claims.get('role') or 'service'),
        team=str(claims.get('team') or 'platform'),
        scopes=_parse_scopes(claims.get('scopes')) or set(DEFAULT_SCOPES),
        auth_type='api_key',
        raw_claims=claims,
    )


@lru_cache(maxsize=1)
def _oidc_metadata() -> dict[str, Any]:
    url = (settings.AUTH_OIDC_DISCOVERY_URL or '').strip()
    if not url:
        return {}
    with httpx.Client(timeout=5.0) as client:
        response = client.get(url)
        response.raise_for_status()
        data = response.json()
        return data if isinstance(data, dict) else {}


@lru_cache(maxsize=1)
def _jwks_client() -> jwt.PyJWKClient | None:
    jwks_url = (settings.AUTH_JWKS_URL or '').strip()
    if not jwks_url:
        metadata = _oidc_metadata()
        jwks_url = str(metadata.get('jwks_uri') or '').strip()
    if not jwks_url:
        return None
    return jwt.PyJWKClient(jwks_url)


def _jwt_decode_options() -> dict[str, Any]:
    return {
        'verify_aud': bool(settings.AUTH_JWT_AUDIENCE and settings.AUTH_JWT_REQUIRE_AUDIENCE),
        'verify_iss': bool(settings.AUTH_JWT_ISSUER and settings.AUTH_JWT_REQUIRE_ISSUER),
        'require': ['exp', 'iat'],
    }


def _extract_tenant(claims: dict[str, Any], tenant_id_hint: str) -> str:
    for value in _claim_values(claims, settings.AUTH_TENANT_CLAIM_NAMES):
        if isinstance(value, list):
            candidate = next((str(item).strip() for item in value if str(item).strip()), '')
        else:
            candidate = str(value).strip()
        if candidate:
            if tenant_id_hint and candidate != tenant_id_hint:
                raise HTTPException(status_code=403, detail='Bearer token tenant mismatch')
            return candidate
    return tenant_id_hint


def _extract_role(claims: dict[str, Any]) -> str:
    values = _claim_values(claims, settings.AUTH_ROLE_CLAIM_NAMES)
    for value in values:
        if isinstance(value, list) and value:
            return str(value[0]).strip()
        if isinstance(value, str) and value.strip():
            return value.strip()
    return 'viewer'


def _extract_team(claims: dict[str, Any]) -> str:
    values = _claim_values(claims, settings.AUTH_TEAM_CLAIM_NAMES)
    for value in values:
        if isinstance(value, list) and value:
            return str(value[0]).strip()
        if isinstance(value, str) and value.strip():
            return value.strip()
    return ''


def _extract_scopes(claims: dict[str, Any]) -> set[str]:
    scopes: set[str] = set()
    for value in _claim_values(claims, settings.AUTH_SCOPE_CLAIM_NAMES):
        scopes |= _parse_scopes(value)
    if not scopes:
        scopes = set(DEFAULT_SCOPES)
    return scopes


def _ctx_from_jwt(token: str, tenant_id: str) -> AccessContext:
    decode_kwargs: dict[str, Any] = {
        'algorithms': [settings.AUTH_JWT_ALGORITHM],
        'issuer': settings.AUTH_JWT_ISSUER or None,
        'audience': settings.AUTH_JWT_AUDIENCE or None,
        'options': _jwt_decode_options(),
        'leeway': settings.AUTH_JWT_CLOCK_SKEW_SECONDS,
    }

    try:
        jwks_client = _jwks_client()
        if jwks_client is not None:
            signing_key = jwks_client.get_signing_key_from_jwt(token)
            claims = jwt.decode(token, signing_key.key, **decode_kwargs)
            auth_type = 'bearer-jwks'
        else:
            if not settings.AUTH_JWT_SECRET:
                raise HTTPException(
                    status_code=500,
                    detail='JWT auth is enabled but neither AUTH_JWT_SECRET nor AUTH_JWKS_URL/AUTH_OIDC_DISCOVERY_URL is configured',
                )
            claims = jwt.decode(token, settings.AUTH_JWT_SECRET, **decode_kwargs)
            auth_type = 'bearer-shared-secret'
    except HTTPException:
        raise
    except jwt.PyJWTError as exc:
        raise HTTPException(status_code=401, detail=f'Invalid bearer token: {exc}') from exc
    except Exception as exc:
        raise HTTPException(status_code=401, detail=f'Failed to validate bearer token: {exc}') from exc

    resolved_tenant = _extract_tenant(claims, tenant_id)
    if not resolved_tenant:
        raise HTTPException(status_code=401, detail='Bearer token is missing tenant context')

    return AccessContext(
        tenant_id=_validate_tenant(resolved_tenant),
        subject=str(claims.get('sub') or claims.get('preferred_username') or claims.get('email') or 'user'),
        role=_extract_role(claims),
        team=_extract_team(claims),
        scopes=_extract_scopes(claims),
        auth_type=auth_type,
        raw_claims=claims,
    )


def _resolve_tenant(x_tenant_id: str | None) -> str:
    header_tenant = (x_tenant_id or '').strip()
    default_tenant = (settings.DEFAULT_TENANT_ID or '').strip()
    if header_tenant:
        return header_tenant
    if settings.ALLOW_DEFAULT_TENANT and default_tenant:
        return default_tenant
    raise HTTPException(
        status_code=400,
        detail='Missing X-Tenant-ID header and default-tenant fallback is disabled or empty',
    )


def access_dependency(*required_scopes: str) -> Callable[..., AccessContext]:
    def dependency(
        x_tenant_id: str | None = Header(default=None, alias='X-Tenant-ID'),
        authorization: str | None = Header(default=None, alias='Authorization'),
        x_platform_api_key: str | None = Header(default=None, alias='X-Platform-API-Key'),
    ) -> AccessContext:
        tenant_id = _resolve_tenant(x_tenant_id)

        if not settings.API_AUTH_REQUIRED:
            ctx = _ctx_from_demo(tenant_id)
        elif x_platform_api_key:
            ctx = _ctx_from_api_key(x_platform_api_key.strip(), tenant_id)
        elif authorization and authorization.lower().startswith('bearer '):
            ctx = _ctx_from_jwt(authorization.split(' ', 1)[1].strip(), tenant_id)
        else:
            raise HTTPException(status_code=401, detail='Missing Authorization bearer token or X-Platform-API-Key')

        if required_scopes:
            ctx.require(*required_scopes)
        return ctx

    return dependency


def get_tenant_id(ctx: AccessContext = Depends(access_dependency())) -> str:
    return ctx.tenant_id


def can_read_job(ctx: AccessContext, job: dict[str, Any]) -> bool:
    visibility = str(job.get('visibility') or 'Private')
    if ctx.has_scope('*') or ctx.has_scope('jobs:admin'):
        return True
    if visibility == 'Global':
        return True
    if visibility == 'Team':
        job_team = str(job.get('submitted_by_team') or '')
        return bool(job_team and ctx.team and job_team == ctx.team)
    owner = str(job.get('submitted_by_user_id') or '')
    return bool(owner and owner == ctx.subject)
