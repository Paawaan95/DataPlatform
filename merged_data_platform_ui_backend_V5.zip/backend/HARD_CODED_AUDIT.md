# Hardcoded Configuration Audit

## Centralized now
- PostgreSQL image, DB name, user, password, internal host/port, external port
- API internal/external port
- default tenant id and tenant name
- Airflow base URL, UI URL, auth mode, username, password, bearer token, timeout
- Airbyte base URL
- discovery cadence and DAG discovery defaults
- bootstrap seed enablement for tenant/tool-instance seed rows
- Docker host gateway mapping token

## Files changed
- `app/config.py`
- `app/clients/airflow_client.py`
- `app/routes/admin.py`
- `app/sql_repo.py`
- `docker-compose.yml`
- `sql/002_seed.sh` (new runtime seed script)
- `.env`
- `.env.example`

## Hardcoded values intentionally kept
These remain in code because they are business logic or schema semantics, not deploy-time environment config:
- enum values like `airflow`, `airbyte`, `job_run`, `Private`, `Team`, `Global`
- API route paths like `/v1/jobs` and `/v1/admin/bootstrap`
- worker module entry points like `worker.poll_airflow`
- status normalization values like `RUNNING`, `FAILED`, `SUCCEEDED`
- table / stored procedure names in SQL

## Notes
- The project already includes both `fast` and `slow` worker flows. Both now consume `.env` through Docker Compose.
- This package does **not** include colleague codebases that were not uploaded, so I centralized the full runnable backend package you provided.
