from __future__ import annotations

import io
import json
import os
from typing import Iterable

import pyarrow as pa
import pyarrow.parquet as pq

from app.config import settings
from app.services.object_store import minio_client
from app.sql_repo import call_bootstrap, upsert_job_summary, utc_now


def _put_bytes(bucket: str, object_key: str, payload: bytes, content_type: str) -> None:
    client = minio_client()
    if client is None:
        raise RuntimeError('MinIO is not configured')
    if not client.bucket_exists(bucket):
        client.make_bucket(bucket)
    client.put_object(bucket, object_key, io.BytesIO(payload), len(payload), content_type=content_type)


def _csv_bytes(rows: list[dict[str, object]]) -> bytes:
    columns = ['customer_id', 'customer_name', 'country', 'order_count', 'revenue']
    lines = [','.join(columns)]
    for row in rows:
        lines.append(','.join(str(row.get(col, '')) for col in columns))
    return ('\n'.join(lines) + '\n').encode('utf-8')


def _jsonl_bytes(rows: Iterable[dict[str, object]]) -> bytes:
    return ('\n'.join(json.dumps(row) for row in rows) + '\n').encode('utf-8')


def _json_bytes(rows: list[dict[str, object]]) -> bytes:
    return json.dumps(rows, indent=2).encode('utf-8')


def _parquet_bytes(rows: list[dict[str, object]]) -> bytes:
    table = pa.Table.from_pylist(rows)
    sink = io.BytesIO()
    pq.write_table(table, sink)
    return sink.getvalue()


def main() -> None:
    tenant_id = os.getenv('SEED_TENANT_ID', settings.DEFAULT_TENANT_ID)
    job_id = os.getenv('SEED_JOB_ID', 'JOB-DEMO-RESULT-1001')
    prefix = os.getenv('SEED_RESULT_PREFIX', 'gold/demo/customer_metrics/run_id=seed_v4/')
    bucket = settings.MINIO_DEFAULT_BUCKET
    created_at = utc_now()

    rows = [
        {'customer_id': 101, 'customer_name': 'Acme Retail', 'country': 'IN', 'order_count': 12, 'revenue': 18250.5},
        {'customer_id': 102, 'customer_name': 'Bright Stores', 'country': 'US', 'order_count': 7, 'revenue': 9730.0},
        {'customer_id': 103, 'customer_name': 'City Hub', 'country': 'DE', 'order_count': 4, 'revenue': 5110.75},
    ]

    objects = {
        f'{prefix}customer_metrics.csv': (_csv_bytes(rows), 'text/csv'),
        f'{prefix}customer_metrics.jsonl': (_jsonl_bytes(rows), 'application/x-ndjson'),
        f'{prefix}customer_metrics.json': (_json_bytes(rows), 'application/json'),
        f'{prefix}customer_metrics.parquet': (_parquet_bytes(rows), 'application/octet-stream'),
    }

    for object_key, (payload, content_type) in objects.items():
        _put_bytes(bucket, object_key, payload, content_type)

    call_bootstrap(
        tenant_id=tenant_id,
        tenant_name=settings.DEFAULT_TENANT_NAME,
        airflow_base_url=settings.AIRFLOW_BASE_URL,
        airbyte_base_url=settings.AIRBYTE_BASE_URL,
    )
    upsert_job_summary(
        tenant_id=tenant_id,
        job_id=job_id,
        job_type='SQL query',
        orchestrator='Airflow + Trino',
        status='SUCCEEDED',
        visibility='Global',
        created_at=created_at,
        submitted_by_user_id='seed-script',
        submitted_by_role='Platform',
        submitted_by_team='Platform',
        source='silver/demo/orders_clean',
        destination='gold/demo/customer_metrics',
        result_location=f's3://{bucket}/{prefix}',
        open_job_link='',
        seen_at=created_at,
    )

    print('[OK] Seeded demo result set')
    print(f'  tenant_id      : {tenant_id}')
    print(f'  job_id         : {job_id}')
    print(f'  result_location: s3://{bucket}/{prefix}')
    print('  objects        :')
    for object_key in objects:
        print(f'    - s3://{bucket}/{object_key}')


if __name__ == '__main__':
    main()
