from __future__ import annotations

import json
import os
from urllib.parse import urlparse

import httpx

API_BASE_URL = os.getenv('LEDGER_API_BASE_URL', f"http://127.0.0.1:{os.getenv('API_PORT_EXTERNAL', '8199')}").rstrip('/')
TENANT_ID = os.getenv('SMOKE_TENANT_ID', os.getenv('DEFAULT_TENANT_ID', 'demo'))
JOB_ID = os.getenv('SMOKE_JOB_ID', 'JOB-DEMO-RESULT-1001')
PUBLIC_ENDPOINT = os.getenv('MINIO_PUBLIC_ENDPOINT', '127.0.0.1:9000').strip()
AUTH_MODE = os.getenv('SMOKE_AUTH_MODE', 'none').strip().lower()
API_KEY = os.getenv('LEDGER_API_KEY', 'local-service-key').strip()
BEARER_TOKEN = os.getenv('LEDGER_API_TOKEN', '').strip()


def _headers() -> dict[str, str]:
    headers = {'Accept': 'application/json', 'X-Tenant-ID': TENANT_ID}
    if AUTH_MODE == 'api_key' and API_KEY:
        headers['X-Platform-API-Key'] = API_KEY
    elif AUTH_MODE == 'bearer' and BEARER_TOKEN:
        headers['Authorization'] = f'Bearer {BEARER_TOKEN}'
    return headers


def _get(client: httpx.Client, path: str, **params):
    response = client.get(f'{API_BASE_URL}{path}', params=params or None)
    response.raise_for_status()
    return response.json()


def _post(client: httpx.Client, path: str, payload: dict):
    response = client.post(f'{API_BASE_URL}{path}', json=payload)
    response.raise_for_status()
    return response.json()


def main() -> None:
    with httpx.Client(headers=_headers(), timeout=20.0) as client:
        detail = _get(client, f'/v1/jobs/{JOB_ID}')
        serving = _get(client, f'/v1/jobs/{JOB_ID}/serving')
        assert detail.get('job_id') == JOB_ID, 'job detail did not match requested job id'
        assert serving.get('job_id') == JOB_ID, 'serving payload did not match requested job id'

        objects = _get(client, f'/v1/jobs/{JOB_ID}/objects', limit=20)
        items = objects.get('items') or []
        assert items, 'no result objects were listed'
        selected_object = next((item.get('object_key') for item in items if item.get('is_primary')), items[0].get('object_key'))
        assert selected_object, 'no primary object could be resolved'

        preview = _get(client, f'/v1/jobs/{JOB_ID}/preview', limit=10, object_key=selected_object)
        assert preview.get('object_key') == selected_object, 'preview resolved the wrong object'
        assert isinstance(preview.get('rows'), list), 'preview rows were not returned'

        download = _post(client, f'/v1/jobs/{JOB_ID}/download-url', {'object_key': selected_object})
        download_url = str(download.get('download_url') or '')
        assert download_url, 'download URL was not returned'
        parsed = urlparse(download_url)
        assert parsed.netloc == PUBLIC_ENDPOINT, f'download URL host mismatch: expected {PUBLIC_ENDPOINT}, got {parsed.netloc}'

        sftp = _post(client, f'/v1/jobs/{JOB_ID}/sftp-publish', {'object_key': selected_object})
        assert sftp.get('available') is True, 'sftp publish not available'

        print('[OK] Serving smoke test passed')
        print(json.dumps({
            'job_id': JOB_ID,
            'selected_object': selected_object,
            'preview_rows': len(preview.get('rows') or []),
            'download_url_host': parsed.netloc,
            'sftp_published_files': sftp.get('published_files') or [],
        }, indent=2))


if __name__ == '__main__':
    main()
