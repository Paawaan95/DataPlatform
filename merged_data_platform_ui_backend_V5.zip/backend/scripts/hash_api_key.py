from __future__ import annotations

import argparse
import hashlib
import json


def main() -> None:
    parser = argparse.ArgumentParser(description='Hash a platform API key for API_KEYS_JSON entries.')
    parser.add_argument('api_key', help='The raw API key to hash with SHA-256')
    parser.add_argument('--tenant-id', default='demo')
    parser.add_argument('--subject', default='svc-local')
    parser.add_argument('--role', default='service')
    parser.add_argument('--team', default='Platform')
    parser.add_argument('--scopes', default='jobs:list,jobs:read,jobs:lineage:read,jobs:serving:read,jobs:objects:read,jobs:preview:read,jobs:download:create,jobs:sftp:publish,jobs:register')
    args = parser.parse_args()

    digest = hashlib.sha256(args.api_key.encode('utf-8')).hexdigest()
    payload = {
        'sha256': digest,
        'tenant_id': args.tenant_id,
        'subject': args.subject,
        'role': args.role,
        'team': args.team,
        'scopes': [scope.strip() for scope in args.scopes.split(',') if scope.strip()],
    }
    print(json.dumps(payload, indent=2))


if __name__ == '__main__':
    main()
