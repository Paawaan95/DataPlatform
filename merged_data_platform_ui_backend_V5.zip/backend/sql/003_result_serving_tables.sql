create table if not exists result_access_audit (
  audit_id       bigserial primary key,
  tenant_id      text not null,
  job_id         text not null,
  access_type    text not null,
  actor_id       text,
  auth_type      text,
  object_key     text,
  status         text,
  detail         jsonb not null default '{}'::jsonb,
  created_at     timestamptz not null default now()
);

create index if not exists idx_result_access_audit_job_time
  on result_access_audit(tenant_id, job_id, created_at desc);
