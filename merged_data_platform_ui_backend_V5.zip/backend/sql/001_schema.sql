-- Manager-style schema: tables + enums + stored procs (core for demo)
-- Runs automatically on fresh Postgres container start.

create table if not exists tenant (
  tenant_id    text primary key,
  tenant_name  text not null,
  is_active    boolean not null default true,
  created_at   timestamptz not null default now(),
  updated_at   timestamptz not null default now()
);

create table if not exists user_cache (
  tenant_id       text not null references tenant(tenant_id),
  user_id         text not null,
  username        text,
  email           text,
  display_name    text,
  last_synced_at  timestamptz,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  primary key (tenant_id, user_id)
);

do $$ begin
  create type tool_type as enum ('airflow', 'airbyte');
exception when duplicate_object then null;
end $$;

create table if not exists tool_instance (
  tool_instance_id  bigserial primary key,
  tenant_id         text not null references tenant(tenant_id),
  tool              tool_type not null,
  base_url          text not null,
  auth_ref          text,
  is_active         boolean not null default true,
  created_at        timestamptz not null default now(),
  updated_at        timestamptz not null default now(),
  unique (tenant_id, tool)
);

do $$ begin
  create type resource_type as enum ('connection','pipeline','job_run');
exception when duplicate_object then null;
end $$;

create table if not exists tool_resource_binding (
  binding_id           bigserial primary key,
  tenant_id            text not null references tenant(tenant_id),

  platform_resource_id text not null,
  resource_type        resource_type not null,
  tool                 tool_type not null,

  external_id          text not null,
  external_sub_id      text,
  external_url         text,

  created_by_user_id   text,
  updated_by_user_id   text,
  created_at           timestamptz not null default now(),
  updated_at           timestamptz not null default now(),

  unique (tenant_id, platform_resource_id)
);

-- Postgres does not allow COALESCE() inside UNIQUE constraints.
-- Enforce the intended dedupe rule via expression-based UNIQUE INDEX:
create unique index if not exists uq_tool_resource_binding_extkey
  on tool_resource_binding(tenant_id, tool, resource_type, external_id, coalesce(external_sub_id,''));

create index if not exists idx_binding_lookup
  on tool_resource_binding(tenant_id, tool, resource_type, external_id);

create index if not exists idx_binding_tenant_type
  on tool_resource_binding(tenant_id, resource_type);

do $$ begin
  create type job_visibility as enum ('Private','Team','Global');
exception when duplicate_object then null;
end $$;

create table if not exists job_summary_index (
  tenant_id            text not null references tenant(tenant_id),
  job_id               text not null,

  job_type             text not null,
  orchestrator         text not null,
  status               text not null,

  submitted_by_user_id text,
  submitted_by_role    text,
  submitted_by_team    text,
  visibility           job_visibility not null default 'Private',

  source               text,
  destination          text,
  result_location      text,
  open_job_link        text,

  airflow_dag_id        text,
  airflow_dag_run_id    text,
  airbyte_connection_id text,
  airbyte_job_id        text,

  created_at           timestamptz not null,
  updated_at           timestamptz not null default now(),
  last_seen_at         timestamptz not null default now(),

  primary key (tenant_id, job_id)
);

create index if not exists idx_job_tenant_time
  on job_summary_index(tenant_id, created_at desc);

create index if not exists idx_job_tenant_status
  on job_summary_index(tenant_id, status, created_at desc);

create index if not exists idx_job_airflow
  on job_summary_index(tenant_id, airflow_dag_id, airflow_dag_run_id);

create index if not exists idx_job_airbyte
  on job_summary_index(tenant_id, airbyte_job_id);

create table if not exists connection_summary_index (
  tenant_id              text not null references tenant(tenant_id),

  connection_id          text not null,
  airbyte_connection_id  text not null,

  connection_name        text not null,
  source_name            text,
  destination_name       text,

  schedule_type          text,
  schedule_value         text,

  last_sync_status       text,
  last_sync_started_at   timestamptz,
  last_sync_ended_at     timestamptz,

  created_by_user_id     text,
  updated_by_user_id     text,
  created_at             timestamptz not null,
  updated_at             timestamptz not null default now(),
  last_seen_at           timestamptz not null default now(),

  primary key (tenant_id, connection_id),
  unique (tenant_id, airbyte_connection_id)
);

create index if not exists idx_conn_tenant_time
  on connection_summary_index(tenant_id, created_at desc);

create index if not exists idx_conn_last_sync
  on connection_summary_index(tenant_id, last_sync_started_at desc);

create table if not exists sync_state (
  tenant_id        text not null references tenant(tenant_id),
  tool             tool_type not null,
  cursor_json      jsonb not null default '{}'::jsonb,
  last_sync_at     timestamptz,
  last_success_at  timestamptz,
  last_error       text,
  updated_at       timestamptz not null default now(),
  primary key (tenant_id, tool)
);

create table if not exists sync_event_log (
  id              bigserial primary key,
  tenant_id        text not null references tenant(tenant_id),
  tool             tool_type not null,
  event_type       text not null,
  external_id      text,
  external_sub_id  text,
  payload          jsonb,
  created_at       timestamptz not null default now()
);

create index if not exists idx_synclog_tenant_time
  on sync_event_log(tenant_id, created_at desc);

-- Stored proc: upsert jobs (UI reads this table)
create or replace function sp_upsert_job_summary_index(
  p_tenant_id text,
  p_job_id text,
  p_job_type text,
  p_orchestrator text,
  p_status text,

  p_submitted_by_user_id text,
  p_submitted_by_role text,
  p_submitted_by_team text,
  p_visibility job_visibility,

  p_source text,
  p_destination text,
  p_result_location text,
  p_open_job_link text,

  p_airflow_dag_id text,
  p_airflow_dag_run_id text,
  p_airbyte_connection_id text,
  p_airbyte_job_id text,

  p_created_at timestamptz,
  p_seen_at timestamptz
) returns void
language plpgsql
as $$
begin
  insert into job_summary_index (
    tenant_id, job_id,
    job_type, orchestrator, status,
    submitted_by_user_id, submitted_by_role, submitted_by_team, visibility,
    source, destination, result_location, open_job_link,
    airflow_dag_id, airflow_dag_run_id, airbyte_connection_id, airbyte_job_id,
    created_at, updated_at, last_seen_at
  )
  values (
    p_tenant_id, p_job_id,
    p_job_type, p_orchestrator, p_status,
    p_submitted_by_user_id, p_submitted_by_role, p_submitted_by_team, coalesce(p_visibility, 'Private'),
    p_source, p_destination, p_result_location, p_open_job_link,
    p_airflow_dag_id, p_airflow_dag_run_id, p_airbyte_connection_id, p_airbyte_job_id,
    p_created_at, now(), coalesce(p_seen_at, now())
  )
  on conflict (tenant_id, job_id) do update
  set
    job_type = coalesce(job_summary_index.job_type, excluded.job_type),
    orchestrator = coalesce(job_summary_index.orchestrator, excluded.orchestrator),
    status = excluded.status,

    submitted_by_user_id = coalesce(job_summary_index.submitted_by_user_id, excluded.submitted_by_user_id),
    submitted_by_role    = coalesce(job_summary_index.submitted_by_role, excluded.submitted_by_role),
    submitted_by_team    = coalesce(job_summary_index.submitted_by_team, excluded.submitted_by_team),
    visibility           = coalesce(job_summary_index.visibility, excluded.visibility),

    source          = coalesce(excluded.source, job_summary_index.source),
    destination     = coalesce(excluded.destination, job_summary_index.destination),
    result_location = coalesce(excluded.result_location, job_summary_index.result_location),
    open_job_link   = coalesce(excluded.open_job_link, job_summary_index.open_job_link),

    airflow_dag_id        = coalesce(excluded.airflow_dag_id, job_summary_index.airflow_dag_id),
    airflow_dag_run_id    = coalesce(excluded.airflow_dag_run_id, job_summary_index.airflow_dag_run_id),
    airbyte_connection_id = coalesce(excluded.airbyte_connection_id, job_summary_index.airbyte_connection_id),
    airbyte_job_id        = coalesce(excluded.airbyte_job_id, job_summary_index.airbyte_job_id),

    created_at   = least(job_summary_index.created_at, excluded.created_at),
    updated_at   = now(),
    last_seen_at = greatest(job_summary_index.last_seen_at, excluded.last_seen_at);
end;
$$;

-- Stored proc: upsert connection index (optional for demo, aligns with manager doc)
create or replace function sp_upsert_connection_summary_index(
  p_tenant_id text,
  p_connection_id text,
  p_airbyte_connection_id text,

  p_connection_name text,
  p_source_name text,
  p_destination_name text,

  p_schedule_type text,
  p_schedule_value text,

  p_last_sync_status text,
  p_last_sync_started_at timestamptz,
  p_last_sync_ended_at timestamptz,

  p_created_by_user_id text,
  p_updated_by_user_id text,
  p_created_at timestamptz,
  p_seen_at timestamptz
) returns void
language plpgsql
as $$
begin
  insert into connection_summary_index (
    tenant_id,
    connection_id, airbyte_connection_id,
    connection_name, source_name, destination_name,
    schedule_type, schedule_value,
    last_sync_status, last_sync_started_at, last_sync_ended_at,
    created_by_user_id, updated_by_user_id,
    created_at, updated_at, last_seen_at
  )
  values (
    p_tenant_id,
    p_connection_id, p_airbyte_connection_id,
    p_connection_name, p_source_name, p_destination_name,
    p_schedule_type, p_schedule_value,
    p_last_sync_status, p_last_sync_started_at, p_last_sync_ended_at,
    p_created_by_user_id, p_updated_by_user_id,
    p_created_at, now(), coalesce(p_seen_at, now())
  )
  on conflict (tenant_id, connection_id) do update
  set
    airbyte_connection_id = excluded.airbyte_connection_id,
    connection_name  = excluded.connection_name,
    source_name      = excluded.source_name,
    destination_name = excluded.destination_name,
    schedule_type  = coalesce(excluded.schedule_type, connection_summary_index.schedule_type),
    schedule_value = coalesce(excluded.schedule_value, connection_summary_index.schedule_value),
    last_sync_status     = coalesce(excluded.last_sync_status, connection_summary_index.last_sync_status),
    last_sync_started_at = greatest(connection_summary_index.last_sync_started_at, excluded.last_sync_started_at),
    last_sync_ended_at   = greatest(connection_summary_index.last_sync_ended_at, excluded.last_sync_ended_at),
    created_by_user_id = coalesce(connection_summary_index.created_by_user_id, excluded.created_by_user_id),
    updated_by_user_id = coalesce(excluded.updated_by_user_id, connection_summary_index.updated_by_user_id),
    created_at   = least(connection_summary_index.created_at, excluded.created_at),
    updated_at   = now(),
    last_seen_at = greatest(connection_summary_index.last_seen_at, excluded.last_seen_at);
end;
$$;

-- ✅ FIXED: the function must end with $$; (this was your crash)
create or replace function sp_get_active_jobs_to_poll(
  p_tenant_id text,
  p_max_age_minutes int default 180,
  p_limit int default 200
)
returns table (
  job_id text,
  status text,
  airflow_dag_id text,
  airflow_dag_run_id text,
  airbyte_job_id text,
  airbyte_connection_id text,
  created_at timestamptz,
  updated_at timestamptz
)
language sql
as $$
  select
    job_id, status,
    airflow_dag_id, airflow_dag_run_id,
    airbyte_job_id, airbyte_connection_id,
    created_at, updated_at
  from job_summary_index
  where tenant_id = p_tenant_id
    and status not in ('SUCCEEDED','FAILED','CANCELLED','SKIPPED')
    and created_at >= now() - (p_max_age_minutes || ' minutes')::interval
  order by updated_at desc
  limit p_limit;
$$;

create or replace function sp_get_sync_state(p_tenant_id text, p_tool tool_type)
returns jsonb
language sql
as $$
  select cursor_json
  from sync_state
  where tenant_id = p_tenant_id and tool = p_tool;
$$;

create or replace function sp_upsert_sync_state(
  p_tenant_id text,
  p_tool tool_type,
  p_cursor_json jsonb,
  p_last_error text default null,
  p_success boolean default true
) returns void
language plpgsql
as $$
begin
  insert into sync_state (tenant_id, tool, cursor_json, last_sync_at, last_success_at, last_error, updated_at)
  values (p_tenant_id, p_tool, p_cursor_json, now(),
          case when p_success then now() else null end,
          p_last_error, now())
  on conflict (tenant_id, tool) do update
  set cursor_json     = excluded.cursor_json,
      last_sync_at    = now(),
      last_success_at = case when p_success then now() else sync_state.last_success_at end,
      last_error      = excluded.last_error,
      updated_at      = now();
end;
$$;
-- ------------------------------
-- Minimal extensibility + serving audit additions
-- ------------------------------
do $$ begin
  alter type tool_type add value if not exists 'trino';
exception when duplicate_object then null;
end $$;

do $$ begin
  alter type tool_type add value if not exists 'kafka';
exception when duplicate_object then null;
end $$;

do $$ begin
  alter type tool_type add value if not exists 'sql';
exception when duplicate_object then null;
end $$;

do $$ begin
  alter type tool_type add value if not exists 'nl';
exception when duplicate_object then null;
end $$;

alter table job_summary_index add column if not exists job_name text;
alter table job_summary_index add column if not exists system_type text;
alter table job_summary_index add column if not exists system_name text;

create table if not exists result_access_audit (
  id              bigserial primary key,
  tenant_id       text not null references tenant(tenant_id),
  job_id          text not null,
  access_type     text not null,
  actor_id        text,
  auth_type       text,
  object_key      text,
  status          text not null,
  detail          jsonb not null default '{}'::jsonb,
  created_at      timestamptz not null default now()
);

create index if not exists idx_result_access_audit_job_time
  on result_access_audit(tenant_id, job_id, created_at desc);

create index if not exists idx_result_access_audit_access_type_time
  on result_access_audit(tenant_id, access_type, created_at desc);
