#!/bin/bash
set -euo pipefail

normalize_bool() {
  local value="${1:-}"
  value="$(printf '%s' "$value" | tr '[:upper:]' '[:lower:]')"
  case "$value" in
    1|true|yes|y|on) return 0 ;;
    *) return 1 ;;
  esac
}

if ! normalize_bool "${BOOTSTRAP_SEED_ENABLED:-true}"; then
  echo "[seed] BOOTSTRAP_SEED_ENABLED=false, skipping seed bootstrap"
  exit 0
fi

# Safe default for discovery job type map JSON.
# Keep this outside the psql command so shell quoting does not corrupt JSON.
discovery_job_type_map_json="${DISCOVERY_JOB_TYPE_MAP_JSON:-}"
if [ -z "$discovery_job_type_map_json" ]; then
  discovery_job_type_map_json='{"dp_job_dispatcher":"Ingestion"}'
fi

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" --dbname "$POSTGRES_DB" \
  -v tenant_id="${DEFAULT_TENANT_ID:-demo}" \
  -v tenant_name="${DEFAULT_TENANT_NAME:-Demo Tenant}" \
  -v airflow_enabled="${BOOTSTRAP_AIRFLOW_ENABLED:-true}" \
  -v airbyte_enabled="${BOOTSTRAP_AIRBYTE_ENABLED:-true}" \
  -v airflow_base_url="${AIRFLOW_BASE_URL:-http://host.docker.internal:18080}" \
  -v airflow_ui_base_url="${AIRFLOW_UI_BASE_URL:-http://localhost:18080}" \
  -v airflow_auth_mode="${AIRFLOW_AUTH_MODE:-basic}" \
  -v airflow_username="${AIRFLOW_USERNAME:-admin}" \
  -v airflow_password="${AIRFLOW_PASSWORD:-ADMIN}" \
  -v airflow_bearer_token="${AIRFLOW_BEARER_TOKEN:-}" \
  -v airbyte_base_url="${AIRBYTE_BASE_URL:-http://host.docker.internal:18000}" \
  -v discovery_dag_ids="${DISCOVERY_DAG_IDS:-dp_job_dispatcher}" \
  -v discovery_default_visibility="${DISCOVERY_DEFAULT_VISIBILITY:-Global}" \
  -v discovery_run_type_filter="${DISCOVERY_RUN_TYPE_FILTER:-all}" \
  -v discovery_job_type_map_json="$discovery_job_type_map_json" <<'SQL'
insert into tenant(tenant_id, tenant_name)
values (:'tenant_id', :'tenant_name')
on conflict (tenant_id) do update
set tenant_name = excluded.tenant_name,
    updated_at = now();

insert into tool_instance(tenant_id, tool, base_url, auth_ref, is_active)
select
  :'tenant_id',
  'airflow'::tool_type,
  :'airflow_base_url',
  jsonb_strip_nulls(
    jsonb_build_object(
      'ui_base_url', nullif(:'airflow_ui_base_url', ''),
      'auth_mode', nullif(:'airflow_auth_mode', ''),
      'username', nullif(:'airflow_username', ''),
      'password', nullif(:'airflow_password', ''),
      'bearer_token', nullif(:'airflow_bearer_token', ''),
      'discovery_dag_ids',
        case
          when nullif(:'discovery_dag_ids', '') is null then null
          else to_jsonb(string_to_array(:'discovery_dag_ids', ','))
        end,
      'job_type_map',
        case
          when nullif(:'discovery_job_type_map_json', '') is null then null
          else (:'discovery_job_type_map_json')::jsonb
        end,
      'default_visibility', nullif(:'discovery_default_visibility', ''),
      'discovery_run_type_filter', nullif(:'discovery_run_type_filter', '')
    )
  )::text,
  true
where lower(:'airflow_enabled') in ('1','true','yes','y','on')
on conflict (tenant_id, tool) do update
set base_url = excluded.base_url,
    auth_ref = excluded.auth_ref,
    is_active = true,
    updated_at = now();

insert into tool_instance(tenant_id, tool, base_url, auth_ref, is_active)
select
  :'tenant_id',
  'airbyte'::tool_type,
  :'airbyte_base_url',
  ''::text,
  true
where lower(:'airbyte_enabled') in ('1','true','yes','y','on')
  and nullif(:'airbyte_base_url', '') is not null
on conflict (tenant_id, tool) do update
set base_url = excluded.base_url,
    auth_ref = excluded.auth_ref,
    is_active = true,
    updated_at = now();
SQL
