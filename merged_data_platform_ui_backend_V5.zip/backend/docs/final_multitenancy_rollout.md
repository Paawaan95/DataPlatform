# Final multitenancy rollout

This package has been updated so deploy-time configuration is read from `.env` instead of being scattered across:
- Docker Compose
- bootstrap seed SQL
- API defaults
- worker Airflow client defaults

## Runtime components covered
- `dp_control_api`
- `dp_control_fast_worker`
- `dp_control_slow_worker`
- `dp_control_pg`

## Centralized config sources
Use these files only:
- `.env`
- `.env.example`

## Important
For client deployment, change only the values in `.env` and then restart the stack.

## Main knobs
- PostgreSQL credentials and ports
- API port
- default tenant seed values
- Airflow base URL, UI URL, credentials, timeout
- Airbyte base URL
- discovery loop cadence and DAG defaults
- seed enablement flags

## PowerShell restart
```powershell
docker compose down
docker compose up -d --build
```
