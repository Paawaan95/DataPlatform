# MinIO consumer-serving layer

This package adds a backend-owned consumer-serving layer on top of `job_summary_index.result_location`.

## What the backend now owns
- translating `job_id` -> serving metadata
- translating `job_id` -> object listing under the result prefix
- translating `job_id` -> preview rows for CSV / JSON / Parquet
- generating short-lived presigned download URLs
- recording serving access audit events when the audit table exists

## Security boundary
- the browser never receives permanent MinIO root/access secrets
- the browser only calls backend APIs
- download access is returned as short-lived backend-issued presigned URLs
- bearer/API-key auth can be enabled through `.env`

## Scope of this implementation
- optimized for the current Data Platform Job Details / Consumer Results flow
- backward compatible with existing UI tabs and existing DB rows
- safe against empty `result_location` and older databases without the new audit table
