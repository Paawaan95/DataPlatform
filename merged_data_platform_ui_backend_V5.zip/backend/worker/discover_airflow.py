from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from app.clients.airflow_client import airflow_ui_run_link, list_dag_runs, list_dags, normalize_state
from app.config import settings
from app.sql_repo import (
    fetch_tool_instance,
    get_or_create_job_id_for_airflow_run,
    get_sync_state,
    list_active_tenant_ids,
    log_event,
    upsert_job_summary,
    upsert_sync_state,
    utc_now,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
LOGGER = logging.getLogger(__name__)
DISCOVERY_CURSOR_KEY = "discover_airflow"
ALLOWED_VISIBILITIES = {"PRIVATE": "Private", "TEAM": "Team", "GLOBAL": "Global"}


def parse_dt(value: Any) -> datetime | None:
    if not value:
        return None
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=timezone.utc)
    text = str(value).strip()
    if not text:
        return None
    if text.endswith("Z"):
        text = text[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(text)
    except ValueError:
        return None
    return dt if dt.tzinfo else dt.replace(tzinfo=timezone.utc)


def airflow_run_timestamp(run: dict[str, Any]) -> datetime | None:
    for key in ("end_date", "start_date", "last_scheduling_decision", "logical_date", "execution_date", "queued_at"):
        dt = parse_dt(run.get(key))
        if dt:
            return dt
    return None


def normalize_visibility(value: str | None) -> str:
    return ALLOWED_VISIBILITIES.get(str(value or "Global").strip().upper(), "Global")


def dag_job_type(airflow: dict[str, Any], dag_id: str) -> str:
    job_type_map = airflow.get("job_type_map") or {}
    if isinstance(job_type_map, dict) and dag_id in job_type_map:
        return str(job_type_map[dag_id])
    return "Airflow DAG Run"


def discovery_run_type_filter(airflow: dict[str, Any]) -> str:
    value = str(airflow.get("discovery_run_type_filter") or settings.DISCOVERY_RUN_TYPE_FILTER or "all").strip().lower()
    if value in {"manual_only", "scheduled_only", "all"}:
        return value
    return "all"


def run_matches_filter(run: dict[str, Any], run_filter: str) -> bool:
    if run_filter == "all":
        return True
    run_type = str(run.get("run_type") or "").strip().lower()
    external_trigger = bool(run.get("external_trigger"))
    is_manual = run_type == "manual" or external_trigger
    is_scheduled = run_type == "scheduled" or (run_type == "" and not external_trigger)
    if run_filter == "manual_only":
        return is_manual
    if run_filter == "scheduled_only":
        return is_scheduled
    return True


def sort_runs_desc(runs: list[dict[str, Any]]) -> list[dict[str, Any]]:
    return sorted(runs, key=lambda run: airflow_run_timestamp(run) or datetime.min.replace(tzinfo=timezone.utc), reverse=True)


def get_cursor_state(cursor_json: dict[str, Any]) -> dict[str, Any]:
    raw = cursor_json.get(DISCOVERY_CURSOR_KEY, {})
    if not isinstance(raw, dict):
        raw = {}
    dag_watermarks = raw.get("dag_watermarks")
    if not isinstance(dag_watermarks, dict):
        # backward compat with the older shape where discover_airflow was {dag_id: ts}
        dag_watermarks = {k: v for k, v in raw.items() if isinstance(v, str)}
    return {
        "runs_watermark_ts": raw.get("runs_watermark_ts"),
        "last_active_poll_ts": raw.get("last_active_poll_ts"),
        "lookback_seconds": int(raw.get("lookback_seconds") or settings.DISCOVERY_LOOKBACK_SECONDS),
        "active_poll_window_minutes": int(raw.get("active_poll_window_minutes") or settings.DISCOVERY_ACTIVE_POLL_WINDOW_MINUTES),
        "dag_watermarks": dag_watermarks,
    }


def set_cursor_state(cursor_json: dict[str, Any], state: dict[str, Any]) -> None:
    cursor_json[DISCOVERY_CURSOR_KEY] = {
        "runs_watermark_ts": state.get("runs_watermark_ts"),
        "last_active_poll_ts": state.get("last_active_poll_ts"),
        "lookback_seconds": state.get("lookback_seconds"),
        "active_poll_window_minutes": state.get("active_poll_window_minutes"),
        "dag_watermarks": state.get("dag_watermarks", {}),
    }


def compute_since_ts(now: datetime, state: dict[str, Any], dag_id: str) -> datetime:
    dag_watermarks = state.get("dag_watermarks") or {}
    dag_watermark = parse_dt(dag_watermarks.get(dag_id))
    global_watermark = parse_dt(state.get("runs_watermark_ts"))
    lookback = timedelta(seconds=int(state.get("lookback_seconds") or settings.DISCOVERY_LOOKBACK_SECONDS))
    active_window = timedelta(minutes=int(state.get("active_poll_window_minutes") or settings.DISCOVERY_ACTIVE_POLL_WINDOW_MINUTES))
    bootstrap_window = timedelta(minutes=settings.DISCOVERY_BOOTSTRAP_LOOKBACK_MINUTES)

    candidates: list[datetime] = [now - active_window]
    if dag_watermark:
        candidates.append(dag_watermark - lookback)
    elif global_watermark:
        candidates.append(global_watermark - lookback)
    else:
        candidates.append(now - bootstrap_window)
    return max(candidates)


def maybe_recent_tail_offsets(total_entries: int | None, page_size: int) -> list[int]:
    if not total_entries or total_entries <= 0:
        return []
    last_page_offset = max(total_entries - page_size, 0)
    second_last = max(total_entries - (2 * page_size), 0)
    offsets = [last_page_offset]
    if second_last != last_page_offset:
        offsets.append(second_last)
    return offsets


async def resolve_discovery_dag_ids(airflow: dict[str, Any]) -> list[str]:
    configured = [str(item).strip() for item in (airflow.get("discovery_dag_ids") or []) if str(item).strip()]
    if configured and configured != ["*"] and "*" not in configured:
        return configured
    if not configured and not settings.DISCOVERY_SCAN_ALL_DAGS:
        return []

    dag_ids: list[str] = []
    limit = 100
    offset = 0
    for _ in range(10):
        data = await list_dags(airflow, limit=limit, offset=offset, only_active=True)
        rows = data.get("dags") or []
        if not rows:
            break
        dag_ids.extend(str(row.get("dag_id")).strip() for row in rows if str(row.get("dag_id", "")).strip())
        if len(rows) < limit:
            break
        offset += limit
    return sorted(set(dag_ids))


async def fetch_candidate_runs(airflow: dict[str, Any], dag_id: str, since_ts: datetime) -> list[dict[str, Any]]:
    page_size = settings.DISCOVERY_DAG_RUN_PAGE_SIZE
    run_filter = discovery_run_type_filter(airflow)
    candidates: list[dict[str, Any]] = []
    seen_pairs: set[tuple[str, str]] = set()

    first_page = await list_dag_runs(
        airflow,
        dag_id,
        limit=page_size,
        offset=0,
        order_by=settings.DISCOVERY_ORDER_BY or None,
        extra_filters={"start_date_gte": since_ts.isoformat()},
    )
    pages = [first_page]

    newest_seen = max((airflow_run_timestamp(run) or datetime.min.replace(tzinfo=timezone.utc) for run in first_page.get("dag_runs") or []), default=datetime.min.replace(tzinfo=timezone.utc))

    # Fallback: if the API ignored ordering/filtering and returned only old pages, fetch from the tail too.
    if newest_seen < since_ts:
        for tail_offset in maybe_recent_tail_offsets(first_page.get("total_entries"), page_size):
            if tail_offset == 0:
                continue
            pages.append(
                await list_dag_runs(
                    airflow,
                    dag_id,
                    limit=page_size,
                    offset=tail_offset,
                    order_by=None,
                    extra_filters=None,
                )
            )

    for page in pages:
        for run in sort_runs_desc(list(page.get("dag_runs") or [])):
            dag_run_id = str(run.get("dag_run_id") or run.get("run_id") or "").strip()
            if not dag_run_id:
                continue
            pair = (dag_id, dag_run_id)
            if pair in seen_pairs:
                continue
            seen_pairs.add(pair)
            if not run_matches_filter(run, run_filter):
                continue
            run_ts = airflow_run_timestamp(run)
            if run_ts and run_ts < since_ts:
                continue
            candidates.append(run)

    return sort_runs_desc(candidates)[: settings.DISCOVERY_MAX_RUNS_PER_DAG_PER_LOOP]


async def discover_recent_runs_for_dag(
    tenant_id: str,
    airflow: dict[str, Any],
    dag_id: str,
    state: dict[str, Any],
) -> tuple[datetime, int]:
    now = utc_now()
    since_ts = compute_since_ts(now, state, dag_id)
    runs = await fetch_candidate_runs(airflow, dag_id, since_ts)

    discovered_count = 0
    latest_seen = parse_dt((state.get("dag_watermarks") or {}).get(dag_id)) or since_ts

    for run in runs:
        dag_run_id = run.get("dag_run_id") or run.get("run_id")
        if not dag_run_id:
            continue

        run_ts = airflow_run_timestamp(run) or now
        latest_seen = max(latest_seen, run_ts)
        state_name = normalize_state(run)
        visibility = normalize_visibility(airflow.get("default_visibility"))
        open_job_link = airflow_ui_run_link(airflow, dag_id, dag_run_id)

        job_id = get_or_create_job_id_for_airflow_run(
            tenant_id,
            dag_id,
            dag_run_id,
            external_url=open_job_link,
        )
        upsert_job_summary(
            tenant_id=tenant_id,
            job_id=job_id,
            job_type=dag_job_type(airflow, dag_id),
            orchestrator="Airflow",
            status=state_name,
            visibility=visibility,
            submitted_by_user_id="system:airflow-discovery",
            submitted_by_role="System",
            submitted_by_team="Platform",
            open_job_link=open_job_link,
            airflow_dag_id=dag_id,
            airflow_dag_run_id=dag_run_id,
            created_at=run_ts,
            seen_at=now,
        )
        discovered_count += 1

    log_event(
        tenant_id,
        "airflow",
        "SLOW_DISCOVER_DAG_RUNS",
        external_id=dag_id,
        payload={
            "since_ts": since_ts.isoformat(),
            "latest_seen": latest_seen.isoformat(),
            "returned_runs": len(runs),
            "upserts": discovered_count,
            "run_type_filter": discovery_run_type_filter(airflow),
        },
    )

    return latest_seen, discovered_count


async def discover_once(tenant_id: str):
    airflow = fetch_tool_instance(tenant_id, "airflow")
    if not airflow:
        LOGGER.info("Skipping discovery tenant=%s because airflow tool_instance is missing", tenant_id)
        return

    dag_ids = await resolve_discovery_dag_ids(airflow)
    if not dag_ids:
        LOGGER.info("Skipping discovery tenant=%s because no dag ids are configured", tenant_id)
        return

    cursor_json = get_sync_state(tenant_id, "airflow")
    state = get_cursor_state(cursor_json)
    discovered_total = 0
    global_latest = parse_dt(state.get("runs_watermark_ts")) or utc_now() - timedelta(minutes=settings.DISCOVERY_BOOTSTRAP_LOOKBACK_MINUTES)

    for dag_id in dag_ids:
        try:
            latest_seen, discovered_count = await discover_recent_runs_for_dag(tenant_id, airflow, dag_id, state)
            state.setdefault("dag_watermarks", {})[dag_id] = latest_seen.isoformat()
            global_latest = max(global_latest, latest_seen)
            discovered_total += discovered_count
        except Exception as exc:
            LOGGER.exception("Discovery error tenant=%s dag_id=%s", tenant_id, dag_id)
            log_event(
                tenant_id,
                "airflow",
                "SLOW_DISCOVER_ERROR",
                external_id=dag_id,
                payload={"error": str(exc)},
            )
            state["runs_watermark_ts"] = global_latest.isoformat()
            state["last_active_poll_ts"] = utc_now().isoformat()
            set_cursor_state(cursor_json, state)
            upsert_sync_state(tenant_id, "airflow", cursor_json, last_error=str(exc), success=False)
            continue

    state["runs_watermark_ts"] = global_latest.isoformat()
    state["last_active_poll_ts"] = utc_now().isoformat()
    set_cursor_state(cursor_json, state)
    upsert_sync_state(tenant_id, "airflow", cursor_json, last_error=None, success=True)
    LOGGER.info(
        "Discovery tenant=%s dags=%s upserts=%s watermark=%s",
        tenant_id,
        len(dag_ids),
        discovered_total,
        state["runs_watermark_ts"],
    )


async def main():
    while True:
        for tenant_id in list_active_tenant_ids():
            await discover_once(tenant_id)
        await asyncio.sleep(settings.SLOW_DISCOVERY_SECONDS)


if __name__ == "__main__":
    asyncio.run(main())
