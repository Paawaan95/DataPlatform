from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from app.config import settings
from app.clients.airflow_client import get_dag_run, normalize_state
from app.sql_repo import (
    fetch_tool_instance,
    get_active_jobs_to_poll,
    list_active_tenant_ids,
    log_event,
    upsert_job_summary,
)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
LOGGER = logging.getLogger(__name__)
TERMINAL = {"SUCCEEDED", "FAILED", "CANCELLED", "SKIPPED"}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


async def poll_once():
    for tenant_id in list_active_tenant_ids():
        airflow = fetch_tool_instance(tenant_id, "airflow")
        if not airflow:
            LOGGER.info("Skipping tenant=%s because airflow tool_instance is missing", tenant_id)
            continue

        active_rows = get_active_jobs_to_poll(tenant_id, max_age_minutes=10080, limit=200)
        LOGGER.info("Polling tenant=%s active_jobs=%s", tenant_id, len(active_rows))

        for row in active_rows:
            status = str(row.get("status") or "").upper()
            if status in TERMINAL:
                continue

            dag_id = row.get("airflow_dag_id")
            dag_run_id = row.get("airflow_dag_run_id")
            if not dag_id or not dag_run_id:
                continue

            try:
                af = await get_dag_run(airflow, dag_id, dag_run_id)
                if not af:
                    continue
                new_status = normalize_state(af)
                if new_status != status:
                    log_event(
                        tenant_id,
                        "airflow",
                        "POLL_DAG_RUN",
                        external_id=dag_id,
                        external_sub_id=dag_run_id,
                        payload={"job_id": row["job_id"], "from": status, "to": new_status},
                    )

                upsert_job_summary(
                    tenant_id=tenant_id,
                    job_id=row["job_id"],
                    job_type="Unknown",
                    orchestrator="Airflow",
                    status=new_status,
                    visibility="Private",
                    airflow_dag_id=dag_id,
                    airflow_dag_run_id=dag_run_id,
                    airbyte_connection_id=row.get("airbyte_connection_id"),
                    airbyte_job_id=row.get("airbyte_job_id"),
                    created_at=row["created_at"],
                    seen_at=utc_now(),
                )
            except Exception as exc:
                LOGGER.exception("Poll error tenant=%s dag_id=%s dag_run_id=%s", tenant_id, dag_id, dag_run_id)
                log_event(
                    tenant_id,
                    "airflow",
                    "POLL_ERROR",
                    external_id=dag_id,
                    external_sub_id=dag_run_id,
                    payload={"error": str(exc)},
                )


async def main():
    while True:
        await poll_once()
        await asyncio.sleep(settings.POLL_SECONDS)


if __name__ == "__main__":
    asyncio.run(main())
