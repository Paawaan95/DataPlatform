from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone

from app.clients.airbyte_client import get_job, normalize_airbyte_status
from app.config import settings
from app.sql_repo import (
    fetch_tool_instance,
    get_active_jobs_to_poll,
    list_active_tenant_ids,
    log_event,
    upsert_job_summary,
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
LOGGER = logging.getLogger(__name__)
TERMINAL = {'SUCCEEDED', 'FAILED', 'CANCELLED', 'SKIPPED'}


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


async def poll_once():
    for tenant_id in list_active_tenant_ids():
        airbyte = fetch_tool_instance(tenant_id, 'airbyte')
        if not airbyte:
            continue

        active_rows = get_active_jobs_to_poll(tenant_id, max_age_minutes=10080, limit=200)
        for row in active_rows:
            status = str(row.get('status') or '').upper()
            if status in TERMINAL:
                continue
            airbyte_job_id = str(row.get('airbyte_job_id') or '').strip()
            if not airbyte_job_id:
                continue
            try:
                payload = get_job(airbyte, airbyte_job_id)
                if not payload:
                    continue
                new_status = normalize_airbyte_status(payload)
                if new_status != status:
                    log_event(
                        tenant_id,
                        'airbyte',
                        'POLL_AIRBYTE_JOB',
                        external_id=airbyte_job_id,
                        external_sub_id=row.get('airbyte_connection_id'),
                        payload={'job_id': row['job_id'], 'from': status, 'to': new_status},
                    )
                upsert_job_summary(
                    tenant_id=tenant_id,
                    job_id=row['job_id'],
                    job_type=row.get('job_type') or 'Ingestion',
                    orchestrator=row.get('orchestrator') or 'Airbyte',
                    status=new_status,
                    visibility=row.get('visibility') or 'Private',
                    airflow_dag_id=row.get('airflow_dag_id'),
                    airflow_dag_run_id=row.get('airflow_dag_run_id'),
                    airbyte_connection_id=row.get('airbyte_connection_id'),
                    airbyte_job_id=airbyte_job_id,
                    submitted_by_user_id=row.get('submitted_by_user_id'),
                    submitted_by_role=row.get('submitted_by_role'),
                    submitted_by_team=row.get('submitted_by_team'),
                    source=row.get('source'),
                    destination=row.get('destination'),
                    result_location=row.get('result_location'),
                    open_job_link=row.get('open_job_link'),
                    created_at=row['created_at'],
                    seen_at=utc_now(),
                )
            except Exception as exc:
                LOGGER.exception('Airbyte poll error tenant=%s job=%s', tenant_id, airbyte_job_id)
                log_event(
                    tenant_id,
                    'airbyte',
                    'POLL_ERROR',
                    external_id=airbyte_job_id,
                    external_sub_id=row.get('airbyte_connection_id'),
                    payload={'error': str(exc)},
                )


async def main():
    while True:
        await poll_once()
        await asyncio.sleep(settings.POLL_SECONDS)


if __name__ == '__main__':
    asyncio.run(main())
