from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timedelta, timezone
from typing import Any

from app.clients.airbyte_client import airbyte_ui_job_link, job_timestamps, list_connections, list_jobs_for_connection, normalize_airbyte_status
from app.config import settings
from app.sql_repo import (
    fetch_tool_instance,
    get_or_create_connection_id_for_airbyte_connection,
    get_or_create_job_id_for_airbyte_job,
    get_sync_state,
    list_active_tenant_ids,
    log_event,
    upsert_connection_summary,
    upsert_job_summary,
    upsert_sync_state,
    utc_now,
)

logging.basicConfig(level=logging.INFO, format='%(asctime)s %(levelname)s %(message)s')
LOGGER = logging.getLogger(__name__)
AIRBYTE_CURSOR_KEY = 'discover_airbyte'


def parse_dt(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        return datetime.fromisoformat(str(value).replace('Z', '+00:00')).astimezone(timezone.utc)
    except Exception:
        return None


def _cursor(cursor_json: dict[str, Any]) -> dict[str, Any]:
    raw = cursor_json.get(AIRBYTE_CURSOR_KEY, {})
    return raw if isinstance(raw, dict) else {}


def _set_cursor(cursor_json: dict[str, Any], state: dict[str, Any]) -> None:
    cursor_json[AIRBYTE_CURSOR_KEY] = state


async def discover_once(tenant_id: str):
    airbyte = fetch_tool_instance(tenant_id, 'airbyte')
    if not airbyte:
        return

    cursor_json = get_sync_state(tenant_id, 'airbyte')
    state = _cursor(cursor_json)
    watermark = parse_dt(state.get('jobs_last_seen_at')) or (utc_now() - timedelta(hours=settings.AIRBYTE_LOOKBACK_HOURS))
    latest_seen = watermark

    connections = list_connections(airbyte)
    for connection in connections[: settings.AIRBYTE_CONNECTION_LIMIT]:
        connection_id = str(connection.get('connectionId') or connection.get('connection_id') or '').strip()
        if not connection_id:
            continue
        connection_name = str(connection.get('name') or connection_id)
        platform_conn_id = get_or_create_connection_id_for_airbyte_connection(
            tenant_id,
            connection_id,
            external_url=airbyte_ui_job_link(airbyte, connection_id=connection_id),
        )
        upsert_connection_summary(
            tenant_id=tenant_id,
            connection_id=platform_conn_id,
            airbyte_connection_id=connection_id,
            connection_name=connection_name,
            source_name=str((connection.get('source') or {}).get('name') or connection.get('sourceName') or ''),
            destination_name=str((connection.get('destination') or {}).get('name') or connection.get('destinationName') or ''),
            schedule_type=str((connection.get('schedule') or {}).get('type') or connection.get('scheduleType') or ''),
            schedule_value=str(connection.get('scheduleData') or connection.get('schedule') or ''),
            last_sync_status=str(connection.get('status') or ''),
        )

        for job in list_jobs_for_connection(airbyte, connection_id):
            job_id_raw = str((job.get('job') or {}).get('id') or job.get('jobId') or job.get('id') or '').strip()
            if not job_id_raw:
                continue
            started_at, ended_at = job_timestamps(job)
            seen_at = ended_at or started_at or utc_now()
            if seen_at < watermark:
                continue
            latest_seen = max(latest_seen, seen_at)
            open_job_link = airbyte_ui_job_link(airbyte, connection_id=connection_id, job_id=job_id_raw)
            job_id = get_or_create_job_id_for_airbyte_job(tenant_id, job_id_raw, connection_id, external_url=open_job_link)
            upsert_job_summary(
                tenant_id=tenant_id,
                job_id=job_id,
                job_type='Ingestion',
                orchestrator='Airbyte',
                status=normalize_airbyte_status(job),
                visibility=airbyte.get('default_visibility') or settings.DISCOVERY_DEFAULT_VISIBILITY,
                submitted_by_user_id='system:airbyte-discovery',
                submitted_by_role='System',
                submitted_by_team='Platform',
                source=str((connection.get('source') or {}).get('name') or connection.get('sourceName') or ''),
                destination=str((connection.get('destination') or {}).get('name') or connection.get('destinationName') or ''),
                open_job_link=open_job_link,
                airbyte_connection_id=connection_id,
                airbyte_job_id=job_id_raw,
                created_at=started_at or seen_at,
                seen_at=utc_now(),
            )
    _set_cursor(cursor_json, {'jobs_last_seen_at': latest_seen.isoformat()})
    upsert_sync_state(tenant_id, 'airbyte', cursor_json, success=True)
    log_event(tenant_id, 'airbyte', 'SLOW_DISCOVER_JOBS', payload={'connections': len(connections), 'latest_seen': latest_seen.isoformat()})


async def main():
    while True:
        for tenant_id in list_active_tenant_ids():
            try:
                await discover_once(tenant_id)
            except Exception as exc:
                LOGGER.exception('Airbyte discovery error tenant=%s', tenant_id)
                log_event(tenant_id, 'airbyte', 'SLOW_DISCOVER_ERROR', payload={'error': str(exc)})
        await asyncio.sleep(settings.SLOW_DISCOVERY_SECONDS)


if __name__ == '__main__':
    asyncio.run(main())
