# Merged Data Platform UI + Backend (centralized `.env`)

This package keeps the **UI** and **backend** codebases separate, but runs them from a single folder with one root `.env`.

## Patch level
This bundle includes the earlier serving-layer hardening plus a new production-oriented patch for:
- **SFTPGo-based SFTP serving**
- **OIDC/JWKS-capable auth**
- **Airbyte runtime workers**
- **DuckDB-backed Parquet preview**
- **runtime registration for Airflow, Airbyte, Trino, Kafka, SQL, and NL jobs**

## Key capabilities in this patched build
- backend-owned Job Details consumer-serving layer for MinIO-backed job outputs
- `GET /v1/jobs/{job_id}/serving`
- `GET /v1/jobs/{job_id}/objects`
- `GET /v1/jobs/{job_id}/preview`
- `POST /v1/jobs/{job_id}/download-url`
- `POST /v1/jobs/{job_id}/sftp-publish`
- fallback lineage API for Job Details
- centralized auth + MinIO + SFTPGo config in root `.env`
- MinIO service + bucket init helper in Docker Compose
- real local SFTPGo service with per-tenant provisioning for published results
- internal vs public MinIO endpoint split for presigned browser downloads
- explicit SFTP publish flow; `GET /serving` is read-only by default
- object-aware UI for preview/download/SFTP when a job has multi-file output
- seed + smoke scripts for local validation

## Folder layout
- `backend/` -> FastAPI API, workers, SQL, Dockerfile, scripts
- `ui/` -> Streamlit UI
- `runtime/sftpgo/data/exports/` -> shared export root used by backend + SFTPGo
- `.env` -> centralized runtime configuration
- `docker-compose.yml` -> Postgres + MinIO + MinIO bucket init + SFTPGo + backend API + workers

## Run backend stack
```powershell
cd <extracted-folder>
docker compose up -d --build
```

Default endpoints after startup:
- API: `http://127.0.0.1:8199`
- Postgres: `localhost:5435`
- MinIO API: `http://127.0.0.1:9000`
- MinIO Console: `http://127.0.0.1:9001`
- SFTP: `127.0.0.1:2222`
- SFTPGo Admin/API: `http://127.0.0.1:8080`

## Seed demo result objects + a demo job row
```powershell
docker compose exec dp_control_api python /app/scripts/seed_demo_result.py
```

## Run serving smoke test
```powershell
docker compose exec dp_control_api python /app/scripts/smoke_result_serving.py
```

## Run UI
```powershell
cd <extracted-folder>\ui
python -m streamlit run app.py
```

## Important notes
1. Use `MINIO_INTERNAL_ENDPOINT=minio:9000` for backend/container traffic and `MINIO_PUBLIC_ENDPOINT=127.0.0.1:9000` for browser-facing presigned URLs.
2. `GET /v1/jobs/{job_id}/serving` is read-only by default; explicit publish happens through `POST /v1/jobs/{job_id}/sftp-publish`.
3. SFTPGo user provisioning is deterministic for local/dev. For production, replace that with one-time credentials or SSH-key provisioning plus secret management.
4. If you already have an existing Postgres volume, SQL changes under `backend/sql/` will not auto-run until you reset the volume or apply the SQL manually.
