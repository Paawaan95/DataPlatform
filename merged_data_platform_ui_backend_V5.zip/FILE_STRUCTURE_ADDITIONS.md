# File structure additions for API + serving + production-oriented patch

## New backend files
- `backend/app/clients/airbyte_client.py` — Airbyte API client helpers for connections, jobs, status normalization, and UI links
- `backend/app/services/sftpgo.py` — SFTPGo admin/API integration for tenant-scoped user provisioning
- `backend/worker/poll_airbyte.py` — fast Airbyte job-status polling loop
- `backend/worker/discover_airbyte.py` — slower Airbyte connection/job discovery loop
- `backend/scripts/hash_api_key.py` — helper to generate SHA-256 API-key entries for `API_KEYS_JSON`
- `backend/scripts/seed_demo_result.py` — demo object and job seeding
- `backend/scripts/smoke_result_serving.py` — local serving smoke test

## Updated backend files
- `backend/app/config.py`
  - added OIDC/JWKS auth settings
  - added Airbyte auth/UI settings
  - added SFTPGo settings
  - added DuckDB-backed Parquet preview settings
- `backend/app/auth.py`
  - added OIDC discovery and JWKS validation
  - added stronger claim extraction
  - added hashed API key support
  - widened required scopes to include `jobs:register`
- `backend/app/services/object_store.py`
  - uses MinIO internal vs public endpoint split
  - validates requested object keys against job result scope
  - adds DuckDB-first Parquet preview path
- `backend/app/services/sftp_export.py`
  - moved publication/status flow onto SFTPGo-oriented export handling
- `backend/app/routes/jobs.py`
  - preserved existing serving routes
  - added runtime registration for Airflow, Airbyte, Trino, Kafka, SQL, and NL jobs
  - keeps `GET /serving` read-only and `POST /sftp-publish` explicit
- `backend/app/routes/admin.py`
  - richer bootstrap payload for Airbyte auth/UI config
- `backend/app/sql_repo.py`
  - tool-instance config now resolves Airbyte UI/auth metadata
  - generic binding helpers for Airflow and Airbyte
  - connection upsert helpers
- `backend/requirements.txt`
  - added `duckdb`
- `backend/docker-compose.yml`
  - aligned with root Compose and now includes SFTPGo + Airbyte workers

## Updated root/infrastructure files
- `docker-compose.yml`
  - replaced local demo SFTP container with `drakkan/sftpgo`
  - added MinIO bucket init helper
  - added Airbyte workers
- `.env`
- `.env.example`
- `backend/.env.example`
  - now include OIDC/JWKS, Airbyte, SFTPGo, and Parquet-query settings
- `runtime/sftpgo/data/exports/`
  - shared export root used by backend API and SFTPGo

## Updated UI files
- `ui/ui/components/serving.py`
- `ui/ui/components/serving_tabs/api.py`
- `ui/ui/components/serving_tabs/sftp.py`
- `ui/ui/components/serving_tabs/download.py`
- `ui/ui/components/serving_tabs/sample_preview.py`
- `ui/ui/pages/common/job_details.py`
- `ui/ui/services/ledger_api.py`
  - object-aware preview/download/SFTP UX for multi-file outputs
