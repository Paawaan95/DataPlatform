This package restores the Job Details flow to the backup-compatible implementation and fixes centralized .env loading.

Files restored/added:
- ui/app.py
- ui/ui/settings.py
- ui/ui/services/ledger_api.py
- ui/ui/services/job_detail_view.py
- ui/ui/pages/common/job_details.py
- ui/ui/pages/common/lineage.py
- ui/ui/components/serving.py

Extra change:
- Job Details now shows ledger_api_error visibly when backend fetch fails.
