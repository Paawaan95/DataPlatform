$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot
python -m pip install -r .\ui\requirements.txt
python -m streamlit run .\ui\app.py
