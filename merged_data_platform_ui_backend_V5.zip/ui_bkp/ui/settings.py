from __future__ import annotations

import json
import os
from typing import Any


def env_str(name: str, default: str = "") -> str:
    value = os.getenv(name)
    if value is None:
        return default
    return str(value).strip()


def env_bool(name: str, default: bool = False) -> bool:
    value = os.getenv(name)
    if value is None:
        return default
    return str(value).strip().lower() in {"1", "true", "yes", "on"}


def env_int(name: str, default: int) -> int:
    value = os.getenv(name)
    if value is None:
        return default
    try:
        return int(str(value).strip())
    except Exception:
        return default


def env_json(name: str, default: Any) -> Any:
    raw = os.getenv(name)
    if raw is None or not str(raw).strip():
        return default
    try:
        return json.loads(raw)
    except Exception:
        return default


PLATFORM_NAME = env_str("PLATFORM_NAME", "Data Platform Console")
STREAMLIT_PAGE_TITLE = env_str("STREAMLIT_PAGE_TITLE", PLATFORM_NAME)
UI_SHOW_MOCK_BADGE = env_bool("UI_SHOW_MOCK_BADGE", False)

LEDGER_DEFAULT_TENANT = env_str("LEDGER_DEFAULT_TENANT", "default")
LEDGER_FETCH_LIMIT = env_int("LEDGER_FETCH_LIMIT", 5000)

AIRFLOW_UI_BASE_URL = env_str("AIRFLOW_UI_BASE_URL", env_str("AIRFLOW_BASE_URL", "http://localhost:18080"))
AIRBYTE_UI_BASE_URL = env_str("AIRBYTE_UI_BASE_URL", env_str("AIRBYTE_BASE_URL", "http://localhost:18000"))
OPENMETADATA_UI_BASE_URL = env_str("OPENMETADATA_UI_BASE_URL", env_str("OPENMETADATA_BASE_URL", "http://localhost:8585"))

STORAGE_URI_PREFIX = env_str("STORAGE_URI_PREFIX", "s3://minio")
STORAGE_FEAST_PREFIX = env_str("STORAGE_FEAST_PREFIX", f"{STORAGE_URI_PREFIX.rstrip('/')}/feast")
STORAGE_MODELS_PREFIX = env_str("STORAGE_MODELS_PREFIX", f"{STORAGE_URI_PREFIX.rstrip('/')}/models")
STORAGE_REPORTS_PREFIX = env_str("STORAGE_REPORTS_PREFIX", f"{STORAGE_URI_PREFIX.rstrip('/')}/reports")

UI_INGESTION_CONNECTORS = env_json(
    "UI_INGESTION_CONNECTORS_JSON",
    {
        "crm-postgres": {"objects": ["public.customers", "public.orders", "public.events"]},
        "files-sftp": {"objects": ["customers.csv", "orders.csv", "events.jsonl"]},
    },
)

UI_ORG_HIERARCHY = env_json(
    "UI_ORG_HIERARCHY_JSON",
    {
        "Bronze": {
            "sales": ["orders", "customers", "events"],
            "finance": ["payments", "invoices"],
            "crm": ["contacts", "accounts"],
        },
        "Silver": {
            "sales": ["orders_clean", "customers_clean"],
            "finance": ["payments_clean"],
            "crm": ["contacts_clean"],
        },
        "Gold": {
            "sales": ["customer_agg", "revenue_mart", "features"],
            "finance": ["finance_mart"],
            "crm": ["crm_mart"],
        },
    },
)

UI_OPENMETADATA_DATASET = env_str("UI_OPENMETADATA_DATASET", "sales.orders")
UI_OPENMETADATA_COLUMNS = env_json(
    "UI_OPENMETADATA_COLUMNS_JSON",
    [
        {
            "Column": "order_id",
            "Type": "INT",
            "Explicit meaning": "Primary key",
            "Inferred meaning": "Unique order identifier",
        },
        {
            "Column": "customer_id",
            "Type": "STRING",
            "Explicit meaning": "FK to customers",
            "Inferred meaning": "Join key to customers.id",
        },
        {
            "Column": "order_ts",
            "Type": "TIMESTAMP",
            "Explicit meaning": "Order time",
            "Inferred meaning": "Event timestamp for ordering",
        },
        {
            "Column": "amount",
            "Type": "DOUBLE",
            "Explicit meaning": "Order amount",
            "Inferred meaning": "Revenue metric",
        },
    ],
)
UI_OPENMETADATA_EXPLICIT = env_json(
    "UI_OPENMETADATA_EXPLICIT_JSON",
    {
        "Display Name": "Customer Orders",
        "Description": "Confirmed business description (editable).",
        "Primary Key": "order_id",
        "Owner": "Sales Team",
    },
)
UI_OPENMETADATA_INFERRED = env_json(
    "UI_OPENMETADATA_INFERRED_JSON",
    {
        "Display Name": "Orders (inferred)",
        "Primary Key": "order_id",
        "Description": "Orders table with transactional data",
        "Join Hint": "orders.customer_id -> customers.id",
        "Confidence": "0.72",
    },
)

UI_QUERY_DEFAULT_SQL = env_str("UI_QUERY_DEFAULT_SQL", "SELECT * FROM sales.orders LIMIT 10")
UI_QUERY_DEFAULT_RESULT_NAME = env_str("UI_QUERY_DEFAULT_RESULT_NAME", "query_result_orders")
UI_QUERY_DEFAULT_SOURCE = env_str("UI_QUERY_DEFAULT_SOURCE", UI_OPENMETADATA_DATASET)

UI_KAFKA_TOPIC_DEFAULT = env_str("UI_KAFKA_TOPIC_DEFAULT", "crm.contacts")
UI_KAFKA_CREATE_TOPIC_DEFAULT = env_bool("UI_KAFKA_CREATE_TOPIC_DEFAULT", True)
UI_KAFKA_FILTERS_DEFAULT = env_str("UI_KAFKA_FILTERS_DEFAULT", "event_type = 'UPSERT'")
UI_KAFKA_DEST_DATASET_DEFAULT = env_str("UI_KAFKA_DEST_DATASET_DEFAULT", "contacts_stream")

UI_FEATURE_NAME_DEFAULT = env_str("UI_FEATURE_NAME_DEFAULT", "customer_lifetime_value")
UI_FEATURE_DESCRIPTION_DEFAULT = env_str(
    "UI_FEATURE_DESCRIPTION_DEFAULT",
    "Total revenue per customer (proxy for CLV).",
)
UI_FEATURE_SQL_DEFAULT = env_str(
    "UI_FEATURE_SQL_DEFAULT",
    "SELECT customer_id, SUM(revenue) AS clv FROM gold.sales.customer_agg GROUP BY customer_id",
)
UI_FEATURE_OWNER_DEFAULT = env_str("UI_FEATURE_OWNER_DEFAULT", "")

UI_MODEL_NAME_DEFAULT = env_str("UI_MODEL_NAME_DEFAULT", "churn_model")
UI_MODEL_TRAINING_DATASET_DEFAULT = env_str("UI_MODEL_TRAINING_DATASET_DEFAULT", "gold.sales.mart.training_churn")
UI_MODEL_LABEL_DEFAULT = env_str("UI_MODEL_LABEL_DEFAULT", "churned")

UI_HEALTH_ROWS = env_json(
    "UI_HEALTH_ROWS_JSON",
    [
        {"Tool": "Airflow", "Purpose": "Orchestrates ingestion, query, feature materialization, and model runs", "Link": "https://airflow.apache.org", "Status": "Healthy"},
        {"Tool": "Airbyte", "Purpose": "Batch ingestion connectors and sync scheduling", "Link": "https://airbyte.com", "Status": "Unhealthy"},
        {"Tool": "Kafka", "Purpose": "Streaming ingestion backbone (topics/events)", "Link": "https://kafka.apache.org", "Status": "Unhealthy"},
        {"Tool": "Trino", "Purpose": "Interactive SQL engine over lakehouse tables/files", "Link": "https://trino.io", "Status": "Healthy"},
        {"Tool": "Spark", "Purpose": "Distributed transforms + feature materialization + training prep", "Link": "https://spark.apache.org", "Status": "Healthy"},
        {"Tool": "MinIO", "Purpose": "Object store for Bronze/Silver/Gold + artifacts (Parquet/etc.)", "Link": "https://min.io", "Status": "Healthy"},
        {"Tool": "OpenMetadata", "Purpose": "Catalog + schema + lineage surfaces", "Link": "https://open-metadata.org", "Status": "Healthy"},
        {"Tool": "Grafana", "Purpose": "Dashboards for job health, SLAs, infra metrics", "Link": "https://grafana.com", "Status": "Healthy"},
    ],
)


DEMO_JOB_FIXTURES = env_json(
    "UI_DEMO_JOBS_JSON",
    [
        {
            "job_type": "Ingestion",
            "orchestrator": "Airbyte + Airflow",
            "result_location_base": "bronze/sales/orders",
            "submitted_by": "Data Engineer",
            "role": "Data Engineer",
            "team": "DataEng",
            "status": "SUCCEEDED",
            "visibility": "Global",
            "source": "postgresql://sales/orders",
            "destination": "bronze/sales/orders",
            "job_id": "JOB-DEMO-0001",
            "job_name": "Salesforce to Snowflake",
            "system_type": "airbyte",
            "system_name": "Salesforce to Snowflake",
        },
        {
            "job_type": "SQL query",
            "orchestrator": "Airflow + Trino",
            "result_location_base": "gold/sales/customer_agg",
            "submitted_by": "Data Analyst",
            "role": "Data Analyst",
            "team": "Analytics",
            "status": "RUNNING",
            "visibility": "Team",
            "source": "silver/sales/orders_clean",
            "destination": "gold/sales/customer_agg",
            "job_id": "JOB-DEMO-0002",
            "job_name": "Daily Revenue Query",
            "system_type": "sql",
            "system_name": "daily_revenue_query",
        },
        {
            "job_type": "Feature materialization",
            "orchestrator": "Airflow + Spark",
            "result_location_base": "gold/sales/features/customer_lifetime_value",
            "submitted_by": "ML Engineer",
            "role": "ML Engineer",
            "team": "ML",
            "status": "SUCCEEDED",
            "visibility": "Team",
            "source": "gold/sales/customer_agg",
            "destination": "gold/sales/features",
            "job_id": "JOB-DEMO-0003",
            "job_name": "Customer Segmentation Prompt",
            "system_type": "nl",
            "system_name": "customer_segmentation_prompt",
        },
        {
            "job_type": "Model training",
            "orchestrator": "Airflow + Python",
            "result_location_base": "models/churn_model",
            "submitted_by": "ML Engineer",
            "role": "ML Engineer",
            "team": "ML",
            "status": "FAILED",
            "visibility": "Private",
            "source": "gold/sales/features",
            "destination": "models/churn_model",
            "job_id": "JOB-DEMO-0004",
            "job_name": "Churn Model Training",
            "system_type": "airflow",
            "system_name": "churn_model_training",
        },
    ],
)


def storage_uri(*parts: str) -> str:
    root = STORAGE_URI_PREFIX.rstrip("/")
    cleaned = [str(part).strip().strip("/") for part in parts if str(part).strip().strip("/")]
    if not cleaned:
        return root
    return f"{root}/{'/'.join(cleaned)}"


def storage_base_path(level_1: str, level_2: str, level_3: str = "") -> str:
    parts = [str(level_1).lower(), str(level_2)]
    if str(level_3).strip():
        parts.append(str(level_3))
    return storage_uri(*parts)


def normalized_demo_path(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if "://" in text:
        return text
    return storage_uri(*text.split("/"))
