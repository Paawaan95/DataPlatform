import pandas as pd
import streamlit as st
from datetime import datetime

from ui import settings
from ui.components.chat import chat_form_split
from ui.components.tables import show_table
from ui.config import success_box
from ui.services.features import (
    add_feature_value_record,
    detect_sql_sources,
    latest_feature_values_rows,
    upsert_feature_sources,
)
from ui.services.jobs import add_job, ensure_dummy_jobs
from ui.services.lineage import add_lineage_edge
from ui.services.utils import storage_uri, with_run_ts
from ui.state import A_MANAGE_FEATURES, can


def render_feature_definitions_tab():
    def form_features():
        feature_name = st.text_input("Feature Definition Name", settings.UI_FEATURE_NAME_DEFAULT, key="f_name")
        entity = st.selectbox("Entity", ["customer", "account", "device"], key="f_entity")
        sql = st.text_area("Feature SQL / Logic", settings.UI_FEATURE_SQL_DEFAULT, key="f_sql")

        src_df = pd.DataFrame([
            {"Dataset": d, "Confirmed": False, "Source": "Detected", "Last Updated": ""}
            for d in detect_sql_sources(sql)
        ])
        if "f_sources_editor" not in st.session_state:
            st.session_state["f_sources_editor"] = src_df

        c_src1, c_src2 = st.columns([1, 1])
        with c_src1:
            if st.button("Auto-detect input sources from SQL", key="f_detect_sql"):
                st.session_state["f_sources_editor"] = src_df
        with c_src2:
            st.caption("You can edit the detected list. Confirmed = reviewed by owner.")

        editor_df = st.data_editor(
            st.session_state.get("f_sources_editor", src_df),
            num_rows="dynamic",
            use_container_width=True,
            hide_index=True,
            key="f_sources_editor",
        )
        description = st.text_input("Description", settings.UI_FEATURE_DESCRIPTION_DEFAULT, key="f_desc")
        window = st.selectbox("Window", ["7d", "30d", "90d", "180d", "All-time"], index=2, key="f_window")
        cadence = st.selectbox("Refresh Cadence", ["On-demand", "Hourly", "Daily", "Weekly"], index=2, key="f_cadence")
        owner_default = settings.UI_FEATURE_OWNER_DEFAULT or st.session_state.get("user", "")
        owner = st.text_input("Owner", owner_default, key="f_owner")

        if st.button("Save / Update feature definition", type="primary", key="f_save", disabled=not can(A_MANAGE_FEATURES)):
            now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            df = st.session_state.features_table
            src_list = [str(x) for x in editor_df.get("Dataset", []) if str(x).strip()]
            src_display = ", ".join(src_list) if src_list else ""
            if not df.empty and (df["Feature Name"] == feature_name).any():
                idx = df.index[df["Feature Name"] == feature_name][0]
                df.loc[idx, ["Entity", "Source Table", "Definition SQL", "Description", "Window", "Refresh Cadence", "Owner", "Created At"]] = [entity, src_display, sql, description, window, cadence, owner, now]
                st.session_state.features_table = df
            else:
                row = {
                    "Feature Name": feature_name,
                    "Entity": entity,
                    "Source Table": src_display,
                    "Definition SQL": sql,
                    "Description": description,
                    "Window": window,
                    "Refresh Cadence": cadence,
                    "Owner": owner,
                    "Version": "v1",
                    "Stage": "Draft",
                    "Created At": now,
                }
                st.session_state.features_table = pd.concat([df, pd.DataFrame([row])], ignore_index=True)
            upsert_feature_sources(feature_name, editor_df)
            for ds in src_list:
                add_lineage_edge("Dataset", ds, "Feature", feature_name, "defines")
            st.success("Saved (mock).")

        st.markdown("#### Materialize Feature Values (Offline)")
        output_base = f"{storage_uri('gold', 'features', entity, feature_name)}/"
        st.dataframe(pd.DataFrame([{
            "What happens": "A job computes feature values per entity and writes to object storage (offline store).",
            "Output (base path)": output_base,
            "Suggested unique path": with_run_ts(output_base),
        }]), use_container_width=True, hide_index=True)

        if st.button("Submit materialization job (mock)", type="secondary", key="f_submit_job", disabled=not can(A_MANAGE_FEATURES)):
            job_id, link, result_loc = add_job(
                "Feature materialization",
                "Airflow + Spark",
                output_base,
                status="QUEUED",
                visibility="Team",
                source=f"Feature:{feature_name}",
                destination=output_base,
            )
            add_feature_value_record(feature_name=feature_name, entity=entity, job_id=job_id, offline_location=str(result_loc))
            success_box(f"✅ Submitted (mock). &nbsp; <a href=\"{link}\">Open Job Details</a>")

        st.divider()
        show_table(st.session_state.features_table.drop(columns=["Source Table"], errors="ignore"), "Saved features")
        st.divider()
        st.markdown("#### Feature Values Registry (Feast – Offline)")
        reg = latest_feature_values_rows(feature_name)
        if reg is None or reg.empty:
            st.info("No materialized feature values yet. Submit a materialization job to create a registry entry.")
        else:
            show_table(reg[["Feature Name", "Entity", "Store", "Materialization Job Id", "Offline Location", "Status", "Valid From", "Last Updated"]], "Latest materializations for this feature")

        st.markdown("##### All Feature Values (latest first)")
        show_table(latest_feature_values_rows(), "Feature values registry")

    ensure_dummy_jobs()
    chat_form_split("Feature Definitions", "Example: Define feature logic (X variable) and materialize values for reuse.", form_features, context_key="ml_features")
