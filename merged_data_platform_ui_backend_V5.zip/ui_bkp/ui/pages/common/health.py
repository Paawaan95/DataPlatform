import pandas as pd
import streamlit as st

from ui import settings
from ui.components.tables import html_table


def page_health(embed: bool = False):
    if not embed:
        st.title("Platform Health")

    df = pd.DataFrame(settings.UI_HEALTH_ROWS)
    if df.empty:
        st.info("No platform health rows configured.")
        return

    df["Tool"] = df.apply(lambda r: f"[{r['Tool']}]({r['Link']})" if str(r.get('Link', '')).strip() else str(r['Tool']), axis=1)

    def _status_html(s):
        color = "limegreen" if s == "Healthy" else "crimson"
        return f"<span style='color:{color}; font-weight:700;'>●</span> {s}"

    df["Status"] = df["Status"].apply(_status_html)
    html_table(df[["Tool", "Purpose", "Status"]])
