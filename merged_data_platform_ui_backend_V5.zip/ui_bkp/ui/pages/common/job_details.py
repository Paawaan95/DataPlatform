from __future__ import annotations

import urllib.parse

import pandas as pd
import streamlit as st

from ui import settings

from ui.components.serving import serving_tabs
from ui.components.tables import show_table, jobs_table_with_open, html_table
from ui.runtime import request_rerun
from ui.state import can, A_PUBLISH_ASSET
from ui.services.dq import add_dq_run
from ui.services.jobs import ensure_dummy_jobs, visible_jobs_for_user, publish_output_from_job
from ui.services.job_detail_view import (
    LINEAGE_COLUMNS,
    LINEAGE_CONFIDENCE_LABELS,
    build_display_label,
    build_job_name,
    get_value,
    job_detail_dataframe,
    lineage_for_job,
    lineage_graph_dot,
    lineage_metrics,
    lineage_view_link,
    render_metric_cards,
    resolve_action_links,
    resolve_job_record,
)
from ui.services.ledger_api import (
    fetch_job_download_url,
    fetch_job_sample_preview,
    fetch_job_serving,
    ledger_api_enabled,
)
from ui.services.utils import dataset_id_from_s3_path


FIELD_LINEAGE_COLUMNS = [
    "Edge Id",
    "Source Dataset",
    "Source Column",
    "Target Dataset",
    "Target Column",
    "Transform",
    "Created At",
]



def _field_lineage_for_job(job: dict | pd.Series) -> pd.DataFrame:
    destination = get_value(job, "Destination", "destination")
    dataset_id = dataset_id_from_s3_path(destination)
    field_df = st.session_state.field_lineage_table
    if field_df is None or field_df.empty or not dataset_id:
        return pd.DataFrame(columns=FIELD_LINEAGE_COLUMNS)

    view = field_df[field_df["Target Dataset"].astype(str) == dataset_id].copy()
    if view.empty:
        suffix = dataset_id.split(".")[-1]
        view = field_df[
            field_df["Target Dataset"].astype(str).str.contains(suffix, case=False, na=False)
        ].copy()
    if view.empty:
        return pd.DataFrame(columns=FIELD_LINEAGE_COLUMNS)
    return view[FIELD_LINEAGE_COLUMNS].reset_index(drop=True)



def _render_action_links(job: dict | pd.Series):
    st.markdown("### Action")
    rows = resolve_action_links(job)
    if rows:
        html_table(pd.DataFrame(rows))
    else:
        st.info("No external Airflow or Airbyte link available yet")



def _render_lineage(job: dict | pd.Series, lineage_df: pd.DataFrame, lineage_mode: str, field_lineage_df: pd.DataFrame):
    st.markdown("### Lineage")

    metric_values = lineage_metrics(lineage_df)
    metric_values["field_edges"] = 0 if field_lineage_df.empty else int(len(field_lineage_df))
    render_metric_cards(
        [
            ("Upstream nodes", str(metric_values["upstream"])),
            ("Downstream nodes", str(metric_values["downstream"])),
            ("Edges", str(metric_values["edges"])),
            ("Confidence", LINEAGE_CONFIDENCE_LABELS.get(lineage_mode, "Unavailable")),
        ]
    )

    action_cols = st.columns([1.4, 1, 1])
    with action_cols[0]:
        st.caption(
            "Lineage uses backend lineage when available, otherwise falls back to inferred edges from source, destination, result location, and field-level mappings."
        )
    with action_cols[1]:
        graph_link = lineage_view_link(get_value(job, "Job Id", "job_id"))
        st.markdown(
            f'<a href="{graph_link}" target="_blank" style="display:inline-block;padding:0.55rem 0.85rem;border-radius:10px;border:1px solid #2563eb;text-decoration:none;">Open Lineage View ↗</a>',
            unsafe_allow_html=True,
        )
    with action_cols[2]:
        if not lineage_df.empty:
            csv_data = lineage_df.to_csv(index=False).encode("utf-8")
            st.download_button(
                "Download lineage CSV",
                data=csv_data,
                file_name=f"{get_value(job, 'Job Id', 'job_id')}_lineage.csv",
                mime="text/csv",
                use_container_width=True,
            )

    if lineage_df.empty:
        st.info("No lineage available yet")
    else:
        st.graphviz_chart(lineage_graph_dot(job, lineage_df), use_container_width=True)

    st.markdown("#### Lineage Details")
    if lineage_df.empty:
        st.info("No lineage edges available yet")
    else:
        show_table(lineage_df, height=260)

    st.markdown("#### Field Lineage Details")
    if field_lineage_df.empty:
        st.info("No field lineage available yet")
    else:
        show_table(field_lineage_df, height=260)



def _render_lineage_only(job: dict | pd.Series, lineage_df: pd.DataFrame, lineage_mode: str, field_lineage_df: pd.DataFrame):
    st.title("Lineage View")
    st.caption(build_display_label(job))
    back_link = urllib.parse.quote_plus(get_value(job, "Job Id", "job_id"))
    st.markdown(
        f'<a href="?page=Job%20Details&job_id={back_link}" target="_self">Back to Job Details</a>',
        unsafe_allow_html=True,
    )
    _render_lineage(job, lineage_df, lineage_mode, field_lineage_df)



def _resolve_selected_job() -> tuple[pd.DataFrame, dict | None]:
    jobs = visible_jobs_for_user()
    job_id = st.session_state.selected_job_id
    if not job_id or jobs is None or jobs.empty:
        return jobs, None

    tenant_id = st.session_state.get("selected_tenant") or settings.LEDGER_DEFAULT_TENANT
    return jobs, resolve_job_record(job_id, jobs, tenant_id)



def page_job_details():
    ensure_dummy_jobs()
    jobs, job = _resolve_selected_job()

    if job is None:
        st.title("Job Details")
        jobs_table_with_open(
            jobs,
            "Jobs Summary",
            "jd_jobs_search",
            show_search=False,
            paginate=True,
            pager_key="job_details_jobs",
        )
        st.info("Use the Open link above to open a job.")
        return

    job_id = get_value(job, "Job Id", "job_id")
    tenant_id = st.session_state.get("selected_tenant") or settings.LEDGER_DEFAULT_TENANT
    lineage_df, lineage_mode = lineage_for_job(tenant_id, job_id, job)
    field_lineage_df = _field_lineage_for_job(job)

    if get_value(st.query_params, "lineage_view") == "graph":
        _render_lineage_only(job, lineage_df, lineage_mode, field_lineage_df)
        return

    st.title("Job Details")
    detail_df = job_detail_dataframe(job)
    st.dataframe(detail_df, use_container_width=True, hide_index=True)

    _render_action_links(job)
    _render_lineage(job, lineage_df, lineage_mode, field_lineage_df)

    result_location = get_value(job, "Result Location", "result_location")
    serving_payload = fetch_job_serving(tenant_id, job_id) if ledger_api_enabled() else None
    preview_payload = fetch_job_sample_preview(tenant_id, job_id, limit=20) if ledger_api_enabled() else None
    download_payload = fetch_job_download_url(tenant_id, job_id) if ledger_api_enabled() else None
    serving_tabs(job_id, result_location, serving_payload, preview_payload, download_payload)

    st.divider()
    st.markdown("### Data Quality checks")
    suites = ["basic_suite", "null_checks", "pk_uniqueness"]
    suite = st.selectbox("Expectation Suite", suites, key="dq_suite")
    if st.button("Run DQ checks (mock)", key="dq_run_btn"):
        status = "FAILED" if suite == "null_checks" else "PASSED"
        failed = "amount_null_rate>0.01" if status == "FAILED" else ""
        add_dq_run("Job", job_id, suite, status, failed)
        st.success("DQ run recorded (mock).")
        request_rerun()

    dq = st.session_state.dq_runs_table
    if not dq.empty:
        recent = dq[dq["Related Id"] == job_id].sort_values("Created At", ascending=False).head(5)
        if not recent.empty:
            rows = []
            for _, r in recent.iterrows():
                rows.append({
                    "DQ Run Id": r["DQ Run Id"],
                    "Suite": r["Expectation Suite"],
                    "Status": r["Status"],
                    "Failed Checks": r["Failed Checks"],
                    "Open": f"[Open]({r['Open DQ Link']})",
                })
            html_table(pd.DataFrame(rows))

    st.divider()
    st.markdown("### Publish output")
    c1, c2, c3 = st.columns(3)
    with c1:
        asset_type = st.selectbox("Type", ["Dataset", "Feature output", "Model artifact", "Report"], key="pub_type")
    with c2:
        asset_name_default = build_job_name(job) or "Output"
        asset_name = st.text_input("Name", asset_name_default, key="pub_name")
    with c3:
        visibility = st.selectbox("Visibility", ["Private", "Team", "Global"], key="pub_vis")

    if st.button("Publish", type="primary", key="pub_btn", disabled=not can(A_PUBLISH_ASSET)):
        publish_output_from_job(job_id, asset_type, asset_name, visibility)
        st.success("Published (mock).")
