import pandas as pd
import streamlit as st

from ui import settings
from ui.config import success_box
from ui.services.jobs import add_job, ensure_dummy_jobs
from ui.services.lineage import add_lineage_edge
from ui.services.utils import storage_base_path, with_run_ts
from ui.state import enforce


def page_kafka_ingestion():
    st.title("Kafka Streaming Ingestion")
    ensure_dummy_jobs()
    enforce("submit_ingestion")

    hierarchy = st.session_state.org_hierarchy

    topic = st.text_input("Kafka topic", value=settings.UI_KAFKA_TOPIC_DEFAULT, key="kafka_topic")
    create_topic = st.checkbox("Create topic (mock)", value=settings.UI_KAFKA_CREATE_TOPIC_DEFAULT, key="kafka_create_topic")
    filters = st.text_input("Optional filters", value=settings.UI_KAFKA_FILTERS_DEFAULT, key="kafka_filters")

    l1 = st.selectbox("Level 1", list(hierarchy.keys()), key="kafka_l1")
    l2 = st.selectbox("Level 2", list(hierarchy.get(l1, {}).keys()), key="kafka_l2")
    level3s = hierarchy.get(l1, {}).get(l2, [])
    l3 = st.selectbox("Level 3", level3s if level3s else [""], key="kafka_l3")
    dest_dataset = st.text_input("Destination dataset name", value=settings.UI_KAFKA_DEST_DATASET_DEFAULT, key="kafka_dest_dataset")

    base_prefix = storage_base_path(l1, l2, l3)
    dest_base = f"{base_prefix.rstrip('/')}/{dest_dataset}/"

    st.dataframe(pd.DataFrame([{
        "Topic": topic,
        "Create topic": "Yes" if create_topic else "No",
        "Filters": filters,
        "Output (base)": dest_base,
        "Suggested unique path": with_run_ts(dest_base)
    }]), use_container_width=True, hide_index=True)

    if st.button("Start streaming job (mock)", type="primary", key="kafka_submit"):
        job_id, link, _ = add_job(
            "Kafka Stream",
            "Kafka Connect / Flink (mock)",
            dest_base,
            status="RUNNING",
            visibility="Team",
            source=f"KafkaTopic:{topic}",
            destination=dest_base,
        )
        add_lineage_edge("Kafka Topic", topic, "Job", job_id, "feeds")
        add_lineage_edge("Job", job_id, "Dataset", dest_base, "writes_to")
        success_box(f"✅ Streaming job started (mock). &nbsp; <a href=\"{link}\">Open Job Details</a>")
