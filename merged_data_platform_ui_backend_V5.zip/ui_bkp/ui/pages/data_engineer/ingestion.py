import pandas as pd
import streamlit as st

from ui import settings
from ui.components.chat import chat_form_split
from ui.config import success_box
from ui.services.jobs import add_job
from ui.services.lineage import add_field_lineage
from ui.services.utils import storage_base_path, with_run_ts
from ui.state import A_SET_VISIBILITY, A_SUBMIT_INGESTION, can


def page_ingestion():
    hierarchy = st.session_state.org_hierarchy
    mock_sources = settings.UI_INGESTION_CONNECTORS

    def form():
        source = st.selectbox("Source Connector", list(mock_sources.keys()), key="ing_source")
        source_object = st.selectbox("Source table / file", mock_sources[source]["objects"], key="ing_source_obj")

        l1 = st.selectbox("Level 1", list(hierarchy.keys()), key="ing_l1")
        l2 = st.selectbox("Level 2", list(hierarchy.get(l1, {}).keys()), key="ing_l2")
        level3s = hierarchy.get(l1, {}).get(l2, [])
        l3 = st.selectbox("Level 3", level3s if level3s else [""], key="ing_l3")

        default_dataset = source_object.split(".")[-1].replace(".csv", "").replace(".jsonl", "")
        dest_dataset = st.text_input("Destination dataset name", value=default_dataset, key="ing_dest_dataset")

        base_prefix = storage_base_path(l1, l2, l3)
        dest_base = f"{base_prefix.rstrip('/')}/{dest_dataset}/"

        st.dataframe(pd.DataFrame([{
            "Destination Path (base)": dest_base,
            "Suggested unique path": with_run_ts(dest_base)
        }]), use_container_width=True, hide_index=True)

        job_vis = st.selectbox("Job visibility", ["Private", "Team", "Global"], disabled=not can(A_SET_VISIBILITY), key="ing_job_vis")

        if st.button("Submit ingestion job (mock)", type="primary", key="ing_submit", disabled=not can(A_SUBMIT_INGESTION)):
            _, link, _ = add_job(
                "Ingestion",
                "Airbyte + Airflow",
                dest_base,
                status="QUEUED",
                visibility=job_vis,
                source=source_object,
                destination=dest_base,
            )
            success_box(f"✅ Submitted (mock). &nbsp; <a href=\"{link}\">Open Job Details</a>")
            try:
                dest_ds_id = f"{l1.lower()}.{l2}.{dest_dataset}"
                cols = st.session_state.openmetadata.get("columns")
                if isinstance(cols, pd.DataFrame) and not cols.empty and "Column" in cols.columns:
                    for c in cols["Column"].tolist():
                        add_field_lineage(str(source_object), str(c), dest_ds_id, str(c), "copy")
            except Exception:
                pass

    chat_form_split("Data Ingestion", "Example: Ingest orders into Bronze → sales → orders.", form, context_key="ingestion")
