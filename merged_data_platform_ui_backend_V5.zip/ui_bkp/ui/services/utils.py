from __future__ import annotations

from datetime import datetime

from ui import settings


def run_ts():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def with_run_ts(base_path: str):
    base = str(base_path).rstrip("/") + "/"
    return f"{base}run_ts={run_ts()}/"


def storage_uri(*parts: str) -> str:
    return settings.storage_uri(*parts)


def storage_base_path(level_1: str, level_2: str, level_3: str = "") -> str:
    return settings.storage_base_path(level_1, level_2, level_3)


def storage_dataset_path(level_1: str, level_2: str, dataset_name: str, level_3: str = "") -> str:
    base = storage_base_path(level_1, level_2, level_3)
    return f"{base.rstrip('/')}/{str(dataset_name).strip().strip('/')}"


def normalize_demo_path(value: str) -> str:
    return settings.normalized_demo_path(value)


def dataset_id_from_s3_path(s3_path: str) -> str:
    try:
        prefix = settings.STORAGE_URI_PREFIX.rstrip("/") + "/"
        p = str(s3_path).replace(prefix, "")
        parts = [x for x in p.split("/") if x]
        if len(parts) >= 3:
            zone = parts[0]
            domain = parts[1]
            dataset = parts[2]
            return f"{zone}.{domain}.{dataset}"
    except Exception:
        pass
    return ""
