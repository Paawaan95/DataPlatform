from __future__ import annotations

import uuid
from datetime import datetime
from typing import Any

import pandas as pd
import streamlit as st


LINEAGE_COLUMNS = [
    "Edge Id",
    "From Type",
    "From Id",
    "To Type",
    "To Id",
    "Relation",
    "Created At",
]


def add_lineage_edge(from_type: str, from_id: str, to_type: str, to_id: str, relation: str):
    edge_id = f"LIN-{str(uuid.uuid4())[:8]}"
    created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row = {
        "Edge Id": edge_id,
        "From Type": from_type,
        "From Id": from_id,
        "To Type": to_type,
        "To Id": to_id,
        "Relation": relation,
        "Created At": created,
    }
    st.session_state.lineage_table = pd.concat([st.session_state.lineage_table, pd.DataFrame([row])], ignore_index=True)



def add_field_lineage(src_dataset: str, src_col: str, tgt_dataset: str, tgt_col: str, transform: str):
    edge_id = f"FLN-{str(uuid.uuid4())[:8]}"
    created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row = {
        "Edge Id": edge_id,
        "Source Dataset": src_dataset,
        "Source Column": src_col,
        "Target Dataset": tgt_dataset,
        "Target Column": tgt_col,
        "Transform": transform,
        "Created At": created,
    }
    st.session_state.field_lineage_table = pd.concat([
        st.session_state.field_lineage_table, pd.DataFrame([row])
    ], ignore_index=True)
    return edge_id



def add_field_lineage_edge(src_dataset: str, src_col: str, tgt_dataset: str, tgt_col: str, transform: str,
                           created: str | None = None):
    if created is None:
        return add_field_lineage(src_dataset, src_col, tgt_dataset, tgt_col, transform)
    edge_id = f"FLN-{str(uuid.uuid4())[:8]}"
    row = {
        "Edge Id": edge_id,
        "Source Dataset": src_dataset,
        "Source Column": src_col,
        "Target Dataset": tgt_dataset,
        "Target Column": tgt_col,
        "Transform": transform,
        "Created At": created,
    }
    st.session_state.field_lineage_table = pd.concat([
        st.session_state.field_lineage_table, pd.DataFrame([row])
    ], ignore_index=True)
    return edge_id



def lineage_for_node(node_id: str) -> pd.DataFrame:
    df = st.session_state.lineage_table
    if df.empty:
        return df
    mask = (df["From Id"] == node_id) | (df["To Id"] == node_id)
    return df[mask].copy()



def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()



def _job_value(job: Any, *keys: str) -> str:
    if hasattr(job, "get"):
        for key in keys:
            value = _clean_text(job.get(key, ""))
            if value:
                return value
    else:
        for key in keys:
            try:
                value = _clean_text(job[key])
            except Exception:
                value = ""
            if value:
                return value
    return ""



def fallback_lineage_for_job(job: Any) -> pd.DataFrame:
    job_id = _job_value(job, "Job Id", "job_id")
    if not job_id:
        return pd.DataFrame(columns=LINEAGE_COLUMNS)

    job_name = _job_value(job, "Job Name", "job_name", "System Name", "system_name", "Job Type", "job_type") or job_id
    source = _job_value(job, "Source", "source")
    destination = _job_value(job, "Destination", "destination")
    result_location = _job_value(job, "Result Location", "result_location")
    created_at = _job_value(job, "Created At", "created_at") or datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    rows: list[dict[str, str]] = []
    if source:
        rows.append(
            {
                "Edge Id": f"LIN-FB-{job_id}-SRC",
                "From Type": "Source",
                "From Id": source,
                "To Type": "Job",
                "To Id": f"{job_name} ({job_id})",
                "Relation": "feeds",
                "Created At": created_at,
            }
        )
    if destination:
        rows.append(
            {
                "Edge Id": f"LIN-FB-{job_id}-DST",
                "From Type": "Job",
                "From Id": f"{job_name} ({job_id})",
                "To Type": "Destination",
                "To Id": destination,
                "Relation": "writes_to",
                "Created At": created_at,
            }
        )
    if result_location:
        rows.append(
            {
                "Edge Id": f"LIN-FB-{job_id}-RES",
                "From Type": "Job",
                "From Id": f"{job_name} ({job_id})",
                "To Type": "Result Location",
                "To Id": result_location,
                "Relation": "stores_at",
                "Created At": created_at,
            }
        )

    return pd.DataFrame(rows, columns=LINEAGE_COLUMNS)
