import streamlit as st

from ui import settings

SMALL_FONT_CSS = """
<style>
html, body, [class*="css"]  { font-size: 12px; }
textarea { font-size: 12px !important; }
input { font-size: 12px !important; }
</style>
"""

SUCCESS_BOX_CSS = """
<style>
.successbox {
  padding: 0.75rem 1rem;
  border-radius: 0.5rem;
  background: rgba(0, 255, 0, 0.12);
  border: 1px solid rgba(0, 255, 0, 0.35);
}
.successbox a { text-decoration: underline; }
</style>
"""


def setup_page():
    page_title = settings.STREAMLIT_PAGE_TITLE
    if settings.UI_SHOW_MOCK_BADGE:
        page_title = f"{page_title} (Mock)"
    st.set_page_config(layout="wide", page_title=page_title)
    st.markdown(SMALL_FONT_CSS, unsafe_allow_html=True)
    st.markdown(SUCCESS_BOX_CSS, unsafe_allow_html=True)


def success_box(markdown_text: str):
    st.markdown(f"<div class='successbox'>{markdown_text}</div>", unsafe_allow_html=True)
