import streamlit as st

from ui.components.serving_tabs.api import render_api_tab
from ui.components.serving_tabs.sftp import render_sftp_tab
from ui.components.serving_tabs.download import render_download_tab
from ui.components.serving_tabs.sample_preview import render_sample_preview_tab



def _summary_card(label: str, value: str):
    with st.container(border=True):
        st.caption(label.upper())
        st.markdown(f"**{value}**")



def _render_serving_summary(job_or_asset_id: str, payload: dict, preview: dict | None, download: dict | None):
    result_location = str(payload.get("result_location") or "").strip()
    api_payload = payload.get("api") or {}
    sftp_payload = payload.get("sftp") or {}
    preview_rows = (preview or {}).get("rows") or []
    download_url = (download or {}).get("download_url") or ""

    result_status = "Available" if result_location else "Not available yet"
    serving_modes = []
    if api_payload.get("available"):
        serving_modes.append("API")
    if sftp_payload.get("available"):
        serving_modes.append("SFTP")
    if download_url:
        serving_modes.append("Download")
    if preview_rows:
        serving_modes.append("Preview")
    modes_text = ", ".join(serving_modes) if serving_modes else "Pending publication"

    cards = [
        ("Job / Asset Id", job_or_asset_id),
        ("Result status", result_status),
        ("Serving modes", modes_text),
        ("Result location", result_location or "Not available yet"),
    ]
    cols = st.columns(len(cards))
    for col, (label, value) in zip(cols, cards):
        with col:
            _summary_card(label, value)


def serving_tabs(job_or_asset_id: str, *args):
    """
    Backward compatible signatures:
      serving_tabs(job_id)
      serving_tabs(job_id, serving_payload, preview_payload, download_payload)
      serving_tabs(job_id, result_location, serving_payload, preview_payload, download_payload)
    """
    explicit_result_location = ""
    payload = {}
    preview = None
    download = None

    if len(args) == 0:
        pass
    elif len(args) == 1:
        if isinstance(args[0], dict):
            payload = args[0]
        else:
            explicit_result_location = str(args[0] or "").strip()
    elif len(args) == 3 and isinstance(args[0], dict):
        payload = args[0] or {}
        preview = args[1] if isinstance(args[1], dict) else None
        download = args[2] if isinstance(args[2], dict) else None
    else:
        explicit_result_location = str(args[0] or "").strip()
        payload = args[1] if len(args) > 1 and isinstance(args[1], dict) else {}
        preview = args[2] if len(args) > 2 and isinstance(args[2], dict) else None
        download = args[3] if len(args) > 3 and isinstance(args[3], dict) else None

    payload = payload if isinstance(payload, dict) else {}
    payload_result_location = str(payload.get("result_location") or "").strip()
    effective_result_location = explicit_result_location or payload_result_location

    merged_payload = dict(payload)
    if effective_result_location and not merged_payload.get("result_location"):
        merged_payload["result_location"] = effective_result_location

    st.markdown("### Consume results (Serving options)")
    _render_serving_summary(job_or_asset_id, merged_payload, preview, download)
    tabs = st.tabs(["API", "SFTP", "Download", "Sample preview"])

    with tabs[0]:
        render_api_tab(merged_payload)

    with tabs[1]:
        render_sftp_tab(merged_payload)

    with tabs[2]:
        render_download_tab(merged_payload, download)

    with tabs[3]:
        render_sample_preview_tab(preview)
