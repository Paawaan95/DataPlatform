import pandas as pd
import streamlit as st



def render_sample_preview_tab(preview_payload: dict | None):
    st.markdown("#### Sample preview")
    payload = preview_payload or {}
    rows = payload.get("rows") or []
    format_name = payload.get("format") or ""
    message = payload.get("message") or "Preview not available yet"

    if not rows:
        st.info(message)
        return

    caption_parts = []
    if format_name:
        caption_parts.append(f"Format: {format_name}")
    if payload.get("object_key"):
        caption_parts.append(f"Object: {payload.get('object_key')}")
    if caption_parts:
        st.caption(" | ".join(caption_parts))

    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    if payload.get("next_cursor"):
        st.caption("More preview rows are available through cursor-based pagination in the backend API.")
