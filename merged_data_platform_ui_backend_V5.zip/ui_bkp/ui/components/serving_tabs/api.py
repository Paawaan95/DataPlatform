import pandas as pd
import streamlit as st



def render_api_tab(serving_payload: dict | None):
    st.markdown("#### API")
    api_payload = (serving_payload or {}).get("api") or {}
    result_location = (serving_payload or {}).get("result_location") or ""
    route = api_payload.get("route", "")
    method = api_payload.get("method", "GET")
    backed_by = api_payload.get("backed_by", result_location)
    available = bool(api_payload.get("available"))

    if not available:
        st.info("API endpoint not available yet")
    rows = [{
        "Endpoint": route,
        "Method": method,
        "Backed by": backed_by,
        "Status": "Ready" if available else "Not available yet",
    }]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
