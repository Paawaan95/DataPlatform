import pandas as pd
import streamlit as st



def render_download_tab(serving_payload: dict | None, download_payload: dict | None):
    st.markdown("#### Download")
    result_location = (serving_payload or {}).get("result_location") or ""
    download_info = download_payload or {}
    download_url = download_info.get("download_url") or ""
    storage_location = download_info.get("storage_location") or result_location

    rows = [{
        "Location": storage_location,
        "Object": download_info.get("object_key") or "",
        "Method": download_info.get("method", "backend-generated URL" if download_url else "Not available yet"),
        "Expires At": download_info.get("expires_at") or "",
        "Status": "Ready" if download_url else "Not available yet",
    }]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    if download_url:
        st.markdown(f"[Download result]({download_url})")
    else:
        st.info(download_info.get("message") or "Download not available yet")
