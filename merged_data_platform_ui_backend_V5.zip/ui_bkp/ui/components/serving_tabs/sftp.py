import pandas as pd
import streamlit as st



def render_sftp_tab(serving_payload: dict | None):
    st.markdown("#### SFTP")
    sftp_payload = (serving_payload or {}).get("sftp") or {}
    result_location = (serving_payload or {}).get("result_location") or ""
    available = bool(sftp_payload.get("available"))
    if not available:
        st.info("SFTP path not available yet")
    st.dataframe(
        pd.DataFrame([
            {
                "SFTP path": sftp_payload.get("path", ""),
                "Backed by": sftp_payload.get("backed_by", result_location),
                "Status": "Ready" if available else "Not available yet",
            }
        ]),
        use_container_width=True,
        hide_index=True,
    )
