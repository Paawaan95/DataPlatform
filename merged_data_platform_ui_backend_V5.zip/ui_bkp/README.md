# Streamlit UI – environment-ready build

This build centralizes deployable configuration into `.env` so you can change client-specific values without editing Python files.

## What changed

- Added `python-dotenv` loading in `app.py`
- Added `ui/settings.py` as the single env-backed configuration layer
- Replaced hardcoded UI endpoints and default tenant usage with `.env` values
- Replaced hardcoded storage prefixes like `s3://minio/...` with env-driven builders
- Moved demo/mock defaults for ingestion, Kafka, query, features, models, and OpenMetadata seed data behind `.env`
- Kept the existing page structure intact

## Run (PowerShell)

```powershell
cd .
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
Copy-Item .env.example .env
# Edit .env for your environment
streamlit run app.py
```

## Minimum values to set in `.env`

- `LEDGER_API_BASE_URL`
- `LEDGER_DEFAULT_TENANT`
- `AIRFLOW_UI_BASE_URL`
- `AIRBYTE_UI_BASE_URL`
- `OPENMETADATA_UI_BASE_URL`
- `STORAGE_URI_PREFIX`

## Notes

- The uploaded codebase is UI-only. Slow worker / fast worker code is not present in this package, so those services were not modified here.
- The UI still supports demo/mock defaults, but they now come from `.env` instead of being scattered across files.
