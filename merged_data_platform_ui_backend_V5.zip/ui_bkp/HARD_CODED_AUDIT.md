# Hard-coded configuration audit (UI package)

This package now centralizes deployable settings into `.env`.

## Hard-coded items removed from page/service logic

### Endpoints / tenant routing
- `LEDGER_API_BASE_URL`
- `LEDGER_DEFAULT_TENANT`
- Airflow UI fallback URL
- Airbyte UI fallback URL
- OpenMetadata UI base URL

### Storage paths / object-store prefixes
- `s3://minio/...` paths across:
  - ingestion page
  - Kafka ingestion page
  - query page
  - feature materialization
  - model output
  - dummy assets/jobs
  - feature-value registry

### Demo / seed values now centralized
- ingestion connector list
- org hierarchy seed
- OpenMetadata seed dataset / columns / metadata
- Kafka default topic, filters, destination dataset
- query default SQL and result dataset
- feature default name / SQL / description / owner
- model default name / training dataset / label
- platform health cards
- demo job fixtures

## Files changed
- `app.py`
- `requirements.txt`
- `README.md`
- `.env.example`
- `ui/settings.py` (new)
- `ui/config.py`
- `ui/state.py`
- `ui/services/utils.py`
- `ui/services/ledger_api.py`
- `ui/services/job_detail_view.py`
- `ui/services/jobs.py`
- `ui/services/features.py`
- `ui/pages/data_engineer/ingestion.py`
- `ui/pages/data_engineer/kafka_ingestion.py`
- `ui/pages/data_analyst/query_studio.py`
- `ui/pages/ml_engineer/tabs/feature_definitions.py`
- `ui/pages/ml_engineer/tabs/models.py`
- `ui/pages/common/health.py`
- `ui/pages/common/job_details.py`
- `ui/pages/common/lineage.py`

## Not modified in this package
- slow worker code
- fast worker code
- backend API code
- Docker compose / deployment manifests

Those files were not present in the uploaded UI zip.
