# Job Details restored fix

## Intent
Restore the original UX contract:
- no separate Jobs Summary page
- Job Details page shows the jobs list when no job is selected
- Job Id is clickable and opens Job Details in a new browser tab
- Job Details keeps Action, Lineage, Lineage Details, Field Lineage Details, and Consume Results on the same page
- Lineage page supports a focused job-specific visual view when opened from Job Details

## Files changed
- ui/components/tables.py
- ui/services/lineage.py
- ui/pages/common/job_details.py
- ui/pages/common/lineage.py
