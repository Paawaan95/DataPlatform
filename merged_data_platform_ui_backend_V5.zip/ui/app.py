from pathlib import Path

from dotenv import load_dotenv

APP_DIR = Path(__file__).resolve().parent
REPO_ROOT = APP_DIR.parent
ROOT_ENV = REPO_ROOT / ".env"
LOCAL_ENV = APP_DIR / ".env"

if ROOT_ENV.exists():
    load_dotenv(ROOT_ENV)
elif LOCAL_ENV.exists():
    load_dotenv(LOCAL_ENV)
else:
    load_dotenv()

import streamlit as st

from ui.config import setup_page
from ui.state import init_state
from ui.auth import qp_autologin
from ui.router import router

setup_page()
init_state()
qp_autologin()
router()
