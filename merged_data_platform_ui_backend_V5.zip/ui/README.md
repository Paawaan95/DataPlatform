# Streamlit UI – role-wise pages split (structure-only)

✅ `app.py` is still the main entry (Streamlit run app.py)  
✅ Login stays first → then role-wise sidebar pages exactly like before  
✅ Common pages are shared, role pages are in separate folders  
✅ Tabs inside pages are also separated into files (feature tabs + serving tabs)

## Run (PowerShell)

```powershell
cd .
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
streamlit run app.py
```
