import pandas as pd
import streamlit as st

from ui.components.tables import html_table


def page_health(embed: bool = False):
    if not embed:
        st.title("Platform Health")

    rows = [
        {"Tool": "Airflow", "Purpose": "Orchestrates ingestion, query, feature materialization, and model runs",
         "Link": "https://airflow.apache.org", "Status": "Healthy"},
        {"Tool": "Airbyte", "Purpose": "Batch ingestion connectors and sync scheduling", "Link": "https://airbyte.com",
         "Status": "Unhealthy"},
        {"Tool": "Kafka", "Purpose": "Streaming ingestion backbone (topics/events)", "Link": "https://kafka.apache.org",
         "Status": "Unhealthy"},
        {"Tool": "Trino", "Purpose": "Interactive SQL engine over lakehouse tables/files", "Link": "https://trino.io",
         "Status": "Healthy"},
        {"Tool": "Spark", "Purpose": "Distributed transforms + feature materialization + training prep",
         "Link": "https://spark.apache.org", "Status": "Healthy"},
        {"Tool": "MinIO", "Purpose": "Object store for Bronze/Silver/Gold + artifacts (Parquet/etc.)",
         "Link": "https://min.io", "Status": "Healthy"},
        {"Tool": "OpenMetadata", "Purpose": "Catalog + schema + lineage surfaces", "Link": "https://open-metadata.org",
         "Status": "Healthy"},
        {"Tool": "Grafana", "Purpose": "Dashboards for job health, SLAs, infra metrics", "Link": "https://grafana.com",
         "Status": "Healthy"},
    ]
    df = pd.DataFrame(rows)
    df["Tool"] = df.apply(lambda r: f"[{r['Tool']}]({r['Link']})", axis=1)

    def _status_html(s):
        color = "limegreen" if s == "Healthy" else "crimson"
        return f"<span style='color:{color}; font-weight:700;'>●</span> {s}"

    df["Status"] = df["Status"].apply(_status_html)
    html_table(df[["Tool", "Purpose", "Status"]])
