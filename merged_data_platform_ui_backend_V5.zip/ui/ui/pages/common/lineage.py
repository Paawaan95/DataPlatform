from __future__ import annotations

import pandas as pd
import streamlit as st

from ui import settings

from ui.components.tables import show_table, search_box
from ui.services.job_detail_view import (
    LINEAGE_CONFIDENCE_LABELS,
    build_display_label,
    get_value,
    lineage_for_job,
    lineage_graph_dot,
    lineage_metrics,
    render_metric_cards,
    resolve_job_record,
)
from ui.services.jobs import ensure_dummy_jobs, visible_jobs_for_user
from ui.services.utils import dataset_id_from_s3_path


FIELD_LINEAGE_COLUMNS = [
    "Edge Id",
    "Source Dataset",
    "Source Column",
    "Target Dataset",
    "Target Column",
    "Transform",
    "Created At",
]



def _field_lineage_for_job(job: dict | pd.Series) -> pd.DataFrame:
    destination = get_value(job, "Destination", "destination")
    dataset_id = dataset_id_from_s3_path(destination)
    field_df = st.session_state.field_lineage_table
    if field_df is None or field_df.empty or not dataset_id:
        return pd.DataFrame(columns=FIELD_LINEAGE_COLUMNS)

    view = field_df[field_df["Target Dataset"].astype(str) == dataset_id].copy()
    if view.empty:
        suffix = dataset_id.split(".")[-1]
        view = field_df[
            field_df["Target Dataset"].astype(str).str.contains(suffix, case=False, na=False)
        ].copy()
    if view.empty:
        return pd.DataFrame(columns=FIELD_LINEAGE_COLUMNS)
    return view[FIELD_LINEAGE_COLUMNS].reset_index(drop=True)



def _render_job_lineage_view(job: dict | pd.Series, lineage_df: pd.DataFrame, lineage_mode: str, field_lineage_df: pd.DataFrame):
    st.title("Lineage")
    st.caption(build_display_label(job))
    metrics = lineage_metrics(lineage_df)
    render_metric_cards(
        [
            ("Upstream nodes", str(metrics["upstream"])),
            ("Downstream nodes", str(metrics["downstream"])),
            ("Edges", str(metrics["edges"])),
            ("Confidence", LINEAGE_CONFIDENCE_LABELS.get(lineage_mode, "Unavailable")),
        ]
    )

    if lineage_df.empty:
        st.info("No lineage available yet")
    else:
        st.graphviz_chart(lineage_graph_dot(job, lineage_df), use_container_width=True)

    st.markdown("#### Lineage Details")
    if lineage_df.empty:
        st.info("No lineage edges available yet")
    else:
        show_table(lineage_df, height=320)

    st.markdown("#### Field Lineage Details")
    if field_lineage_df.empty:
        st.info("No field lineage available yet")
    else:
        show_table(field_lineage_df, height=320)



def page_lineage():
    ensure_dummy_jobs()
    focus_job_id = get_value(st.query_params, "job_id") or st.session_state.get("selected_job_id", "")
    if focus_job_id:
        jobs = visible_jobs_for_user()
        tenant_id = st.session_state.get("selected_tenant") or settings.LEDGER_DEFAULT_TENANT
        job = resolve_job_record(focus_job_id, jobs, tenant_id)
        if job is not None:
            lineage_df, lineage_mode = lineage_for_job(tenant_id, focus_job_id, job)
            field_lineage_df = _field_lineage_for_job(job)
            _render_job_lineage_view(job, lineage_df, lineage_mode, field_lineage_df)
            return

    st.title("Lineage")
    df = st.session_state.lineage_table
    q = search_box("Search lineage (job id, asset id, table, feature, model...)", key="lineage_search")
    view = df.copy()
    if q and not view.empty:
        mask = False
        for c in ["From Type", "From Id", "To Type", "To Id", "Relation", "Created At"]:
            mask = mask | view[c].astype(str).str.lower().str.contains(q)
        view = view[mask]
    show_table(view, "Lineage edges")
