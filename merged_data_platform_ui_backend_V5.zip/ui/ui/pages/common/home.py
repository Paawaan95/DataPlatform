import streamlit as st

from ui.components.tables import assets_table_with_open
from ui.services.jobs import ensure_dummy_jobs, visible_assets_for_user


def page_home():
    st.title("Home")
    ensure_dummy_jobs()

    assets = visible_assets_for_user()

    st.info(
        "This is the platform home. For demo clarity, the **Jobs list** is shown only under **Job Details**. "
        "Use the sidebar -> **Job Details** to view and open jobs."
    )
    st.divider()

    st.subheader("Published assets (searchable)")
    assets_table_with_open(assets, "Assets", "home_assets_search")
