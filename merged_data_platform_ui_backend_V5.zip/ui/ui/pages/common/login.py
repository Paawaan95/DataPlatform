import streamlit as st

from ui.runtime import request_rerun
from ui.state import ROLE_TEAMS


def page_login():
    st.title("Data Platform Console – Login (Mock)")
    user = st.selectbox("Select User", ["Admin", "Data Engineer", "Data Analyst", "ML Engineer"], key="login_user")
    if st.button("Login", type="primary", key="login_btn"):
        st.session_state.logged_in = True
        st.session_state.user = user
        st.session_state.role = user
        st.session_state.team = ROLE_TEAMS.get(user, "Unknown")
        st.session_state.page = "Home"
        request_rerun()
