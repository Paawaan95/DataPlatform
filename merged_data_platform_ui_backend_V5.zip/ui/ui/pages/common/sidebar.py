from datetime import datetime

import streamlit as st

from ui.auth import do_logout_callback
from ui.runtime import request_rerun
from ui.services.ledger_api import fetch_available_tenants


def _clear_param(name: str):
    try:
        if name in st.query_params:
            del st.query_params[name]
    except Exception:
        pass


def sidebar():
    with st.sidebar:
        st.write(f"👤 **{st.session_state.user}**")
        st.write(f"Role: **{st.session_state.role}**")
        st.write(f"Team: **{st.session_state.team}**")

        col_a, col_b = st.columns([1, 1])
        with col_a:
            st.button("Logout", on_click=do_logout_callback, key="logout_btn")
        with col_b:
            st.caption(datetime.now().strftime("%Y-%m-%d %H:%M"))

        tenants = fetch_available_tenants()
        if tenants:
            current_tenant = st.session_state.get("selected_tenant") or tenants[0]
            if current_tenant not in tenants:
                current_tenant = tenants[0]
            selected_tenant = st.selectbox(
                "Tenant",
                options=tenants,
                index=tenants.index(current_tenant),
                key="tenant_selector",
            )
            if selected_tenant != st.session_state.get("selected_tenant"):
                st.session_state.selected_tenant = selected_tenant
                st.session_state.selected_job_id = None
                st.session_state.selected_asset_id = None
                _clear_param("job_id")
                _clear_param("asset_id")
                request_rerun()
            else:
                st.session_state.selected_tenant = selected_tenant

        st.divider()

        pages = ["Home", "Health", "Data Quality", "Lineage", "Field Lineage", "Job Details", "Asset Details"]

        if st.session_state.role == "Admin":
            pages += ["Org Levels", "OpenMetadata", "RBAC Matrix"]
        if st.session_state.role == "Data Engineer":
            pages += ["Ingestion", "Kafka Ingestion"]
        if st.session_state.role == "Data Analyst":
            pages += ["Query Studio"]
        if st.session_state.role == "ML Engineer":
            pages += ["Features & Models"]

        current_page = st.session_state.page if st.session_state.page in pages else pages[0]
        choice = st.radio(
            "Navigate",
            pages,
            index=pages.index(current_page),
            key="nav_radio",
        )

        if choice != st.session_state.page:
            st.session_state.page = choice
            try:
                st.query_params["page"] = choice
            except Exception:
                pass

            if choice == "Job Details":
                if "job_id" not in st.query_params:
                    st.session_state.selected_job_id = None
            else:
                st.session_state.selected_job_id = None
                _clear_param("job_id")

            if choice == "Asset Details":
                if "asset_id" not in st.query_params:
                    st.session_state.selected_asset_id = None
            else:
                st.session_state.selected_asset_id = None
                _clear_param("asset_id")
        else:
            st.session_state.page = choice
