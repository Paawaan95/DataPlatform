import pandas as pd
import streamlit as st

from ui import settings
from ui.services.ledger_api import publish_job_sftp


def render_sftp_tab(job_or_asset_id: str, serving_payload: dict | None):
    st.markdown('#### SFTP')
    sftp_payload = (serving_payload or {}).get('sftp') or {}
    result_location = (serving_payload or {}).get('result_location') or ''
    selected_object_key = st.session_state.get(f'serving_selected_object::{job_or_asset_id}', '')

    if not sftp_payload.get('available'):
        st.info('Not available yet')
        st.dataframe(
            pd.DataFrame([
                {
                    'Host': '',
                    'Port': '',
                    'Username': '',
                    'SFTP path': '',
                    'Backed by': result_location,
                    'Status': 'Not available yet',
                }
            ]),
            use_container_width=True,
            hide_index=True,
        )
        return

    st.dataframe(
        pd.DataFrame([
            {
                'Host': sftp_payload.get('host', ''),
                'Port': sftp_payload.get('port', ''),
                'Username': sftp_payload.get('username', ''),
                'SFTP path': sftp_payload.get('path', ''),
                'Selected object': selected_object_key,
                'Published files': sftp_payload.get('published_file_count', 0),
                'Read only': 'Yes' if sftp_payload.get('read_only') else 'No',
                'Backed by': sftp_payload.get('backed_by', result_location),
                'Status': 'Published' if sftp_payload.get('published') else 'Ready for explicit publish',
            }
        ]),
        use_container_width=True,
        hide_index=True,
    )
    if sftp_payload.get('message'):
        st.caption(str(sftp_payload.get('message')))

    publish_result = None
    if st.button('Publish selected object to SFTP', key=f'sftp_publish::{job_or_asset_id}'):
        tenant_id = st.session_state.get('selected_tenant') or settings.LEDGER_DEFAULT_TENANT
        publish_result = publish_job_sftp(tenant_id, job_or_asset_id, object_key=selected_object_key or None)
        if publish_result is not None:
            st.session_state[f'sftp_publish_feedback::{job_or_asset_id}'] = publish_result
        st.rerun()

    feedback = st.session_state.get(f'sftp_publish_feedback::{job_or_asset_id}') or publish_result
    if isinstance(feedback, dict) and feedback.get('message'):
        st.caption(str(feedback.get('message')))

    published_files = sftp_payload.get('published_files') or []
    if published_files:
        st.markdown('**Published file(s)**')
        st.dataframe(pd.DataFrame({'Path': published_files}), use_container_width=True, hide_index=True)
