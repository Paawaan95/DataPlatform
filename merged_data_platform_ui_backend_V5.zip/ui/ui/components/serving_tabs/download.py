import pandas as pd
import streamlit as st


def render_download_tab(job_or_asset_id: str, serving_payload: dict | None, download_payload: dict | None):
    st.markdown('#### Download')
    result_location = (serving_payload or {}).get('result_location') or ''
    download_info = download_payload or {}
    download_url = download_info.get('download_url') or ''
    storage_location = download_info.get('storage_location') or result_location
    selected_object_key = st.session_state.get(f'serving_selected_object::{job_or_asset_id}', '')

    rows = [{
        'Location': storage_location,
        'Selected object': selected_object_key or download_info.get('object_key') or '',
        'Resolved object key': download_info.get('object_key') or '',
        'Method': download_info.get('method', 'backend-generated URL' if download_url else 'Not available yet'),
        'Public endpoint': download_info.get('public_endpoint') or '',
        'Expires in seconds': download_info.get('expires_in_seconds') or '',
        'Expires at': download_info.get('expires_at') or '',
    }]
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    if download_info.get('message'):
        st.caption(str(download_info.get('message')))

    if download_url:
        st.markdown(f'[Download result]({download_url})')
    else:
        st.info('Not available yet')
