import pandas as pd
import streamlit as st


def _preview_keys(job_or_asset_id: str) -> tuple[str, str]:
    return (
        f'serving_preview_cursor::{job_or_asset_id}',
        f'serving_preview_history::{job_or_asset_id}',
    )


def render_sample_preview_tab(job_or_asset_id: str, preview_payload: dict | None):
    st.markdown('#### Sample preview')
    payload = preview_payload or {}
    rows = payload.get('rows') or []
    format_name = payload.get('format') or ''
    selected_object_key = st.session_state.get(f'serving_selected_object::{job_or_asset_id}', '')
    cursor_key, history_key = _preview_keys(job_or_asset_id)

    if not rows:
        st.info(payload.get('message') or 'Not available yet')
        return

    meta_cols = st.columns(4)
    with meta_cols[0]:
        st.caption(f"Format: {format_name or 'unknown'}")
    with meta_cols[1]:
        st.caption(f"Object: {payload.get('object_key') or selected_object_key or 'n/a'}")
    with meta_cols[2]:
        st.caption(f"Next cursor: {'available' if payload.get('next_cursor') else 'none'}")
    with meta_cols[3]:
        st.caption(f"Rows: {len(rows)}")

    nav_cols = st.columns([1, 1, 3])
    with nav_cols[0]:
        if st.button('Previous page', key=f'preview_prev::{job_or_asset_id}', disabled=not st.session_state.get(history_key)):
            history = list(st.session_state.get(history_key) or [])
            previous_cursor = history.pop() if history else None
            st.session_state[history_key] = history
            st.session_state[cursor_key] = previous_cursor or None
            st.rerun()
    with nav_cols[1]:
        if st.button('Next page', key=f'preview_next::{job_or_asset_id}', disabled=not payload.get('next_cursor')):
            history = list(st.session_state.get(history_key) or [])
            history.append(st.session_state.get(cursor_key))
            st.session_state[history_key] = history
            st.session_state[cursor_key] = payload.get('next_cursor')
            st.rerun()
    with nav_cols[2]:
        if payload.get('message'):
            st.caption(str(payload.get('message')))

    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
