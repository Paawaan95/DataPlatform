import pandas as pd
import streamlit as st


def render_api_tab(serving_payload: dict | None):
    st.markdown('#### API')
    api_payload = (serving_payload or {}).get('api') or {}
    objects_summary = (serving_payload or {}).get('objects_summary') or {}
    result_location = (serving_payload or {}).get('result_location') or ''
    if not api_payload.get('available'):
        st.info('Not available yet')
        st.dataframe(
            pd.DataFrame([
                {
                    'Preview endpoint': '',
                    'Objects endpoint': '',
                    'Download endpoint': '',
                    'Backed by': result_location,
                    'Status': 'Not available yet',
                }
            ]),
            use_container_width=True,
            hide_index=True,
        )
        return

    st.dataframe(
        pd.DataFrame([
            {
                'Preview endpoint': api_payload.get('preview_route') or api_payload.get('route', ''),
                'Objects endpoint': api_payload.get('objects_route', ''),
                'Download endpoint': api_payload.get('download_route', ''),
                'SFTP publish endpoint': (serving_payload or {}).get('sftp', {}).get('publish_route', ''),
                'Auth mode': api_payload.get('auth_mode', 'demo-none'),
                'Pagination': api_payload.get('pagination', 'cursor'),
                'Object count': objects_summary.get('count', 0),
                'Backed by': api_payload.get('backed_by', result_location),
                'Status': 'Ready',
            }
        ]),
        use_container_width=True,
        hide_index=True,
    )
