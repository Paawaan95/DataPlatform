import math
import re

import pandas as pd
import streamlit as st

from ui.links import go_to_link
from ui.runtime import request_rerun


SEARCHABLE_JOB_COLUMNS = [
    "Job Id",
    "Job Name",
    "System Type",
    "System Name",
    "Display Label",
    "Job Type",
    "Orchestrator",
    "Status",
    "Visibility",
    "Created At",
    "Submitted By",
    "Source",
    "Destination",
    "Result Location",
]


def show_table(df: pd.DataFrame, title: str | None = None, height: int | str | None = None):
    if title:
        st.markdown(f"### {title}")
    if df is None or df.empty:
        st.info("No rows yet.")
        return
    kwargs = dict(use_container_width=True, hide_index=True)
    if height is not None:
        kwargs["height"] = height
    st.dataframe(df, **kwargs)


def html_table(df: pd.DataFrame, title: str | None = None):
    if title:
        st.markdown(f"### {title}")
    if df is None or df.empty:
        st.info("No rows yet.")
        return

    def esc(s: str) -> str:
        return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace('"', "&quot;").replace("'", "&#39;"))

    def linkify(v):
        if v is None:
            return ""
        s = str(v)
        if s.strip().startswith("<span") or s.strip().startswith("<a "):
            return s
        m = re.match(r"^\[(.*?)\]\((.*?)\)$", s.strip())
        if m:
            txt, url = m.group(1), m.group(2)
            return f"<a href=\"{esc(url)}\">{esc(txt)}</a>"
        if s.startswith("http://") or s.startswith("https://") or s.startswith("s3://") or s.startswith("?page="):
            return f"<a href=\"{esc(s)}\">{esc(s)}</a>"
        return esc(s)

    cols = list(df.columns)
    thead = "".join([f"<th style='text-align:left;padding:6px;border-bottom:1px solid #555;'>{esc(c)}</th>" for c in cols])
    rows_html = ""
    for _, r in df.iterrows():
        tds = "".join([f"<td style='padding:6px;border-bottom:1px solid #333;'>{linkify(r[c])}</td>" for c in cols])
        rows_html += f"<tr>{tds}</tr>"
    html = f"<table style='width:100%;border-collapse:collapse;'><thead><tr>{thead}</tr></thead><tbody>{rows_html}</tbody></table>"
    st.markdown(html, unsafe_allow_html=True)


def search_box(label: str, key: str) -> str:
    return st.text_input(label, value="", key=key, placeholder="Type to filter...").strip().lower()


def md_link(val) -> str:
    s = "" if val is None else str(val)
    if s.startswith("s3://") or s.startswith("http://") or s.startswith("https://"):
        return f"[{s}]({s})"
    return s


def _series_or_blank(df: pd.DataFrame, name: str) -> pd.Series:
    if name in df.columns:
        return df[name]
    return pd.Series([""] * len(df), index=df.index)


def _coerce_positive_int(value, default: int) -> int:
    try:
        ivalue = int(value)
        return ivalue if ivalue > 0 else default
    except Exception:
        return default


def _page_window(current_page: int, total_pages: int, max_buttons: int = 7) -> list[int]:
    start = max(1, current_page - (max_buttons // 2))
    end = min(total_pages, start + max_buttons - 1)
    start = max(1, end - max_buttons + 1)
    return list(range(start, end + 1))


def _set_jobs_page(base_key: str, new_page: int, total_pages: int):
    st.session_state[f"{base_key}_page"] = max(1, min(total_pages, int(new_page)))
    request_rerun()


def _set_jobs_page_size(base_key: str, new_size: int):
    st.session_state[f"{base_key}_page_size"] = int(new_size)
    st.session_state[f"{base_key}_page"] = 1
    request_rerun()


def _clear_query_value(name: str):
    try:
        if name in st.query_params:
            del st.query_params[name]
    except Exception:
        pass


def _render_jobs_html_table(df: pd.DataFrame):
    if df is None or df.empty:
        st.info("No rows yet.")
        return

    def esc(value: str) -> str:
        return (str(value).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
                .replace('"', "&quot;").replace("'", "&#39;"))

    render = df.copy()
    render["Job Id"] = render.apply(
        lambda row: (
            f'<a href="{esc(row.get("Open", ""))}" target="_blank" rel="noopener noreferrer">{esc(row.get("Job Id", ""))}</a>'
            if str(row.get("Open", "")).strip() else esc(str(row.get("Job Id", "")))
        ),
        axis=1,
    )
    render["Open"] = render["Open"].apply(
        lambda value: f'[Open]({value})' if str(value).strip() else ""
    )
    html_table(render)


def _render_page_size_control(base_key: str, current_page_size: int):
    page_sizes = [20, 50, 100, 200]
    if hasattr(st, "popover"):
        with st.popover("Page size"):
            st.caption(f"Current: {current_page_size}")
            for size in page_sizes:
                if st.button(f"{size} rows", key=f"{base_key}_page_size_btn_{size}", use_container_width=True):
                    _set_jobs_page_size(base_key, size)
    else:
        selected_size = st.selectbox(
            "Page size",
            options=page_sizes,
            index=page_sizes.index(current_page_size) if current_page_size in page_sizes else 0,
            key=f"{base_key}_page_size_select",
            label_visibility="collapsed",
        )
        if selected_size != current_page_size:
            _set_jobs_page_size(base_key, selected_size)


def _render_actions_control(base_key: str, current_page_df: pd.DataFrame, total_pages: int):
    csv_data = current_page_df.to_csv(index=False).encode("utf-8")
    if hasattr(st, "popover"):
        with st.popover("Actions"):
            if st.button("Refresh list", key=f"{base_key}_refresh_btn", use_container_width=True):
                request_rerun()
            if st.button("Go to first page", key=f"{base_key}_first_action_btn", use_container_width=True):
                _set_jobs_page(base_key, 1, total_pages)
            if st.button("Go to last page", key=f"{base_key}_last_action_btn", use_container_width=True):
                _set_jobs_page(base_key, total_pages, total_pages)
            st.download_button(
                "Download current page CSV",
                data=csv_data,
                file_name=f"{base_key}_page.csv",
                mime="text/csv",
                key=f"{base_key}_download_btn",
                use_container_width=True,
            )
    else:
        action = st.selectbox(
            "Actions",
            options=["Actions", "Refresh list", "Go to first page", "Go to last page"],
            key=f"{base_key}_action_select",
            label_visibility="collapsed",
        )
        if action == "Refresh list":
            request_rerun()
        elif action == "Go to first page":
            _set_jobs_page(base_key, 1, total_pages)
        elif action == "Go to last page":
            _set_jobs_page(base_key, total_pages, total_pages)


def _render_jobs_pagination_controls(base_key: str, total_rows: int, total_pages: int, current_page: int,
                                     current_page_df: pd.DataFrame):
    page_numbers = _page_window(current_page, total_pages)

    left, right = st.columns([8, 3])
    with left:
        control_widths = [0.55, 0.55] + [0.55] * len(page_numbers) + [0.55, 0.55, 1.35, 1.35, 0.65]
        controls = st.columns(control_widths)
        idx = 0

        if controls[idx].button("«", key=f"{base_key}_jump_first"):
            _set_jobs_page(base_key, 1, total_pages)
        idx += 1
        if controls[idx].button("<", key=f"{base_key}_prev_page"):
            _set_jobs_page(base_key, current_page - 1, total_pages)
        idx += 1

        for page_number in page_numbers:
            if controls[idx].button(
                str(page_number),
                key=f"{base_key}_page_{page_number}",
                type="primary" if page_number == current_page else "secondary",
            ):
                _set_jobs_page(base_key, page_number, total_pages)
            idx += 1

        if controls[idx].button(">", key=f"{base_key}_next_page"):
            _set_jobs_page(base_key, current_page + 1, total_pages)
        idx += 1
        if controls[idx].button("»", key=f"{base_key}_jump_last"):
            _set_jobs_page(base_key, total_pages, total_pages)
        idx += 1

        current_page_size = _coerce_positive_int(st.session_state.get(f"{base_key}_page_size", 20), 20)
        with controls[idx]:
            _render_page_size_control(base_key, current_page_size)
        idx += 1

        with controls[idx]:
            _render_actions_control(base_key, current_page_df, total_pages)
        idx += 1

        if controls[idx].button("←", key=f"{base_key}_back_home"):
            _clear_query_value("job_id")
            try:
                st.query_params["page"] = "Home"
            except Exception:
                pass
            st.session_state.selected_job_id = None
            st.session_state.page = "Home"
            request_rerun()

    with right:
        st.markdown(
            (
                "<div style='text-align:right;padding-top:0.35rem;font-size:1.45rem;'>"
                f"<strong>Record Count:</strong> {int(total_rows)}"
                "</div>"
            ),
            unsafe_allow_html=True,
        )


def jobs_table_with_open(df: pd.DataFrame, title: str, search_key: str, *, show_search: bool = True,
                         paginate: bool = False, pager_key: str | None = None):
    st.markdown(f"### {title}")
    q = search_box("Search jobs", key=search_key) if show_search else ""

    view = df.copy() if df is not None else pd.DataFrame()
    if q and not view.empty:
        mask = pd.Series(False, index=view.index)
        for col in SEARCHABLE_JOB_COLUMNS:
            if col in view.columns:
                mask = mask | view[col].astype(str).str.lower().str.contains(q, na=False)
        view = view[mask]

    if view is None or view.empty:
        st.info("No matching jobs.")
        return

    view = pd.DataFrame({
        "Job Id": _series_or_blank(view, "Job Id").astype(str),
        "Job Name": _series_or_blank(view, "Job Name").astype(str),
        "System Type": _series_or_blank(view, "System Type").astype(str),
        "System Name": _series_or_blank(view, "System Name").astype(str),
        "Job Type": _series_or_blank(view, "Job Type").astype(str),
        "Orchestrator": _series_or_blank(view, "Orchestrator").astype(str),
        "Status": _series_or_blank(view, "Status").astype(str),
        "Visibility": _series_or_blank(view, "Visibility").astype(str),
        "Source": _series_or_blank(view, "Source").astype(str),
        "Destination": _series_or_blank(view, "Destination").astype(str),
        "Result Location": _series_or_blank(view, "Result Location").astype(str),
        "Created At": _series_or_blank(view, "Created At").astype(str),
        "Open": _series_or_blank(view, "Open Job Link").astype(str),
    }).fillna("")

    view = view.sort_values("Created At", ascending=False, kind="stable").reset_index(drop=True)

    if not paginate:
        _render_jobs_html_table(view)
        return

    pager_base = pager_key or search_key or title.lower().replace(" ", "_")
    page_size_key = f"{pager_base}_page_size"
    page_key = f"{pager_base}_page"

    current_page_size = _coerce_positive_int(st.session_state.get(page_size_key, 20), 20)
    if current_page_size not in {20, 50, 100, 200}:
        current_page_size = 20
        st.session_state[page_size_key] = current_page_size

    total_rows = len(view)
    total_pages = max(1, math.ceil(total_rows / current_page_size))
    current_page = _coerce_positive_int(st.session_state.get(page_key, 1), 1)
    current_page = max(1, min(total_pages, current_page))
    st.session_state[page_key] = current_page

    start_idx = (current_page - 1) * current_page_size
    end_idx = start_idx + current_page_size
    current_page_df = view.iloc[start_idx:end_idx].reset_index(drop=True)

    _render_jobs_html_table(current_page_df)
    st.write("")
    _render_jobs_pagination_controls(pager_base, total_rows, total_pages, current_page, current_page_df)


def assets_table_with_open(df: pd.DataFrame, title: str, search_key: str):
    st.markdown(f"### {title}")
    q = search_box("Search assets", key=search_key)

    view = df.copy() if df is not None else pd.DataFrame()
    if q and not view.empty:
        cols = ["Asset Id", "Type", "Name", "Visibility", "Owner", "Published At", "Source Job Id"]
        mask = pd.Series(False, index=view.index)
        for c in cols:
            if c in view.columns:
                mask = mask | view[c].astype(str).str.lower().str.contains(q, na=False)
        view = view[mask]

    if view is None or view.empty:
        st.info("No matching assets.")
        return

    h = st.columns([2.0, 2.5, 1.0, 1.4, 2.0, 1.0])
    h[0].markdown("**Asset Id**")
    h[1].markdown("**Name**")
    h[2].markdown("**Visibility**")
    h[3].markdown("**Published**")
    h[4].markdown("**Result Location**")
    h[5].markdown("**Open**")

    for _, r in view.sort_values("Published At", ascending=False).iterrows():
        link = str(r.get("Open Asset Link", ""))
        res = str(r.get("Result Location", ""))
        row = st.columns([2.0, 2.5, 1.0, 1.4, 2.0, 1.0])
        row[0].write(str(r.get("Asset Id", "")))
        row[1].write(str(r.get("Name", "")))
        row[2].write(str(r.get("Visibility", "")))
        row[3].write(str(r.get("Published At", "")))
        row[4].markdown(md_link(res), unsafe_allow_html=True)
        if link:
            if row[5].button("Open", key=f"open_asset_{r.get('Asset Id', '')}"):
                go_to_link(link)
        else:
            row[5].write("—")
