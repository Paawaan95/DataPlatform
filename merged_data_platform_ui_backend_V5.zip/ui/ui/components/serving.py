import streamlit as st

from ui.components.serving_tabs.api import render_api_tab
from ui.components.serving_tabs.download import render_download_tab
from ui.components.serving_tabs.sample_preview import render_sample_preview_tab
from ui.components.serving_tabs.sftp import render_sftp_tab


def serving_state_keys(job_or_asset_id: str) -> dict[str, str]:
    return {
        'object': f'serving_selected_object::{job_or_asset_id}',
        'preview_limit': f'serving_preview_limit::{job_or_asset_id}',
        'preview_cursor': f'serving_preview_cursor::{job_or_asset_id}',
        'preview_history': f'serving_preview_history::{job_or_asset_id}',
        'preview_object_snapshot': f'serving_preview_object_snapshot::{job_or_asset_id}',
        'preview_limit_snapshot': f'serving_preview_limit_snapshot::{job_or_asset_id}',
    }


def _summary_card(label: str, value: str):
    with st.container(border=True):
        st.caption(label.upper())
        st.markdown(f"**{value}**")


def _object_options(payload: dict) -> list[dict]:
    return list((payload.get('objects_summary') or {}).get('items') or [])


def _ensure_serving_state(job_or_asset_id: str, payload: dict):
    keys = serving_state_keys(job_or_asset_id)
    objects = _object_options(payload)
    primary_object = (payload.get('objects_summary') or {}).get('primary_object_key') or ''
    valid_keys = {str(item.get('object_key') or '').strip() for item in objects if str(item.get('object_key') or '').strip()}

    selected = str(st.session_state.get(keys['object']) or '').strip()
    if not selected or (valid_keys and selected not in valid_keys):
        st.session_state[keys['object']] = primary_object or (next(iter(valid_keys)) if valid_keys else '')

    st.session_state.setdefault(keys['preview_limit'], 20)
    st.session_state.setdefault(keys['preview_cursor'], None)
    st.session_state.setdefault(keys['preview_history'], [])

    current_object = str(st.session_state.get(keys['object']) or '').strip()
    last_object = str(st.session_state.get(keys['preview_object_snapshot']) or '').strip()
    if current_object != last_object:
        st.session_state[keys['preview_cursor']] = None
        st.session_state[keys['preview_history']] = []
        st.session_state[keys['preview_object_snapshot']] = current_object

    current_limit = int(st.session_state.get(keys['preview_limit']) or 20)
    last_limit = int(st.session_state.get(keys['preview_limit_snapshot']) or current_limit)
    if current_limit != last_limit:
        st.session_state[keys['preview_cursor']] = None
        st.session_state[keys['preview_history']] = []
    st.session_state[keys['preview_limit_snapshot']] = current_limit


def _render_serving_controls(job_or_asset_id: str, payload: dict):
    keys = serving_state_keys(job_or_asset_id)
    objects = _object_options(payload)
    if not objects:
        return

    object_labels: dict[str, str] = {}
    options: list[str] = []
    for item in objects:
        object_key = str(item.get('object_key') or '').strip()
        if not object_key:
            continue
        label = str(item.get('relative_key') or item.get('display_name') or object_key)
        size_bytes = item.get('size_bytes')
        if size_bytes not in (None, ''):
            label = f"{label} ({size_bytes} bytes)"
        if item.get('is_primary'):
            label = f"{label} · primary"
        options.append(object_key)
        object_labels[object_key] = label

    if not options:
        return

    cols = st.columns([2.5, 1])
    with cols[0]:
        st.selectbox(
            'Result object',
            options=options,
            key=keys['object'],
            format_func=lambda value: object_labels.get(value, value),
            help='Choose which object to preview, download, or publish to SFTP when a job produces multiple files.',
        )
    with cols[1]:
        st.selectbox(
            'Preview rows',
            options=[10, 20, 50, 100],
            key=keys['preview_limit'],
            help='Backend preview row limit per request.',
        )


def _render_serving_summary(job_or_asset_id: str, payload: dict, preview: dict | None, download: dict | None):
    result_location = str(payload.get('result_location') or '').strip()
    api_payload = payload.get('api') or {}
    sftp_payload = payload.get('sftp') or {}
    object_summary = payload.get('objects_summary') or {}
    preview_rows = (preview or {}).get('rows') or []
    download_url = (download or {}).get('download_url') or ''

    result_status = 'Available' if result_location else 'Not available yet'
    object_count = str(object_summary.get('count') or 0)
    primary_object = object_summary.get('primary_object_key') or 'Not resolved yet'

    serving_modes = []
    if api_payload.get('available'):
        serving_modes.append('API')
    if sftp_payload.get('available'):
        serving_modes.append('SFTP')
    if download_url:
        serving_modes.append('Download')
    if preview_rows:
        serving_modes.append('Preview')
    modes_text = ', '.join(serving_modes) if serving_modes else 'Pending publication'

    cards = [
        ('Job / Asset Id', job_or_asset_id),
        ('Result status', result_status),
        ('Serving modes', modes_text),
        ('Object count', object_count),
        ('Primary object', primary_object),
        ('Result location', result_location or 'Not available yet'),
    ]
    cols = st.columns(3)
    for idx, (label, value) in enumerate(cards):
        with cols[idx % 3]:
            _summary_card(label, value)


def serving_tabs(job_or_asset_id: str, *args):
    """
    Backward compatible signatures:
      serving_tabs(job_id)
      serving_tabs(job_id, serving_payload, preview_payload, download_payload)
      serving_tabs(job_id, result_location, serving_payload, preview_payload, download_payload)
    """
    explicit_result_location = ''
    payload = {}
    preview = None
    download = None

    if len(args) == 0:
        pass
    elif len(args) == 1:
        if isinstance(args[0], dict):
            payload = args[0]
        else:
            explicit_result_location = str(args[0] or '').strip()
    elif len(args) == 3 and isinstance(args[0], dict):
        payload = args[0] or {}
        preview = args[1] if isinstance(args[1], dict) else None
        download = args[2] if isinstance(args[2], dict) else None
    else:
        explicit_result_location = str(args[0] or '').strip()
        payload = args[1] if len(args) > 1 and isinstance(args[1], dict) else {}
        preview = args[2] if len(args) > 2 and isinstance(args[2], dict) else None
        download = args[3] if len(args) > 3 and isinstance(args[3], dict) else None

    payload = payload if isinstance(payload, dict) else {}
    payload_result_location = str(payload.get('result_location') or '').strip()
    effective_result_location = explicit_result_location or payload_result_location

    merged_payload = dict(payload)
    if effective_result_location and not merged_payload.get('result_location'):
        merged_payload['result_location'] = effective_result_location

    _ensure_serving_state(job_or_asset_id, merged_payload)

    st.markdown('### Consume results (Serving options)')
    _render_serving_summary(job_or_asset_id, merged_payload, preview, download)
    _render_serving_controls(job_or_asset_id, merged_payload)
    tabs = st.tabs(['API', 'SFTP', 'Download', 'Sample preview'])

    with tabs[0]:
        render_api_tab(merged_payload)

    with tabs[1]:
        render_sftp_tab(job_or_asset_id, merged_payload)

    with tabs[2]:
        render_download_tab(job_or_asset_id, merged_payload, download)

    with tabs[3]:
        render_sample_preview_tab(job_or_asset_id, preview)
