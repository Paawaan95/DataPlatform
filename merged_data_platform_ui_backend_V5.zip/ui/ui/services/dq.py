import urllib.parse
import uuid
from datetime import datetime

import pandas as pd
import streamlit as st

from ui.services.lineage import add_lineage_edge


def make_open_dq_link(dq_run_id: str):
    user = st.session_state.user or ""
    role = st.session_state.role or ""
    team = st.session_state.team or ""
    return f"?page=Data%20Quality&dq_run_id={urllib.parse.quote_plus(dq_run_id)}&user={urllib.parse.quote_plus(user)}&role={urllib.parse.quote_plus(role)}&team={urllib.parse.quote_plus(team)}"


def add_dq_run(related_type: str, related_id: str, suite: str, status: str, failed_checks: str):
    dq_id = f"DQ-{str(uuid.uuid4())[:8]}"
    created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    link = make_open_dq_link(dq_id)
    row = {
        "DQ Run Id": dq_id,
        "Related Type": related_type,
        "Related Id": related_id,
        "Expectation Suite": suite,
        "Status": status,
        "Failed Checks": failed_checks,
        "Created At": created,
        "Open DQ Link": link,
    }
    st.session_state.dq_runs_table = pd.concat([st.session_state.dq_runs_table, pd.DataFrame([row])], ignore_index=True)
    add_lineage_edge("DQ Run", dq_id, related_type, related_id, "validates")
    return dq_id


def ensure_dummy_dq():
    if not st.session_state.dq_runs_table.empty:
        return
    add_dq_run("Dataset", "gold.sales.customer_agg", "basic_suite", "PASSED", "")
    add_dq_run("Dataset", "bronze.sales.orders", "null_checks", "FAILED", "amount_null_rate>0.01")


def latest_dq_for_job(job_id: str):
    df = st.session_state.get("dq_runs_table")
    if df is None or df.empty:
        return (None, None, None, None)
    d = df[(df["Related Type"] == "Job") & (df["Related Id"] == job_id)]
    if d.empty:
        return (None, None, None, None)
    d = d.sort_values("Created At", ascending=False)
    r = d.iloc[0]
    return (str(r.get("Status", "")), str(r.get("Failed Checks", "")), str(r.get("Expectation Suite", "")),
            str(r.get("Created At", "")))


def dq_badge_html(status: str | None):
    if not status:
        return "<span style='padding:2px 8px;border-radius:999px;background:#444;color:#fff;font-size:11px;'>No DQ</span>"
    s = status.upper()
    if s in ["PASSED", "SUCCESS", "SUCCEEDED"]:
        bg = "#1f8b4c"
        txt = "PASSED"
    elif s in ["FAILED", "FAIL"]:
        bg = "#b42318"
        txt = "FAILED"
    elif s in ["RUNNING"]:
        bg = "#b54708"
        txt = "RUNNING"
    else:
        bg = "#444"
        txt = s
    return f"<span style='padding:2px 8px;border-radius:999px;background:{bg};color:#fff;font-size:11px;font-weight:600;'>{txt}</span>"
