from __future__ import annotations

import uuid
from datetime import datetime

import pandas as pd
import streamlit as st

from ui.links import make_open_job_link, make_open_asset_link
from ui.services.ledger_api import jobs_dataframe_from_api, ledger_api_enabled
from ui.services.lineage import add_field_lineage_edge, add_lineage_edge
from ui.services.utils import with_run_ts
from ui.services.features import ensure_dummy_feature_values_registry, add_feature_value_record


def add_job(job_type: str, orchestrator: str, result_location_base: str, submitted_by: str | None = None,
            role: str | None = None, status: str = "QUEUED", visibility: str = "Private", team: str | None = None,
            source: str | None = None, destination: str | None = None, job_id: str | None = None,
            created_at: str | None = None, select_job: bool = True, job_name: str | None = None,
            system_type: str | None = None, system_name: str | None = None):
    job_id = job_id or f"JOB-{str(uuid.uuid4())[:8]}"
    created = created_at or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    result_location = with_run_ts(result_location_base)
    open_link = make_open_job_link(job_id)
    row = {
        "Job Id": job_id,
        "Job Name": job_name or job_type,
        "System Type": system_type or orchestrator.lower(),
        "System Name": system_name or job_name or job_type,
        "Display Label": f"{job_type} - {job_name or job_type}",
        "Submitted By": submitted_by if submitted_by else st.session_state.user,
        "Role": role if role else st.session_state.role,
        "Team": team if team else st.session_state.team,
        "Visibility": visibility,
        "Job Type": job_type,
        "Orchestrator": orchestrator,
        "Status": status,
        "Created At": created,
        "Source": source if source else "",
        "Destination": destination if destination else "",
        "Result Location": result_location,
        "Open Job Link": open_link,
        "External Job Link": "",
        "Airflow DAG Id": "",
        "Airflow DAG Run Id": "",
        "Airbyte Connection Id": "",
        "Airbyte Job Id": "",
    }
    st.session_state.jobs_table = pd.concat([st.session_state.jobs_table, pd.DataFrame([row])], ignore_index=True)
    if select_job:
        st.session_state.selected_job_id = job_id
    if source:
        add_lineage_edge("Input", source, "Job", job_id, "feeds")
    if destination:
        add_lineage_edge("Job", job_id, "Output", destination, "writes")
    add_lineage_edge("Job", job_id, "Location", result_location, "stores_at")
    return job_id, open_link, result_location


def jobs_table_source() -> pd.DataFrame:
    if ledger_api_enabled():
        tenant_id = st.session_state.get("selected_tenant") or "demo"
        fetch_limit = 500
        try:
            configured_limit = int(st.session_state.get("jobs_fetch_limit", 500))
            fetch_limit = min(500, max(1, configured_limit))
        except Exception:
            fetch_limit = 500
        api_jobs = jobs_dataframe_from_api(tenant_id, limit=fetch_limit)
        if api_jobs is not None and (not api_jobs.empty or not st.session_state.get("ledger_api_error")):
            return api_jobs
    return st.session_state.jobs_table


def ensure_dummy_field_lineage():
    if not st.session_state.field_lineage_table.empty:
        return
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    samples = [
        ("sales.orders", "order_id", "gold.sales.customer_agg", "order_id", "copy"),
        ("sales.orders", "customer_id", "gold.sales.customer_agg", "customer_id", "copy"),
        ("sales.orders", "amount", "gold.sales.customer_agg", "total_revenue", "SUM(amount) GROUP BY customer_id"),
        ("gold.sales.customer_agg", "total_revenue", "gold.sales.features", "clv", "rename(total_revenue→clv)"),
        ("silver.crm.customers", "customer_id", "gold.sales.features", "customer_id", "copy"),
    ]
    for a, b, c, d, e in samples:
        add_field_lineage_edge(a, b, c, d, e, created=now)


def ensure_dummy_lineage():
    if not st.session_state.lineage_table.empty:
        return
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    edges = [
        ("Job", "JOB-DEMO-0001", "Dataset", "bronze.sales.orders", "writes_to"),
        ("Dataset", "bronze.sales.orders", "Dataset", "silver.sales.orders_clean", "transforms_to"),
        ("Dataset", "silver.sales.orders_clean", "Dataset", "gold.sales.customer_agg", "aggregates_to"),
        ("Dataset", "gold.sales.customer_agg", "Feature", "customer_lifetime_value", "feeds_feature"),
        ("Feature", "customer_lifetime_value", "Model", "churn_model", "feeds_model"),
        ("Job", "JOB-DEMO-0002", "Asset", "AST-DEMO-0001", "publishes"),
    ]
    for ft, fid, tt, tid, rel in edges:
        edge_id = f"LIN-{str(uuid.uuid4())[:8]}"
        row = {"Edge Id": edge_id, "From Type": ft, "From Id": fid, "To Type": tt, "To Id": tid, "Relation": rel,
               "Created At": now}
        st.session_state.lineage_table = pd.concat([st.session_state.lineage_table, pd.DataFrame([row])],
                                                   ignore_index=True)


def ensure_dummy_assets():
    if not st.session_state.published_assets.empty:
        return
    user = st.session_state.user or "Admin"
    team = st.session_state.team or "Platform"
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    a1 = "AST-DEMO-0001"
    a2 = "AST-DEMO-0002"
    st.session_state.published_assets = pd.concat([st.session_state.published_assets, pd.DataFrame([
        {"Asset Id": a1, "Type": "Dataset", "Name": "gold.sales.customer_agg", "Visibility": "Global", "Owner": user,
         "Team": team, "Published At": now, "Source Job Id": "JOB-DEMO-0001",
         "Result Location": "s3://minio/gold/sales/customer_agg/run_ts=20260131_101500/",
         "Open Asset Link": make_open_asset_link(a1)},
        {"Asset Id": a2, "Type": "Report", "Name": "Daily Revenue Report", "Visibility": "Team", "Owner": user,
         "Team": team, "Published At": now, "Source Job Id": "JOB-DEMO-0002",
         "Result Location": "s3://minio/reports/revenue/run_ts=20260131_090000/",
         "Open Asset Link": make_open_asset_link(a2)},
    ])], ignore_index=True)


def ensure_dummy_jobs():
    ensure_dummy_field_lineage()
    ensure_dummy_lineage()
    ensure_dummy_assets()
    ensure_dummy_feature_values_registry()
    if ledger_api_enabled():
        return
    if not st.session_state.jobs_table.empty:
        return

    add_job(
        "Ingestion",
        "Airbyte + Airflow",
        "s3://minio/bronze/sales/orders/",
        submitted_by="Data Engineer",
        role="Data Engineer",
        team="DataEng",
        status="SUCCEEDED",
        visibility="Global",
        source="postgresql://sales/orders",
        destination="s3://minio/bronze/sales/orders/",
        job_id="JOB-DEMO-0001",
        select_job=False,
        job_name="Salesforce to Snowflake",
        system_type="airbyte",
        system_name="Salesforce to Snowflake",
    )
    add_job(
        "SQL query",
        "Airflow + Trino",
        "s3://minio/gold/sales/customer_agg/",
        submitted_by="Data Analyst",
        role="Data Analyst",
        team="Analytics",
        status="RUNNING",
        visibility="Team",
        source="s3://minio/silver/sales/orders_clean/",
        destination="s3://minio/gold/sales/customer_agg/",
        job_id="JOB-DEMO-0002",
        select_job=False,
        job_name="Daily Revenue Query",
        system_type="sql",
        system_name="daily_revenue_query",
    )
    add_job(
        "Feature materialization",
        "Airflow + Spark",
        "s3://minio/gold/sales/features/customer_lifetime_value/",
        submitted_by="ML Engineer",
        role="ML Engineer",
        team="ML",
        status="SUCCEEDED",
        visibility="Team",
        source="s3://minio/gold/sales/customer_agg/",
        destination="s3://minio/gold/sales/features/",
        job_id="JOB-DEMO-0003",
        select_job=False,
        job_name="Customer Segmentation Prompt",
        system_type="nl",
        system_name="customer_segmentation_prompt",
    )
    add_job(
        "Model training",
        "Airflow + Python",
        "s3://minio/models/churn_model/",
        submitted_by="ML Engineer",
        role="ML Engineer",
        team="ML",
        status="FAILED",
        visibility="Private",
        source="s3://minio/gold/sales/features/",
        destination="s3://minio/models/churn_model/",
        job_id="JOB-DEMO-0004",
        select_job=False,
        job_name="Churn Model Training",
        system_type="airflow",
        system_name="churn_model_training",
    )


def visible_assets_for_user():
    assets = st.session_state.published_assets
    if assets.empty:
        return assets
    role = st.session_state.role
    user = st.session_state.user
    team = st.session_state.team
    if role == "Admin":
        return assets
    global_assets = assets[assets["Visibility"] == "Global"]
    team_assets = assets[(assets["Visibility"] == "Team") & (assets["Team"] == team)]
    private_assets = assets[(assets["Visibility"] == "Private") & (assets["Owner"] == user)]
    return pd.concat([global_assets, team_assets, private_assets], ignore_index=True)


def visible_jobs_for_user():
    jobs = jobs_table_source()
    if jobs is None or jobs.empty:
        return jobs
    role = st.session_state.role
    user = st.session_state.user
    team = st.session_state.get("team", None)
    if role == "Admin":
        return jobs
    global_jobs = jobs[jobs["Visibility"] == "Global"]
    team_jobs = jobs[(jobs["Visibility"] == "Team") & (jobs["Team"] == team)]
    private_jobs = jobs[(jobs["Visibility"] == "Private") & (jobs["Submitted By"] == user)]
    return pd.concat([global_jobs, team_jobs, private_jobs], ignore_index=True).drop_duplicates(subset=["Job Id"])


def publish_output_from_job(job_id: str, asset_type: str, asset_name: str, visibility: str):
    row = visible_jobs_for_user()
    if row is None or row.empty:
        return None
    match = row[row["Job Id"] == job_id]
    if match.empty:
        return None
    job = match.iloc[0]
    asset_id = f"AST-{str(uuid.uuid4())[:8]}"
    published_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    payload = {
        "Asset Id": asset_id,
        "Type": asset_type,
        "Name": asset_name,
        "Visibility": visibility,
        "Owner": st.session_state.user,
        "Team": st.session_state.team,
        "Published At": published_at,
        "Source Job Id": job_id,
        "Result Location": job.get("Result Location", ""),
        "Open Asset Link": make_open_asset_link(asset_id),
    }
    st.session_state.published_assets = pd.concat(
        [st.session_state.published_assets, pd.DataFrame([payload])],
        ignore_index=True,
    )

    destination = str(job.get("Destination", "") or "")
    if asset_type == "Feature output" and destination:
        ensure_dummy_feature_values_registry()
        add_feature_value_record(
            feature_name=asset_name,
            entity=destination.split("/")[-2] if "/" in destination else destination,
            store="offline",
            materialization_job_id=job_id,
            offline_location=str(job.get("Result Location", "")),
            online_location="",
            status="AVAILABLE",
        )
    return asset_id
