from __future__ import annotations

import uuid
from datetime import datetime

import pandas as pd
import streamlit as st


LINEAGE_COLUMNS = [
    "Edge Id",
    "From Type",
    "From Id",
    "To Type",
    "To Id",
    "Relation",
    "Created At",
]


def add_lineage_edge(from_type: str, from_id: str, to_type: str, to_id: str, relation: str):
    edge_id = f"LIN-{str(uuid.uuid4())[:8]}"
    created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row = {
        "Edge Id": edge_id,
        "From Type": from_type,
        "From Id": from_id,
        "To Type": to_type,
        "To Id": to_id,
        "Relation": relation,
        "Created At": created,
    }
    st.session_state.lineage_table = pd.concat([st.session_state.lineage_table, pd.DataFrame([row])], ignore_index=True)


def add_field_lineage(src_dataset: str, src_col: str, tgt_dataset: str, tgt_col: str, transform: str):
    edge_id = f"FLN-{str(uuid.uuid4())[:8]}"
    created = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    row = {
        "Edge Id": edge_id,
        "Source Dataset": src_dataset,
        "Source Column": src_col,
        "Target Dataset": tgt_dataset,
        "Target Column": tgt_col,
        "Transform": transform,
        "Created At": created,
    }
    st.session_state.field_lineage_table = pd.concat([
        st.session_state.field_lineage_table, pd.DataFrame([row])
    ], ignore_index=True)
    return edge_id


def add_field_lineage_edge(src_dataset: str, src_col: str, tgt_dataset: str, tgt_col: str, transform: str,
                           created: str | None = None):
    if created is None:
        return add_field_lineage(src_dataset, src_col, tgt_dataset, tgt_col, transform)
    edge_id = f"FLN-{str(uuid.uuid4())[:8]}"
    row = {
        "Edge Id": edge_id,
        "Source Dataset": src_dataset,
        "Source Column": src_col,
        "Target Dataset": tgt_dataset,
        "Target Column": tgt_col,
        "Transform": transform,
        "Created At": created,
    }
    st.session_state.field_lineage_table = pd.concat([
        st.session_state.field_lineage_table, pd.DataFrame([row])
    ], ignore_index=True)
    return edge_id


def lineage_for_node(node_id: str) -> pd.DataFrame:
    df = st.session_state.lineage_table
    if df.empty:
        return df
    mask = (df["From Id"] == node_id) | (df["To Id"] == node_id)
    return df[mask].copy()


def _clean_text(value) -> str:
    return "" if value is None else str(value).strip()


def _job_value(job, *keys: str) -> str:
    if hasattr(job, "get"):
        for key in keys:
            value = _clean_text(job.get(key, ""))
            if value:
                return value
    return ""


def fallback_lineage_for_job(job) -> pd.DataFrame:
    job_id = _job_value(job, "Job Id", "job_id")
    source = _job_value(job, "Source", "source")
    destination = _job_value(job, "Destination", "destination")
    result_location = _job_value(job, "Result Location", "result_location")

    rows = []
    created_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    def add_edge(from_type: str, from_id: str, to_type: str, to_id: str, relation: str):
        if not from_id or not to_id:
            return
        rows.append({
            "Edge Id": f"LIN-{str(uuid.uuid4())[:8]}",
            "From Type": from_type,
            "From Id": from_id,
            "To Type": to_type,
            "To Id": to_id,
            "Relation": relation,
            "Created At": created_at,
        })

    add_edge("Source", source, "Job", job_id, "feeds")
    add_edge("Job", job_id, "Destination", destination, "writes")
    add_edge("Job", job_id, "Result Location", result_location, "stores_at")

    df = pd.DataFrame(rows, columns=LINEAGE_COLUMNS)
    if df.empty:
        return df
    return df.drop_duplicates(subset=["From Type", "From Id", "To Type", "To Id", "Relation"]).reset_index(drop=True)


def lineage_stats(lineage_df: pd.DataFrame, job_id: str) -> dict[str, int]:
    if lineage_df is None or lineage_df.empty:
        return {"upstream": 0, "downstream": 0, "edges": 0}
    upstream = lineage_df[lineage_df["To Id"].astype(str) == str(job_id)]["From Id"].astype(str).nunique()
    downstream = lineage_df[lineage_df["From Id"].astype(str) == str(job_id)]["To Id"].astype(str).nunique()
    return {"upstream": int(upstream), "downstream": int(downstream), "edges": int(len(lineage_df))}


def lineage_graph_dot(job, lineage_df: pd.DataFrame) -> str:
    job_id = _job_value(job, "Job Id", "job_id") or "UNKNOWN_JOB"
    label = _job_value(job, "Display Label", "display_label") or _job_value(job, "Job Name", "job_name") or job_id

    if lineage_df is None or lineage_df.empty:
        safe = job_id.replace('"', "'")
        safe_label = label.replace('"', "'")
        return "\n".join([
            "digraph Lineage {",
            '  graph [rankdir=LR, bgcolor="transparent"];',
            '  node [shape=box, style="rounded,filled", fontname="Helvetica", color="#94a3b8", fillcolor="#dbeafe"];',
            f'  "Job:{safe}" [label="Job\\n{safe_label}", color="#2563eb", fillcolor="#dbeafe"];',
            "}",
        ])

    nodes = {}
    edges = []
    palette = {
        "Job": ("#dbeafe", "#2563eb"),
        "Source": ("#ecfeff", "#0891b2"),
        "Destination": ("#ecfccb", "#65a30d"),
        "Result Location": ("#f5f3ff", "#7c3aed"),
    }

    for _, row in lineage_df.iterrows():
        from_type = _clean_text(row.get("From Type")) or "Source"
        from_id = _clean_text(row.get("From Id"))
        to_type = _clean_text(row.get("To Type")) or "Target"
        to_id = _clean_text(row.get("To Id"))
        relation = _clean_text(row.get("Relation")) or "flows_to"
        if not from_id or not to_id:
            continue
        fk = f"{from_type}:{from_id}".replace('"', "'")
        tk = f"{to_type}:{to_id}".replace('"', "'")
        nodes[fk] = (from_type, from_id)
        nodes[tk] = (to_type, to_id)
        edges.append((fk, tk, relation.replace('"', "'")))

    lines = [
        "digraph Lineage {",
        '  graph [rankdir=LR, bgcolor="transparent", pad="0.2", nodesep="0.55", ranksep="0.85"];',
        '  node [shape=box, style="rounded,filled", fontname="Helvetica", color="#94a3b8", fillcolor="#f8fafc"];',
        '  edge [fontname="Helvetica", fontsize="10", color="#64748b"];',
    ]
    for key, (node_type, node_id) in nodes.items():
        fill, border = palette.get(node_type, ("#f8fafc", "#94a3b8"))
        node_label = label if node_type == "Job" and node_id == job_id else node_id
        safe_label = node_label.replace('"', "'")
        lines.append(f'  "{key}" [label="{node_type}\\n{safe_label}", fillcolor="{fill}", color="{border}"];')
    for fk, tk, rel in edges:
        lines.append(f'  "{fk}" -> "{tk}" [label="{rel}"];')
    lines.append("}")
    return "\n".join(lines)
