from __future__ import annotations

import urllib.parse
from typing import Any

import pandas as pd
import streamlit as st

from ui import settings
from ui.services.ledger_api import fetch_job_detail, fetch_job_lineage, ledger_api_enabled
from ui.services.lineage import fallback_lineage_for_job, lineage_for_node


DETAIL_COLUMNS = [
    "Job Id",
    "Job Name",
    "System Type",
    "System Name",
    "Display Label",
    "Submitted By",
    "Role",
    "Team",
    "Visibility",
    "Job Type",
    "Orchestrator",
    "Status",
    "Created At",
    "Updated At",
    "Last Seen At",
    "Source",
    "Destination",
    "Result Location",
    "Open Job Link",
    "Airflow DAG",
    "Airflow Run",
    "Airbyte Connection",
    "Airbyte Job",
]

LINEAGE_COLUMNS = [
    "Edge Id",
    "From Type",
    "From Id",
    "To Type",
    "To Id",
    "Relation",
    "Created At",
]


LINEAGE_CONFIDENCE_LABELS = {
    "authoritative": "Authoritative",
    "session": "Workspace cache",
    "inferred": "Inferred",
    "none": "Unavailable",
}


SYSTEM_COLORS = {
    "job": "#dbeafe",
    "source": "#ecfeff",
    "dataset": "#ecfccb",
    "destination": "#ede9fe",
    "result location": "#fee2e2",
    "airflow": "#ffedd5",
    "airbyte": "#cffafe",
    "trino": "#fef3c7",
    "sql": "#fef3c7",
    "kafka": "#fee2e2",
    "nl": "#dcfce7",
    "feature": "#dcfce7",
    "model": "#f3e8ff",
}


def clean_text(value: Any) -> str:
    if value is None:
        return ""
    return str(value).strip()



def get_value(job: dict | pd.Series | None, *keys: str) -> str:
    if job is None:
        return ""
    getter = job.get if hasattr(job, "get") else lambda k, default=None: default
    for key in keys:
        value = clean_text(getter(key, ""))
        if value:
            return value
    return ""



def merge_job_records(primary: dict | pd.Series | None, fallback: dict | pd.Series | None) -> dict[str, Any] | None:
    if primary is None and fallback is None:
        return None

    merged: dict[str, Any] = {}
    for item in (fallback, primary):
        if item is None:
            continue
        data = item.to_dict() if hasattr(item, "to_dict") else dict(item)
        for key, value in data.items():
            if key not in merged or clean_text(merged.get(key)) == "":
                merged[key] = value
            elif clean_text(value):
                merged[key] = value
    return merged



def build_job_name(job: dict | pd.Series) -> str:
    return (
        get_value(job, "Job Name", "job_name")
        or get_value(job, "System Name", "system_name")
        or get_value(job, "Airflow DAG Id", "airflow_dag_id")
        or get_value(job, "Airbyte Connection Id", "airbyte_connection_id")
        or get_value(job, "Airbyte Job Id", "airbyte_job_id")
        or get_value(job, "Job Type", "job_type")
        or get_value(job, "Job Id", "job_id")
    )



def build_system_type(job: dict | pd.Series) -> str:
    explicit = get_value(job, "System Type", "system_type")
    if explicit:
        return explicit
    if get_value(job, "Airflow DAG Id", "airflow_dag_id"):
        return "airflow"
    if get_value(job, "Airbyte Connection Id", "airbyte_connection_id") or get_value(job, "Airbyte Job Id", "airbyte_job_id"):
        return "airbyte"
    orchestrator = get_value(job, "Orchestrator", "orchestrator")
    if orchestrator:
        return orchestrator.split("+")[0].strip().lower()
    return ""



def build_system_name(job: dict | pd.Series) -> str:
    return (
        get_value(job, "System Name", "system_name")
        or get_value(job, "Airflow DAG Id", "airflow_dag_id")
        or get_value(job, "Airbyte Connection Id", "airbyte_connection_id")
        or get_value(job, "Airbyte Job Id", "airbyte_job_id")
        or get_value(job, "Orchestrator", "orchestrator")
    )



def build_display_label(job: dict | pd.Series) -> str:
    explicit = get_value(job, "Display Label", "display_label")
    if explicit:
        return explicit
    job_type = get_value(job, "Job Type", "job_type")
    job_name = build_job_name(job)
    if job_type and job_name:
        return f"{job_type} - {job_name}"
    return job_name or build_system_name(job) or build_system_type(job) or get_value(job, "Job Id", "job_id")



def job_detail_dataframe(job: dict | pd.Series) -> pd.DataFrame:
    row = {
        "Job Id": get_value(job, "Job Id", "job_id"),
        "Job Name": build_job_name(job),
        "System Type": build_system_type(job),
        "System Name": build_system_name(job),
        "Display Label": build_display_label(job),
        "Submitted By": get_value(job, "Submitted By", "submitted_by_user_id"),
        "Role": get_value(job, "Role", "submitted_by_role"),
        "Team": get_value(job, "Team", "submitted_by_team"),
        "Visibility": get_value(job, "Visibility", "visibility"),
        "Job Type": get_value(job, "Job Type", "job_type"),
        "Orchestrator": get_value(job, "Orchestrator", "orchestrator"),
        "Status": get_value(job, "Status", "status"),
        "Created At": get_value(job, "Created At", "created_at"),
        "Updated At": get_value(job, "Updated At", "updated_at"),
        "Last Seen At": get_value(job, "Last Seen At", "last_seen_at"),
        "Source": get_value(job, "Source", "source"),
        "Destination": get_value(job, "Destination", "destination"),
        "Result Location": get_value(job, "Result Location", "result_location"),
        "Open Job Link": get_value(job, "External Job Link", "open_job_link"),
        "Airflow DAG": get_value(job, "Airflow DAG Id", "airflow_dag_id"),
        "Airflow Run": get_value(job, "Airflow DAG Run Id", "airflow_dag_run_id"),
        "Airbyte Connection": get_value(job, "Airbyte Connection Id", "airbyte_connection_id"),
        "Airbyte Job": get_value(job, "Airbyte Job Id", "airbyte_job_id"),
    }
    return pd.DataFrame([row], columns=DETAIL_COLUMNS)



def airflow_run_link(dag_id: str, dag_run_id: str) -> str:
    base = settings.AIRFLOW_UI_BASE_URL.rstrip("/")
    if not dag_id:
        return base
    encoded_dag = urllib.parse.quote_plus(dag_id)
    if dag_run_id:
        encoded_run = urllib.parse.quote_plus(dag_run_id)
        return f"{base}/dags/{encoded_dag}/grid?dag_run_id={encoded_run}"
    return f"{base}/dags/{encoded_dag}/grid"



def airbyte_link(connection_id: str, job_id: str) -> str:
    base = settings.AIRBYTE_UI_BASE_URL.rstrip("/")
    if connection_id:
        return base
    if job_id:
        return base
    return base



def resolve_action_links(job: dict | pd.Series) -> list[dict[str, str]]:
    external_job_link = get_value(job, "External Job Link", "open_job_link")
    airflow_dag_id = get_value(job, "Airflow DAG Id", "airflow_dag_id")
    airflow_dag_run_id = get_value(job, "Airflow DAG Run Id", "airflow_dag_run_id")
    airbyte_job_id = get_value(job, "Airbyte Job Id", "airbyte_job_id")
    airbyte_connection_id = get_value(job, "Airbyte Connection Id", "airbyte_connection_id")

    rows: list[dict[str, str]] = []
    airflow_ui_link = ""
    airbyte_ui_link = ""

    if airflow_dag_id:
        airflow_ui_link = external_job_link if external_job_link and ("/dags/" in external_job_link or "airflow" in external_job_link.lower()) else airflow_run_link(airflow_dag_id, airflow_dag_run_id)
        rows.append({"Action": "Airflow", "Open": f"[Open in Airflow UI]({airflow_ui_link})"})

    if airbyte_job_id or airbyte_connection_id:
        if external_job_link and not airflow_ui_link:
            airbyte_ui_link = external_job_link
        else:
            airbyte_ui_link = airbyte_link(airbyte_connection_id, airbyte_job_id)
        rows.append({"Action": "Airbyte", "Open": f"[Open in Airbyte UI]({airbyte_ui_link})"})

    if external_job_link and not rows:
        rows.append({"Action": "Source system", "Open": f"[Open in source system]({external_job_link})"})

    return rows



def normalize_lineage_df(df: pd.DataFrame | None) -> pd.DataFrame:
    if df is None or df.empty:
        return pd.DataFrame(columns=LINEAGE_COLUMNS)

    renamed = df.copy()
    rename_map = {
        "edge_id": "Edge Id",
        "id": "Edge Id",
        "from_type": "From Type",
        "from_id": "From Id",
        "to_type": "To Type",
        "to_id": "To Id",
        "relation": "Relation",
        "created_at": "Created At",
    }
    for source, target in rename_map.items():
        if source in renamed.columns and target not in renamed.columns:
            renamed[target] = renamed[source]

    for column in LINEAGE_COLUMNS:
        if column not in renamed.columns:
            renamed[column] = ""

    renamed = renamed[LINEAGE_COLUMNS].copy()
    for column in LINEAGE_COLUMNS:
        renamed[column] = renamed[column].fillna("").astype(str)
    return renamed



def lineage_for_job(tenant_id: str, job_id: str, job: dict | pd.Series) -> tuple[pd.DataFrame, str]:
    if ledger_api_enabled():
        backend_df = normalize_lineage_df(fetch_job_lineage(tenant_id, job_id))
        if not backend_df.empty:
            return backend_df, "authoritative"
    local_df = normalize_lineage_df(lineage_for_node(job_id))
    if not local_df.empty:
        return local_df, "session"
    fallback_df = normalize_lineage_df(fallback_lineage_for_job(job))
    if not fallback_df.empty:
        return fallback_df, "inferred"
    return normalize_lineage_df(pd.DataFrame()), "none"



def lineage_metrics(lineage_df: pd.DataFrame) -> dict[str, int]:
    if lineage_df is None or lineage_df.empty:
        return {
            "upstream": 0,
            "downstream": 0,
            "systems": 0,
            "edges": 0,
        }

    upstream = lineage_df["From Id"].astype(str).nunique()
    downstream = lineage_df["To Id"].astype(str).nunique()
    systems = pd.concat([
        lineage_df["From Type"].astype(str),
        lineage_df["To Type"].astype(str),
    ]).str.lower().nunique()
    return {
        "upstream": int(upstream),
        "downstream": int(downstream),
        "systems": int(systems),
        "edges": int(len(lineage_df)),
    }



def lineage_view_link(job_id: str) -> str:
    user = urllib.parse.quote_plus(st.session_state.get("user", "") or "")
    role = urllib.parse.quote_plus(st.session_state.get("role", "") or "")
    team = urllib.parse.quote_plus(st.session_state.get("team", "") or "")
    tenant = urllib.parse.quote_plus(st.session_state.get("selected_tenant", "") or "")
    return (
        f"?page=Lineage&job_id={urllib.parse.quote_plus(job_id)}"
        f"&user={user}&role={role}&team={team}&tenant={tenant}"
    )



def graph_node_fill(node_type: str) -> str:
    return SYSTEM_COLORS.get(node_type.lower(), "#f8fafc")



def lineage_graph_dot(job: dict | pd.Series, lineage_df: pd.DataFrame) -> str:
    focus_job_id = get_value(job, "Job Id", "job_id") or "Job"
    focus_label = build_display_label(job) or focus_job_id

    def node_name(node_type: str, node_id: str) -> str:
        return f"{node_type}:{node_id}".replace('"', "'")

    def node_label(node_type: str, node_id: str) -> str:
        short_id = node_id if len(node_id) <= 56 else f"{node_id[:53]}..."
        return f"{node_type}\\n{short_id}".replace('"', "'")

    nodes: dict[str, tuple[str, str]] = {}
    focus_key = node_name("Job", focus_job_id)
    nodes[focus_key] = (focus_label, "Job")
    edges: list[tuple[str, str, str]] = []

    for _, row in lineage_df.iterrows():
        from_type = clean_text(row.get("From Type")) or "Source"
        from_id = clean_text(row.get("From Id"))
        to_type = clean_text(row.get("To Type")) or "Target"
        to_id = clean_text(row.get("To Id"))
        relation = clean_text(row.get("Relation")) or "relates_to"
        if not from_id or not to_id:
            continue
        from_key = node_name(from_type, from_id)
        to_key = node_name(to_type, to_id)
        nodes.setdefault(from_key, (from_id, from_type))
        nodes.setdefault(to_key, (to_id, to_type))
        edges.append((from_key, to_key, relation))

    lines = [
        "digraph Lineage {",
        '  graph [rankdir=LR, bgcolor="transparent", pad="0.2", nodesep="0.55", ranksep="0.85"];',
        '  node [shape=box, style="rounded,filled", fontname="Helvetica", color="#94a3b8", fillcolor="#f8fafc", margin="0.18,0.12"];',
        '  edge [fontname="Helvetica", fontsize="10", color="#64748b", arrowsize="0.7"];',
    ]

    for key, (display, node_type) in nodes.items():
        is_focus = key == focus_key
        fill = "#dbeafe" if is_focus else graph_node_fill(node_type)
        border = "#2563eb" if is_focus else "#94a3b8"
        label = focus_label.replace('"', "'") if is_focus else node_label(node_type, display)
        lines.append(
            f'  "{key}" [label="{label}", fillcolor="{fill}", color="{border}", penwidth="{2 if is_focus else 1}"];'
        )

    for from_key, to_key, relation in edges:
        lines.append(f'  "{from_key}" -> "{to_key}" [label="{relation.replace(chr(34), chr(39))}"];')

    lines.append("}")
    return "\n".join(lines)



def render_metric_cards(items: list[tuple[str, str]]):
    if not items:
        return

    columns = st.columns(len(items))
    for col, (label, value) in zip(columns, items):
        with col:
            with st.container(border=True):
                st.caption(label.upper())
                st.markdown(f"### {value}")



def resolve_job_record(job_id: str, jobs: pd.DataFrame | None, tenant_id: str) -> dict[str, Any] | None:
    local_job = None
    if jobs is not None and not jobs.empty and "Job Id" in jobs.columns:
        local_match = jobs[jobs["Job Id"] == job_id]
        if not local_match.empty:
            local_job = local_match.iloc[0].to_dict()

    if ledger_api_enabled():
        backend_job = fetch_job_detail(tenant_id, job_id)
        merged = merge_job_records(backend_job, local_job)
        if merged:
            return merged
    return merge_job_records(local_job, None)
