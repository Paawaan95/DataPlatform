import urllib.parse
from urllib.parse import parse_qs, unquote_plus

import streamlit as st

from ui.runtime import request_rerun


def go_to_link(link: str):
    if not link:
        return
    try:
        qs = link[1:] if link.startswith("?") else link
        parsed = parse_qs(qs, keep_blank_values=True)

        try:
            st.query_params.clear()
        except Exception:
            pass
        for k, v in parsed.items():
            if v:
                st.query_params[k] = v[0]

        if "page" in parsed and parsed["page"]:
            st.session_state.page = unquote_plus(parsed["page"][0])
        if "job_id" in parsed and parsed["job_id"]:
            st.session_state.selected_job_id = parsed["job_id"][0]
        if "asset_id" in parsed and parsed["asset_id"]:
            st.session_state.selected_asset_id = parsed["asset_id"][0]

        if "user" in parsed and "role" in parsed and parsed["user"] and parsed["role"]:
            st.session_state.logged_in = True
            st.session_state.user = unquote_plus(parsed["user"][0])
            st.session_state.role = unquote_plus(parsed["role"][0])
        if "team" in parsed and parsed["team"]:
            st.session_state.team = unquote_plus(parsed["team"][0])
        if "tenant" in parsed and parsed["tenant"]:
            st.session_state.selected_tenant = unquote_plus(parsed["tenant"][0])

        request_rerun()
    except Exception:
        return


def make_open_job_link(job_id: str):
    user = st.session_state.user or ""
    role = st.session_state.role or ""
    team = st.session_state.get("team", "") or ""
    tenant = st.session_state.get("selected_tenant", "") or ""
    u = urllib.parse.quote_plus(user)
    r = urllib.parse.quote_plus(role)
    t = urllib.parse.quote_plus(team)
    tenant_q = urllib.parse.quote_plus(tenant)
    return f"?page=Job%20Details&job_id={job_id}&user={u}&role={r}&team={t}&tenant={tenant_q}"


def make_open_asset_link(asset_id: str):
    user = st.session_state.user or ""
    role = st.session_state.role or ""
    team = st.session_state.get("team", "") or ""
    tenant = st.session_state.get("selected_tenant", "") or ""
    u = urllib.parse.quote_plus(user)
    r = urllib.parse.quote_plus(role)
    t = urllib.parse.quote_plus(team)
    tenant_q = urllib.parse.quote_plus(tenant)
    return f"?page=Asset%20Details&asset_id={asset_id}&user={u}&role={r}&team={t}&tenant={tenant_q}"
